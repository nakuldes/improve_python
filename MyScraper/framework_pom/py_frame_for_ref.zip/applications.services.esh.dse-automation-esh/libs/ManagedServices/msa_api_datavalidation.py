import pytest
from configs import ManagedServices as ms_config
import time
from libs import API_responseValidation as api_validation
import docker



def verify_msa_api_status(init_env, initialize_request, imageTag, imageName, requestStatusId):
    hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
    #Make Http Request
    response = initialize_request.get(url=hosturl)
    assert response.status_code==200
    responseJson = response.json()
    print(responseJson)

    try:
        while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
            time.sleep(25)
            responseJson = initialize_request.get(url=hosturl).json()
            print(responseJson)

    except Exception as e:
        print("The response json: ", responseJson)
        pytest.fail(e)

    #Assert Statements
    jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesDockerScan")
    assert jsonres_validation==True
    assert responseJson["status"] == "SUCCESS"
    #Assert Image is uploaded in amr registry
    try:
        client = docker.from_env()
        print(f"The arm regisry username and apssword is: : {init_env['amrregistryusername'], init_env['amrregistrypassword']}")
        login_response = client.login(
            username=init_env['amrregistryusername'],
            password=init_env['amrregistrypassword'],
            registry= ms_config.amrRegistryUrl
        )
        print(f"Login Status: : {login_response}")
        #print(f"Docker login returns : {login_response['Status']}")
        print(f"Pulling docker image : {imageName}")
        imageObject = client.images.pull("amr-fm-registry.caas.intel.com/esh-user/"+imageName,tag=imageTag)
        print(f"The Image object is: {imageObject}")
        if imageObject is not None:
            assert True
        else:
            assert False
    except Exception as e:
        print(f"Failed to login to docker registry : {e}")
        pytest.fail(e)

def verifyPypiRequestStatus(init_env, initialize_request, TestData,requestStatusId):
        print("The testdata in status is: ", TestData)
        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        #Make Http Request
        print("THe status url: " , hosturl)
        response = initialize_request.get(url=hosturl)
        print("The response is", response)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements        
        assert responseJson["status"] == TestData['ExpectedResult']
        if TestData['ExpectedResult'] == "SUCCESS":
            if TestData['enableSecurityScan'] is None or TestData['enableSecurityScan'].lower() == 'true':
                expectedJSONSchema = "managedServicesPypiScanwithReports"
            else:
                expectedJSONSchema = "managedServicesPypiScanwithOutReports"
        else:
            expectedJSONSchema = "managedServicesFailure"
            
        jsonres_validation = api_validation.getJSONSchema(responseJson,expectedJSONSchema)
        assert jsonres_validation==True
        responseJson['responseBody']['ERROR_LOG'] == TestData['message']