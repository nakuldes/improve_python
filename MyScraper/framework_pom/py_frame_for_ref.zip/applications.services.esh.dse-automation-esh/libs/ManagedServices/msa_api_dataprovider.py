import pytest
import time
from utils import FileOperations as fo
from configs import ManagedServices as msa
import json
import utils.common

def get_BuildPypi_TestData_As_JSON(action):
    data_BuildPypi = fo.File_Operations().get_csv_data_as_Dataframe(msa.file_path_testdata_BuildPypi,action)
    data_BuildPypi_JSON = data_BuildPypi.to_json(orient="records")
    data_BuildPypi_JSON = json.loads(data_BuildPypi_JSON)
    #print(data_BuildPypi_JSON)
    return data_BuildPypi_JSON