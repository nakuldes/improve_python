import pytest
import utils
from configs import ManagementConsole as mc
import json
import uuid

# """  Update Name and Version in Payload  """

def update_name_and_version_in_payload(data):
    uniquestr = utils.common.get_Current_TimeStamp()
    uniquestr = uniquestr[4:]

    if data["name"]["en"] == "BLANK":
        data["name"]["en"] = ""
    elif str(data["name"]["en"]).startswith("AUTO_") or str(data["name"]["en"]).startswith("Auto_"):
        data["name"]["en"] = data["name"]["en"] + uniquestr
    elif str(data["name"]["en"]).startswith("AUTO") or str(data["name"]["en"]).startswith("Auto"):
        data["name"]["en"] = data["name"]["en"] + uniquestr
    elif str(data["name"]["en"]).startswith(" AUTO") or str(data["name"]["en"]).startswith(" Auto"):
        data["name"]["en"] = data["name"]["en"] + uniquestr
    if data["version"] == "BLANK":
        data["version"] = ""
    else:
        data["version"] = data["version"] + uniquestr

    return data
    
def update_user_and_uuid_in_payload(data):
    if data["user"] == "INVALID":
        data["user"] = "INVALID"
    elif data["user"] == "BLANK":
        data["user"] = ""
    if data["Id"] == "INVALID":
        data["Id"] = "INVALID"
    elif data["Id"] == "BLANK":
        data["Id"] = ""
    return data

def update_name_in_payload(data):
    uniquestr = utils.common.get_Current_TimeStamp()
    uniquestr = uniquestr[4:14]
    if data["name"]["en"] == "BLANK":
        data["name"]["en"] = ""
    elif str(data["name"]["en"]).startswith("AUTO_"):
        data["name"]["en"] = data["name"]["en"] + uniquestr

    return data

def update_uiroute_and_ircproductid_in_payload(data):
    uniquestr = utils.common.get_Current_TimeStamp()
    uniquestr = uniquestr[4:14]

    if data["uiRoute"] == "BLANK":
        data["uiRoute"] = ""
    elif str(data["uiRoute"]).startswith("AUTO_"):
        data["uiRoute"] = data["uiRoute"] + uniquestr

    if data["ircProductId"] == "BLANK":
        data["ircProductId"] = ""
    else:
        data["ircProductId"] = str(uuid.uuid4())

    return data
# """ Module data updates """

def update_ircproductid_in_payload(data):
    if data["ircProductId"] == "BLANK":
        data["ircProductId"] = ""
    else:
        data["ircProductId"] = str(uuid.uuid4())
    return data


def update_module_dependent_values(data, dependent_values):
    # Update the OS IDs for Valid and Invalid combinations -- osIds
    var_data = update_osids_in_payload(data, dependent_values)
    var_data = update_hwids_in_payload(var_data, dependent_values)
    var_data = update_ingredienttype_in_payload(var_data, dependent_values)
    var_data = update_filtertag_in_payload(var_data, dependent_values)

    return var_data


# """  Container data updates """

def update_container_dependent_values(data, dependent_values):
    var_data = update_osids_in_payload(data, dependent_values)
    # var_data = update_hwids_in_payload(var_data, dependent_values)
    # var_data = update_ingredienttype_in_payload(var_data, dependent_values)
    var_data = update_filtertag_in_payload(var_data, dependent_values)
    var_data = update_imagetype_in_payload(var_data, dependent_values)

    return var_data


# """  Online Distribution Data updates  """

def update_onlinedistribution_dependent_values(data, dependent_values):
    data = update_filtertag_in_payload(data, dependent_values)

    return data


# """  Helmchart data updates  """
def update_helmchart_dependent_values(data, dependent_values):
    data = update_osids_in_payload(data, dependent_values)
    # data = update_hwids_in_payload(data, dependent_values)
    # data = update_ingredienttype_in_payload(data, dependent_values)
    data = update_filtertag_in_payload(data, dependent_values)

    return data


# """ Packages data update """
def update_packages_dependent_values(data, dependent_values):
    # data = update_filtertag_in_payload_for_container(data, dependent_values)
    data = update_osids_in_payload(data, dependent_values)
    data = update_hwids_in_payload(data, dependent_values)
    data = update_recipetype_in_payload(data, dependent_values)
    return data


def create_dependent_components_for_package(request, init_env, counts, dependent_values):
    moduleids = create_module_for_package(request, init_env, counts, dependent_values)
    containerids = create_container_for_package(request, init_env, counts, dependent_values)
    helmchartids = create_helmchart_for_package(request, init_env, counts, dependent_values)
    # print(moduleids, containerids, helmchartids)

    return moduleids, containerids, helmchartids

def get_dependent_components_for_package(request, init_env, counts, dependent_values):
    moduleids = get_module_for_package(request, init_env, counts)
    containerids = get_container_for_package(request, init_env, counts)
    helmchartids = get_helmchart_for_packages(request, init_env, counts)

    # print(moduleids, containerids, helmchartids)
    return moduleids, containerids, helmchartids


def update_package_final_payload(request, init_env, payload, counts, dependent_values):

    payload = update_name_and_version_in_payload(payload)
    payload = update_uiroute_and_ircproductid_in_payload(payload)
    payload = update_packages_dependent_values(payload, dependent_values)
    payload = update_default_os_hwids(payload, dependent_values)
    if counts["action"] == "CREATE":
        modules, containers, helmcharts = create_dependent_components_for_package(request, init_env, counts,
                                                                                  dependent_values)
        payload["ingredients"] = modules
        payload["containerIds"] = containers
        payload["helmchartIds"] = helmcharts
        payload["filterTags"][0]["tags"] = dependent_values["filterTags"]
    elif counts["action"] == "GET":
        modules, containers, helmcharts = get_dependent_components_for_package(request, init_env, counts,
                                                                                  dependent_values)
        payload["ingredients"] = modules
        payload["containerIds"] = containers
        payload["helmchartIds"] = helmcharts
        filtertags = get_filter_tags(request, init_env, modules, containers, helmcharts)
        print(filtertags)
        if len(payload["filterTags"]) >= 1 and len(filtertags)>0:
            if len(payload["filterTags"][0]["tags"]) >= 1:
                if payload["filterTags"][0]["tags"][0] != "INVALID" and payload["filterTags"][0]["tags"][0] != "BLANK":
                    payload["filterTags"][0]["tags"] = filtertags
        # else:
        #     payload["filterTags"][0]["tags"][0] = dependent_values["filterTags"]

    payload = update_display_order_for_packages(payload)
    payload = update_installation_order_for_packages(payload)
    payload = update_is_recommended_for_packages(payload)
    payload = update_hide_display_order(payload)
    payload = update_resourceids_in_payload(payload, dependent_values)
    print(payload)

    return payload


"""
Update Individual Fields
"""
def get_filter_tags(request, init_env, modules, containers, helmchart):
    filtertags = []
    if len(modules)>0:
        hosturl = init_env + mc.ModuleEndPoint + modules[0] + "/"
        res = request.get(url=hosturl, verify=False)
        if len(res.json()["filterTags"]) > 0:
            filtertags.append(res.json()["filterTags"][0])
    if len(containers)>0:
        hosturl = init_env + mc.ContainerEndPoint + containers[0] + "/"
        res = request.get(url=hosturl, verify=False)
        if len(res.json()["filterTags"]) > 0:
            filtertags.append(res.json()["filterTags"][0])
    if len(helmchart)>0:
        hosturl = init_env + mc.HelmChartEndPoint + helmchart[0] + "/"
        res = request.get(url=hosturl, verify=False)
        if len(res.json()["filterTags"]) > 0:
            filtertags.append(res.json()["filterTags"][0])
    filtertags = [*set(filtertags)]
    return filtertags

def update_osids_in_payload(data, dependent_values):
    # Update the OS IDs for Valid and Invalid combinations -- osIds
    if len(data["osIds"]) >= 1:
        if data["osIds"][0] != "INVALID" and data["osIds"][0] != "BLANK":
            data["osIds"] = dependent_values["osIds"]
        elif data["osIds"][0] == "INVALID":
            data["osIds"] = ["INVALID"]
        elif data["osIds"][0] == "BLANK":
            data["osIds"] = [""]
    elif len(data["osIds"]) == 0:
        data["osIds"] = []
    return data


def update_hwids_in_payload(data, dependent_values):
    if len(data["hwIds"]) >= 1:
        if data["hwIds"][0] != "INVALID" and data["hwIds"][0] != "BLANK":
            data["hwIds"] = dependent_values["hwIds"]
        elif data["hwIds"][0] == "INVALID":
            data["hwIds"] = ["INVALID"]
        elif data["hwIds"][0] == "BLANK":
            data["hwIds"] = [""]
    elif len(data["hwIds"]) == 0:
        data["hwIds"] = []
    return data


def update_ingredienttype_in_payload(data, dependent_values):
    if data["ingredientType"] != "" and data["ingredientType"] != "INVALID" and data["ingredientType"] != "BLANK":
        data["ingredientType"] = dependent_values["ingredientType"]
    elif data["ingredientType"] == "INVALID":
        data["ingredientType"] = ["INVALID"]
    elif data["ingredientType"] == "BLANK":
        data["ingredientType"] = [""]
    return data


def update_filtertag_in_payload(data, dependent_values):
    if len(data["filterTags"]) >= 1:
        if data["filterTags"][0] != "INVALID" and data["filterTags"][0] != "BLANK":
            data["filterTags"] = dependent_values["filterTags"]
        elif data["filterTags"][0] == "INVALID":
            data["filterTags"] = ["INVALID"]
        elif data["filterTags"][0] == "BLANK":
            data["filterTags"] = [""]
    elif len(data["filterTags"]) == 0:
        data["filterTags"] = []
    return data


def update_filtertag_in_payload_for_container(data, dependent_values):
    if len(data["filterTags"]) >= 1:
        if len(data["filterTags"][0]["tags"]) >= 1:
            if data["filterTags"][0]["tags"][0] != "INVALID" and data["filterTags"][0]["tags"][0] != "BLANK":
                data["filterTags"][0]["tags"] = dependent_values["filterTags"]
            elif data["filterTags"][0]["tags"][0] == "INVALID":
                data["filterTags"][0]["tags"] = dependent_values["hwIds"]
            elif data["filterTags"][0]["tags"][0] == "BLANK":
                data["filterTags"][0]["tags"] = [""]
        elif len(data["filterTags"][0]["tags"]) == 0:
            data["filterTags"][0]["tags"] = []

    return data


def update_imagetype_in_payload(data, dependent_values):
    if data["imageType"] != "" and data["imageType"] != "INVALID" and data["imageType"] != "BLANK":
        data["imageType"] = dependent_values["imageType"]
    elif data["imageType"] == "INVALID":
        data["imageType"] = ["INVALID"]
    elif data["imageType"] == "BLANK":
        data["imageType"] = [""]

    return data


def update_recipetype_in_payload(data, dependent_values):
    # print(data)
    if data["recipeType"] != "" and data["recipeType"] != "INVALID" and data["recipeType"] != "BLANK":
        data["recipeType"] = dependent_values["recipeType"][0]
    elif data["recipeType"] == "INVALID":
        data["recipeType"] = dependent_values["filterTags"]
    elif data["recipeType"] == "INVALIDFORMAT":
        data["recipeType"] = "INVALID"
    elif data["recipeType"] == "BLANK":
        data["recipeType"] = ""

    return data

def update_resourceids_in_payload(data, dependent_values):
    # print(data)
    if data["resourceIds"] != [] and data["resourceIds"] != ["INVALID"] and data["resourceIds"] != ["BLANK"]:
        data["resourceIds"] = dependent_values["resourceIds"]
    elif data["resourceIds"] == ["INVALID"]:
        data["resourceIds"] = [dependent_values["filterTags"]]
    elif data["resourceIds"] == ["INVALIDFORMAT"]:
        data["resourceIds"] = ["INVALID"]
    elif data["resourceIds"] == ["BLANK"]:
        data["resourceIds"] = []

    return data



def update_default_os_hwids(data, dependent_values):
    if data["defaultOs"] != "" and data["defaultOs"] != "INVALID" and data["defaultOs"] != "BLANK":
        data["defaultOs"] = data["osIds"][0]
    elif data["defaultOs"] == "INVALID":
        data["defaultOs"] = dependent_values["filterTags"]
    elif data["defaultOs"] == "INVALIDFORMAT":
        data["defaultOs"] = "INVALID"
    elif data["defaultOs"] == "BLANK":
        data["defaultOs"] = ""

    if data["defaultHw"] != "" and data["defaultHw"] != "INVALID" and data["defaultHw"] != "BLANK":
        data["defaultHw"] = data["hwIds"][0]
    elif data["defaultHw"] == "INVALID":
        data["defaultHw"] = dependent_values["filterTags"]
    elif data["defaultHw"] == "INVALIDFORMAT":
        data["defaultHw"] = "INVALID"
    elif data["defaultHw"] == "BLANK":
        data["defaultHw"] = ""

    return data


def update_display_order_for_packages(data):
    displayorder = []
    if data["displayOrder"][0] == "INVALID":
        value = {"id": data["hwIds"][0], "type": "ingredients"}
        displayorder.append(value)
    elif data["displayOrder"][0] == "BLANK":
        displayorder=[]
    else:
        if len(data["ingredients"]) > 0:
            for i in range(0,len(data["ingredients"])):
                value = {"id": data["ingredients"][i], "type": "ingredients"}
                displayorder.append(value)
        if len(data["containerIds"]) > 0:
            for i in range(0,len(data["containerIds"])):
                value = {"id": data["containerIds"][i], "type": "containers"}
                displayorder.append(value)
        if len(data["helmchartIds"]) > 0:
            for i in range(0,len(data["helmchartIds"])):
                value = {"id": data["helmchartIds"][i], "type": "helmcharts"}
                displayorder.append(value)

    # print(displayorder)
    data["displayOrder"]=displayorder
    return data

def update_installation_order_for_packages(data):
    installorder = []
    if data["installationOrder"][0] == "INVALID":
        value = {"id": data["hwIds"][0], "type": "ingredients"}
        installorder.append(value)
    elif data["installationOrder"][0] == "BLANK":
        installorder=[]
    else:
        if len(data["ingredients"]) > 0:
            for i in range(0,len(data["ingredients"])):
                value = {"id": data["ingredients"][i], "type": "ingredients"}
                installorder.append(value)

        if len(data["containerIds"]) > 0:
            for i in range(0,len(data["containerIds"])):
                value = {"id": data["containerIds"][i], "type": "containers"}
                installorder.append(value)

        if len(data["helmchartIds"]) > 0:
            for i in range(0,len(data["helmchartIds"])):
                value = {"id": data["helmchartIds"][i], "type": "helmcharts"}
                installorder.append(value)

    data["installationOrder"] = installorder
    return data

def update_is_recommended_for_packages(data):
    isrecommended = []
    if data["isRecommended"][0] == "BLANK" or data["isRecommended"] == []:
        isrecommended = []
    elif data["isRecommended"][0] == "INVALID":
        isrecommended = data["osIds"]
    else:
        if len(data["ingredients"]) > 0:
            for i in range(0,len(data["ingredients"])):
                 isrecommended.append(data["ingredients"][i])

        if len(data["containerIds"]) > 0:
            for i in range(0,len(data["containerIds"])):
                isrecommended.append(data["containerIds"][i])

        if len(data["helmchartIds"]) > 0:
            for i in range(0,len(data["helmchartIds"])):
                isrecommended.append(data["helmchartIds"][i])

    data["isRecommended"] = isrecommended
    return data

def update_hide_display_order(data):
    hidedisplayOrder = []
    if len(data["hideDisplayOrder"]) == 0:
        hidedisplayOrder = []
    elif data["hideDisplayOrder"][0] == "BLANK":
        hidedisplayOrder = []
    else:
        if len(data["ingredients"]) > 0:
            for i in range(0,len(data["ingredients"])):
                hidedisplayOrder.append(data["ingredients"][i])

        elif len(data["containerIds"]) > 0:
            for i in range(0,len(data["containerIds"])):
                hidedisplayOrder.append(data["containerIds"][i])

        elif len(data["helmchartIds"]) > 0:
            for i in range(0,len(data["helmchartIds"])):
                hidedisplayOrder.append(data["helmchartIds"][i])

    # print(hidedisplayOrder)
    data["hideDisplayOrder"]=hidedisplayOrder
    return data

def update_package_payload_for_display_installation_order(payload, func, ids):

    for i in payload["displayOrder"]:
        if i["type"]== func:
            i["id"] = ids[0]
    for i in payload["installationOrder"]:
        if i["type"]== func:
            i["id"] = ids[0]


""" Create dependencies for packages """


def create_module_for_package(request, init_env, counts, dependent_values):
    jsonfile = open(mc.create_module_request_payload)
    data = json.load(jsonfile)
    data = update_name_and_version_in_payload(data)
    data = update_module_dependent_values(data, dependent_values)
    print(data)
    moduleids = []
    for i in range(0, counts["Module"]):
        res = request.post(init_env + mc.ModuleEndPoint, json=data)
        if res.status_code == 200:
            moduleids.append(res.json()["id"])
        else:
            pytest.fail("Module creation failed for package")

    return moduleids

def get_module_for_package(request, init_env, counts):

    moduleids = []
    count = counts["Module"]
    res = request.get(url=init_env + mc.ModuleEndPoint)
    if res.status_code == 200:
            for i in range(0, 100):
                if len(res.json()[i]["dependencies"]) == 0:
                    moduleids.append(res.json()[i]["id"])
    else:
        pytest.fail("Module get/fetch action failed for package")
    # print("Fetched Module ids : " + str(moduleids))
    moduleids = moduleids[0:count+1]
    return moduleids

def create_container_for_package(request, init_env, counts, dependent_values):
    jsonfile = open(mc.create_container_request_payload)
    data = json.load(jsonfile)
    data = update_name_and_version_in_payload(data)
    data = update_container_dependent_values(data, dependent_values)
    print(data)
    containerids = []
    for i in range(0, counts["Container"]):

        res = request.post(init_env + mc.ContainerEndPoint, json=data)
        if res.status_code == 200:
            containerids.append(res.json()["id"])
        else:
            pytest.fail("Container creation failed for package")

    return containerids

def get_container_for_package(request, init_env, counts):
    containerids = []

    res = request.get(url=init_env + mc.ContainerEndPoint)
    if res.status_code == 200:
        for i in range(0, counts["Container"]):
            containerids.append(res.json()[i]["id"])
    else:
        pytest.fail("Container get/fetch action failed for package")
    # print("Fetched Container ids : " + str(containerids))
    return containerids


def create_helmchart_for_package(request, init_env, counts, dependent_values):
    jsonfile = open(mc.create_helmchart_request_payload)
    data = json.load(jsonfile)
    data = update_name_and_version_in_payload(data)
    data = update_helmchart_dependent_values(data, dependent_values)
    print(data)
    helmchartids = []
    for i in range(0, counts["HemlChart"]):
        res = request.post(init_env + mc.HelmChartEndPoint, json=data)
        if res.status_code == 200:
            helmchartids.append(res.json()["id"])
        else:
            pytest.fail("Helmchart creation failed for package")

    return helmchartids

def get_helmchart_for_packages(request, init_env, counts):
    helmchartids = []

    res = request.get(url=init_env + mc.HelmChartEndPoint)
    if res.status_code == 200:
        for i in range(0, counts["HemlChart"]):
            helmchartids.append(res.json()[i]["id"])
    else:
        pytest.fail("helmchart get/fetch action failed for package")
    # print("Fetched helmchart ids : " + str(helmchartids))
    return helmchartids


def create_online_distribution(request, init_env, counts, dependent_values):

    jsonfile = open(mc.create_od_request_payload)
    payload = json.load(jsonfile)
    payload = update_name_and_version_in_payload(payload)
    payload = update_onlinedistribution_dependent_values(payload, dependent_values)
    odids = []
    for i in range(0,counts["OnlineDistribution"]):
        res = request.post(url=init_env + mc.OnlineDistributionEndpoint,json=payload,verify=False)
        if res.status_code==201:
            odids.append(res.json()["id"])
        else:
            pytest.fail("Online Distribution creation failed for package")

    return odids

def get_online_distribution(request, init_env, counts):
    odids = []

    res = request.get(url=init_env + mc.OnlineDistributionEndpoint)
    if res.status_code == 200:
        for i in range(0, counts["OnlineDistribution"]):
            odids.append(res.json()[i]["id"])
    else:
        pytest.fail("OD get/fetch action failed for package")
    # print("Fetched OD ids : " + str(odids))
    return odids

def create_recipeType_for_package(request, init_env):
    recipeTypeid = ""
    jsonfile = open(mc.create_RecipeType_request_payload)
    data = json.load(jsonfile)
    data = update_name_in_payload(data)
    print(data)
    res = request.post(init_env + mc.RecipeTypeEndPoint, json=data)
    if res.status_code == 200:
        recipeTypeid = res.json()["id"]
    else:
        pytest.fail("Module creation failed for package")

    return recipeTypeid