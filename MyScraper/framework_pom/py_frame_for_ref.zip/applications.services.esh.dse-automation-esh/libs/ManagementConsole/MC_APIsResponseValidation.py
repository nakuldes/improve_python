import pytest

from configs import ManagementConsole as mc
import json
from jsonschema import validate, ValidationError, SchemaError


def getJSONSchema(data, dataKey):
    with open(mc.jsonschema_filename, 'r') as f:
        schema_data = f.read()
    schema = json.loads(schema_data)
    ret_status = True
    validate_schema = schema[dataKey]
    try:
        validate(instance=data, schema=validate_schema)
    except SchemaError as e:
        print("There is an error with the schema")
        ret_status = False
    except ValidationError as e:
        print(e)
        ret_status = False
    except BaseException as error:
        print(error)
        ret_status = False
    return ret_status


def validateJSONFieldData(response, expected_response):
    assert response == expected_response


def validate_mc_api_response_data(response_code, response_json, message_code, message):
    if response_code == 200:
        assert response_json["messageCode"] == message_code, response_json["messageCode"]
        assert response_json["message"] == message, response_json["message"]
    else:

        if message_code != "" and (message_code not in str(response_json)):
            pytest.fail(
                "Message code is not correct in response -- " + str(response_json))
        if message != "" and (message not in str(response_json)):
            pytest.fail("Message is not correct in response -- " + message +
                        " is not present in response which is : " + str(response_json))
def validate_module_response_json(response_json, data):

    jenkinFilePath = "https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Modules/job/" + data["name"]["en"].strip()
    if response_json["data"]["fullJenkinsPath"] != jenkinFilePath:
        pytest.fail("Jenkin path is not correct in created module.")


def validate_container_response_json(response_json, data, testdata):

    jenkinFilePath = ""
    if (data["registryType"] == "intelpublic" or data["registryType"] == "public") and data["imageSourceType"] == "importimage":
        jenkinFilePath = ""
    elif "jenkinpath" in testdata.keys() and data["imageSourceType"] != "importimage":
        jenkinFilePath = "https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Containers/job/" + testdata["jenkinpath"]
    elif data["imageSourceType"] != "importimage":
        jenkinFilePath = "https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Containers/job/" + data["name"]["en"]

    print(response_json["data"]["fullJenkinsPath"])
    print(jenkinFilePath)

    if response_json["data"]["fullJenkinsPath"] != jenkinFilePath:
        pytest.fail("Jenkin path is not correct in created module." + str(response_json["data"]["fullJenkinsPath"]))

def validate_helmchart_response_json(response_json, data):
    jenkinFilePath = ""
    if (data["registryType"] == "intelpublichelm" or data["registryType"] == "public") == "importHelmChart":
        jenkinFilePath = ""
    elif (data["registryType"]) == "intelprivate":
        jenkinFilePath = "https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Helmcharts/job/" + data["name"]["en"]

    #print(response_json["data"]["fullJenkinsPath"])
    #print(jenkinFilePath)
    if ("fullJenkinsPath" in response_json["data"]) and (response_json["data"]["fullJenkinsPath"] != jenkinFilePath):
        pytest.fail("Jenkins path is not correct in created helmchart." + str(response_json["data"]["fullJenkinsPath"]))


def validate_json_schema(data,dataKey):
    with open(mc.module_jsonschema, 'r') as f:
        schema_data = f.read()
    schema = json.loads(schema_data)
    ret_status = True
    validate_schema=schema[dataKey]
    try:
        validate(instance=data, schema=validate_schema)
    except SchemaError as e:
        print(str(e))
        print("There is an error with the schema")
        ret_status = False
    except ValidationError as e:
        print(e)
        ret_status = False
    except BaseException as error:
        print(error)
        ret_status = False
    return ret_status
