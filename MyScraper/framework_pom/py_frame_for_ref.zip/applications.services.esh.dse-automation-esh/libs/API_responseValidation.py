from configs import ManagementConsole as mc
import json
from jsonschema import validate, ValidationError, SchemaError

def getJSONSchema(data,dataKey):
        with open(mc.jsonschema_filename, 'r') as f:
            schema_data = f.read()
        schema = json.loads(schema_data)
        ret_status = True
        validate_schema=schema[dataKey]
        try:
            validate(instance=data, schema=validate_schema)
        except SchemaError as e:
            print("There is an error with the schema")
            ret_status = False
        except ValidationError as e:
            print(e)
            ret_status = False
        except BaseException as error:
            print(error)
            ret_status = False
        return ret_status

def validateJSONFieldData(response,expected_response):
    assert response == expected_response