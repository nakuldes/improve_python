

def set_Record_Property(record_property, Data, TestType, init_browser="noBrowser"):

    record_property("JIRA_ID",Data["JIRA_ID"])
    record_property("Test_Description",Data["Short_Desc"])
    record_property("Data_Set",Data.values())
    record_property("Test_Type",TestType)
    record_property("Driver",init_browser)
    # print("JIRA_ID -- " + str(Data["JIRA_ID"]))
    # print("Test_Type" + TestType)





