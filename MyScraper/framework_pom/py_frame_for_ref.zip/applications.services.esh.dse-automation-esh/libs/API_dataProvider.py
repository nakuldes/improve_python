import utils
from utils import FileOperations as fo
from configs import ManagementConsole as mc
import requests
from urllib.request import getproxies
import json


# Data Fetch Methods

@staticmethod
def get_Create_Module_Data():
    createmoduledata = fo.File_Operations().get_json_file_data(mc.file_path_create_Module_JSON)
    return createmoduledata


@staticmethod
def get_Update_Module_Data():
    data_Update_Module = fo.File_Operations().get_csv_data(mc.modules_data_file, "UPDATE")
    return data_Update_Module


@staticmethod
def get_Parameters():
    parameterlist = mc.modules_columns_list
    return parameterlist


def getRecipeData(pkg_uuid=None, detail="?detail=true"):
    data = None
    if pkg_uuid is not None:
        response = requests.get(mc.SERVICE_LAYER_HOST + "/recipe/" + pkg_uuid + detail,
                                headers={'Content-Type': 'application/json'},
                                proxies=getproxies(),
                                verify=False)
    data = response.json()
    return data


def getRecipeVersionsByName(package_name, selectedRecipeVersion=None, sl_url=None):
    json_data = None
    response = requests.get(mc.SERVICE_LAYER_HOST + "/recipe/getAllVersionByName/" + package_name,
                            headers={'Content-Type': 'application/json'},
                            verify=False,
                            proxies=getproxies())
    data = response.json()
    is_version_found = False
    if selectedRecipeVersion is not None:
        for key in data:
            if key['version'] == selectedRecipeVersion:
                json_data = key
                is_version_found = True
                break
        if is_version_found is False:
            print("Package Version {0} NOT FOUND".format(selectedRecipeVersion))
    else:
        json_data = data
    return json_data


def fetch_package_data():
    pkg_data = []
    with open("testdata/PackageData.json", "r", encoding='utf-8') as outfile:
        pkg_details = json.load(outfile)
    for i in pkg_details:
        package_uuid = getRecipeVersionsByName(i["pkg_name"], i["pkg_version"])['id']
        if package_uuid is not None:
            res = getRecipeData(pkg_uuid=package_uuid)
            data = {"pkg_name": i["pkg_name"],
                    "pkg_uuid": res["id"],
                    "recipe_type_id": res["recipeType"]}
            for j in range(len(res['ingredients'])):
                if 'imageName' in res['ingredients'][j]:
                    data.update({
                        "image_name": res['ingredients'][j]['imageName'],
                        "image_id": res['ingredients'][j]['id'],
                        "image_tag": res['ingredients'][j]['imageTag']})
                    break
        pkg_data.append(data)

    return pkg_data


def fetch_ingredient_data():
    data = []
    ingredient_data = requests.get(mc.SERVICE_LAYER_HOST + "/ingredient/all",
                                   headers={'Content-Type': 'application/json'},
                                   verify=False)
    JSON_ingredient = ingredient_data.json()
    if JSON_ingredient is None:
        print("API Data is NULL.  Looks Package Version Not Found")
    if JSON_ingredient is not None:
        for i in range(len(JSON_ingredient)):
            if (('en', "ESB common") in JSON_ingredient[i]['name'].items() and ('en', 'ubuntu 20.04')
                    in JSON_ingredient[i]['displayName'].items()):
                data = {"module_uuid": JSON_ingredient[i]['id'],
                        "md5sum_value": JSON_ingredient[i]['hashValue'],
                        "product_key": "ffcbe14a-7911-4a59-9fcb-ffa6ed4c9241"}
    return data
