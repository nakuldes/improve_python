import json
import pandas as pd
import yaml
import platform
import os

class File_Operations():

    def get_csv_data(self,path,filter=None):
        try:
            if platform == "linux" or platform == "linux2":
                data = pd.read_csv(path, )
            elif platform == "win32":
                data = pd.read_csv(path)
                # print("in file operations")
                # print(data.head())
        except Exception as e:
            print("Error occured while reading CSV file .. " + str(e))
        if filter!=None:
            data=data[data["Filter_Citeria"] == filter]

        data.drop('Filter_Citeria', axis=1, inplace=True)
        data = data.values.tolist()
        return data

    def get_csv_data_as_Dataframe(self,path,filter=None,Encoding=None):
        if(Encoding!=None):
            data = pd.read_csv(path,encoding=Encoding)
        else:
            data = pd.read_csv(path)
        print("in file operations")
        print(data.head())
        if filter!=None:
            data=data[data["Filter_Citeria"] == filter]

        data.drop('Filter_Citeria', axis=1, inplace=True)
        # data = data.values.tolist()
        return data

    @staticmethod
    def get_json_file_data(path):

        jsonfile = open(path,encoding="utf-8-sig")
        data=json.load(jsonfile)
        return data

    def get_yaml_file_data(self,path):

        yamlfile = open(path)
        data = yaml.safe_load(yamlfile)
        yamlfile.close()
        return data
   
    
    def get_json_file_filtered_data(self,path,type):
        jsonfile = open(path, encoding='utf8')
        data=json.load(jsonfile)
        filtered_data = [x for x in data if x['test_type'] == type]
        return filtered_data
    
    @staticmethod
    def verify_file_download(zip_file_name):
        hm = str(Path.home())
        file_location = hm + "/Downloads/" + zip_file_name
        return True if (os.path.exists(file_location)) else False

