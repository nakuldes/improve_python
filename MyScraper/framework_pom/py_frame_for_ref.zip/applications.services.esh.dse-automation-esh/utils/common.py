import datetime
import configparser


def get_Current_TimeStamp():
    # print(datetime.datetime.now())
    date, time = str(datetime.datetime.now()).split(" ")
    date = date.split("-")
    time = time.split(":")
    finaldate=""
    for i in date:
        finaldate= finaldate + i
    for j in time:
        finaldate = finaldate + j
    finaldate1, finaldate2 = finaldate.split(".")
    return (finaldate1+finaldate2)
    #return(finaldate.split(".")[0])


# def create_ResultDir():
#     # global resultDir, screenshotDir
#     os.mkdir(self.resultDir)
#     os.mkdir(self.screenshotDir)
#     # return resultDir, sc

def get_credentials():
    print("Reading credentials file....")
    try:
        config = configparser.ConfigParser()
        config.read("configs/credentials.ini")
        print("Successfuly fetched the credentials....")
    except Exception as e:
        print("exception while reading credentials.. " + str(e))
    return config
