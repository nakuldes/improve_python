"""MANAGED SERVICES DETAILS """
amrRegistryUrl = 'https://amr-fm-registry.caas.intel.com/'


# Datafile paths
file_path_create_dockerimage_JSON = "testdata/ms_api/CreateImageAPI.json"
file_path_create_helmchart_JSON = "testdata/ms_api/CreateHelmChartAPI.json"
file_path_validateDocker_SingleImage= "testdata/ms_api/ValidateDockerAPISingleImage.yaml"
file_path_validateDocker_MultipleImageWithAllFail= "testdata/ms_api/ValidateDockerAPIMultipleImageWithAllFail.yaml"
file_path_validateDocker_CommposeFile= "testdata/ms_api/ValidateDockerAPIComposeFile.yaml"
file_path_validateDocker_InvalidDockerRepo= "testdata/ms_api/ValidateDockerInvalidDockerRepo.yaml"
file_path_testdata_BuildPypi= "testdata/ms_api/BuildPypi.csv"
file_path_bom_license = "testdata/ms_api/BOMLicense/Bom_License.json"