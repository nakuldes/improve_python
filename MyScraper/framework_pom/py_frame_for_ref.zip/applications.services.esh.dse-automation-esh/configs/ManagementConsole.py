"""MANAGEMENT CONSOLE DETAILS """

# URLs
MC_QA = "https://mc-qa.intel.com/"
MC_DEV = "https://mc-dev.intel.com/"
# MC_API_HOST_QA = "https://mc-api-qa.intel.com"
MC_API_HOST_QA = "https://mc-qa.intel.com"
SERVICE_LAYER_HOST = "https://eshqaservicelayer.intel.com"

""" Packages Data file paths """
packages_data_file = "testdata/management_console_gui/PackageUI.csv"
file_path_create_Packages_JSON = "testdata/management_console_api/Packages/PackagesAPI.json"
file_path_create_Packages_OD_JSON = "testdata/management_console_api/Packages/PackagesODAPI.json"
create_package_request_payload = "testdata/management_console_api/Packages/PackageCreateRequest.json"
create_od_package_request_payload= "testdata/management_console_api/Packages/PackageODCreateRequest.json"

""" Modules Data file paths """
modules_data_file = "testdata/management_console_gui/ModuleUI.csv"
file_path_create_Module_JSON = "testdata/management_console_api/Modules/ModulesAPI.json"
module_jsonschema = "testdata/management_console_api/Modules/ModuleResponseJsonSchema.json"
create_module_request_payload = "testdata/management_console_api/Modules/ModuleCreateRequest.json"


""" Container Data file paths """
containers_data_file = "testdata/management_console_gui/ContainerUI.csv"
file_path_create_Container_JSON = "testdata/management_console_api/Containers/ContainerAPI.json"
create_container_request_payload = "testdata/management_console_api/Containers/ContainerCreateRequest.json"

""" HelmChart Data file paths """
helm_data_file = "testdata/management_console_gui/HelmChartUI.csv"
file_path_create_Helmchart_JSON = "testdata/management_console_api/HelmCharts/HelmchartAPI.json"
create_helmchart_request_payload = "testdata/management_console_api/HelmCharts/HelmchartCreateRequest.json"

""" Online Distribution Data file paths """
od_data_file = "testdata/management_console_gui/odTestData.csv"
file_path_create_OnlineDistribution_JSON = "testdata/management_console_api/OnlineDistribution/OnlineDistributionAPI.json"
create_od_request_payload = "testdata/management_console_api/OnlineDistribution/OnlineDistributionCreateRequest.json"

""" End to End Data file paths """
e2e_data_file = "testdata/management_console_gui/E2E.csv"

"""RecipeType Path"""
file_path_create_RecipeType_JSON="testdata/management_console_api/RecipeType/RecipeType.json"
create_RecipeType_request_payload = "testdata/management_console_api/RecipeType/RecipeTypeCreateRequest.json"

""" Common """
# File path to store Dependent Values/IDs for Management Console APIs
dependent_values_api = "testdata/management_console_api/api_dependent_data.json"


data_filepath = "testdata/data.json"

# JSON Schema for validation
jsonschema_filename = "testdata/JsonSchema.json"

# Documentation File 
documentation_file_upload = "testdata/sample_documentation_file.txt"
# ReadMe File 
readme_file_upload = "testdata/sample_readme_file.txt"


helmcharts_column_list = ["JIRA_ID", "Short_Desc", "Execution", "Scenario_Type", "Language", "Name", "Display_Name",
                          "Description", "More_Info", "Version_Number", "HelmChart_Name", "Dependency_Type", "Git_Path",
                          "Custom_Branch", "Branch_Name", "More_Info_Link", "Release_Tag", "Unsupported_Countries",
                          "Compatible_OS"]

resp = ["name", "displayName", ]

#Management COnsole APIs Endpoints
PackageEndPoint = "/recipe/"
ModuleEndPoint = "/ingredient/"
ContainerEndPoint = "/container/"
HelmChartEndPoint = "/helmchart/"
OnlineDistributionEndpoint = "/distribution/"
RecipeTypeEndPoint = "/recipe/recipeType/"




