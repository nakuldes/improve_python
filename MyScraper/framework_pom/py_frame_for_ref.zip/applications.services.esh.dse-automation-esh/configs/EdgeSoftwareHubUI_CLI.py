"""MANAGEMENT CONSOLE DETAILS """

# URLs
import utils.common

MC_QA = "https://mc-qa.intel.com/"
MC_DEV = "https://mc-dev.intel.com/"

# Datafile paths
downloadDir = "applications.services.esh.dse-automation-esh/testdata/downloadedPackages"
packagesDataFile = "testdata/selector_tool_ui/Packages.csv"


""" ESH/SELECTOR UI DETAILS """
# URLS  :
# ESH_QA = "https://mc-qa-esh-ui.apps1-ir-int.icloud.intel.com/iot/edgesoftwarehub/download/home/"
ESH_QA = "https://eshqawebui.intel.com/iot/edgesoftwarehub/download/home/"
ESH_DEV = ""

cli_binaryname="edgesoftware"
cli_list="list"
cli_download="download"
cli_export="export"
cli_upgrade="upgrade"
cli_install="install"
cli_uninstall="uninstall -a"
cli_log="log"
cli_update="update"
cli_log_basepath="/var/log/esb-cli"
cli_install_status_filename="install_status.json"
cli_help="--help"
cli_pull="docker --pull"
cli_version="--version"
helm_install="helm install --generate-name"
pypi_binaryname="edgesoftware"
pypi_binaryversion="1.0.0"

#Fetch the credentials
var_credentials = utils.common.get_credentials()
