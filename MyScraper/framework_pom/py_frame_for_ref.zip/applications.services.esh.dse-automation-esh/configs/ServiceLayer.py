SERVICE_LAYER_HOST = "https://eshqaservicelayer.intel.com"

#Recipe_payload
pkg_uuid="60239f20df3856002cb2952c"
recipe_name="Driver Behavior Analytics"
recipe_type_id="5f2ba8570c6523002a9dba1b"

#Docker_payload
image_id="5e58948ae16686023a807db1"
img_productKey="148baa3e-f16a-47e5-ad73-950bc6caa9b3"
image_name="amr-ubuntu2004-ros2-foxy-sdk"
image_tag="2021.2"

#Ingredient_payload
module_uuid="601b5edc3eb151002ace2bf1"
md5sum_value="7fa8bed69eaff9842944a24faf00e929"
product_key="ffcbe14a-7911-4a59-9fcb-ffa6ed4c9241"


data_filepath = "testdata/data.json"
download_dir = "testResults"