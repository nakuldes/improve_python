import pytest
from selenium.webdriver.common.by import By
from .BasePage import WebActions
from selenium.webdriver.support.ui import WebDriverWait
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from utils import FileOperations as fo
from configs import ManagementConsole as mc
import json
import utils.common


class ContainerActions(WebActions):

    def __init__(self, driver):
        super().__init__(driver)


    """ Page Locators """

    CONTAINERS_LINK = (By.XPATH,"//span[contains(text(),'Containers')]")
    CONTAINERS_PROMOTE_COLUMN = (By.XPATH, "//thead[@data-test='datatable-head']/tr/th/span[contains(text(), 'Promote')]")
    CONTAINERS_BUTTON_CREATE_NEW = (By.XPATH,"//span[contains(text(),'Create Container')]")
    CONTAINERS_TEXT_NAME = (By.NAME, "imageName")
    CONTAINERS_TEXT_DISPLAY_NAME = (By.NAME, "displayName")
    CONTAINERS_TEXT_DESCRIPTION = (By.NAME, "imageDesc")
    CONTAINERS_TEXT_MORE_INFO = (By.XPATH, "//body[@id='tinymce']")

    CONTAINERS_BUTTON_TRANSLATION = (By.XPATH, "//form/div/fieldset[@class='multiLingCard'][1]//button[contains(text(), 'Add Translation')]")
    CONTAINERS_SELECT_LANGUAGE = (By.XPATH, "//form/div/fieldset[2]//select")
    CONTAINERS_SELECT_LANGUAGE_CHINESE = (By.XPATH, "//option[@value='ch']")
    CONTAINERS_TEXT_CH_NAME = (By.XPATH, "//form/div/fieldset[@class='multiLingCard'][2]//input[@name='imageName']")
    CONTAINERS_TEXT_CH_DISPLAY_NAME = (By.XPATH, "//form/div/fieldset[@class='multiLingCard'][2]//input[@name='displayName']")
    CONTAINERS_TEXT_CH_DESCRIPTION = (By.XPATH, "//form/div/fieldset[@class='multiLingCard'][2]//textarea[@name='imageDesc']")
    #CONTAINERS_TEXT_CH_MORE_INFO = (By.XPATH, "//body[@data-id='tiny-react_63257841111649232473361']")
    CONTAINERS_TEXT_CH_MORE_INFO = (By.XPATH, "//body[@class='mce-content-body ']")

    
    #CONTAINERS_REGISTRY_RADIO_BUTTON= (By.NAME, "registryType")
    CONTAINERS_REGISTRY_DROPDOWN_BUTTON= (By.NAME, "registryType")
    CONTAINERS_REGISTRY_PUBLIC =(By.XPATH, "//option[contains(text(), 'Intel Public Registry')]")
    CONTAINERS_REGISTRY_OTHER =(By.XPATH, "//option[contains(text(), 'Other Public Registry')]")
    CONTAINERS_REGISTRY_PRIVATE =(By.XPATH, "//option[contains(text(), 'Intel Private Registry')]")
    CONTAINERS_METHOD_BUILD = (By.XPATH, "//input[@value='buildimage']/..")
    CONTAINERS_METHOD_IMPORT = (By.XPATH, "//input[@value='importimage']/..")
    CONTAINERS_TEXT_VERSION_NAME = (By.XPATH, "//fieldset[@class='multiLingCard']/div[3]/div[3]/span[1]/input")
    CONTAINERS_TEXT_IMAGE_NAME = (By.XPATH, "//fieldset[@class='multiLingCard']/div[3]/div[3]/span[2]/input")

    #CONTAINERS_TEXT_IMAGE_NAME = (By.NAME, "containerImageName")
    CONTAINERS_TEXT_BASE_IMAGE = (By.XPATH, "//fieldset/div[3]/div[5]/span/input[@name='baseImage']")
    CONTAINERS_SELECT_DEPENDENCY_TYPE = (By.XPATH, "//fieldset/div[3]/div[4]/span[1]/select")
    CONTAINERS_SELECT_DEPENDENCY_TYPE_PUBLIC = (By.XPATH, "//span[1]/select[@name= 'ingredientType']")
    CONTAINERS_TEXT_GIT_PATH = (By.NAME,"fullGitlabPath")
    CONTAINERS_CUSTOM_BRANCH_YES = (By.XPATH, "//input[@name='isbranch-yes']")
    CONTAINERS_RADIO_CUSTOM_BRANCH = (By.XPATH, "//input[@name='branch']")

    #CONTAINERS_TEXT_MORE_INFO_LINK = (By.NAME, "moreInfoLink")
    CONTAINERS_TEXT_MORE_INFO_LINK = (By.NAME, "//fieldset/div[3]/div[4]/span[2]/input")
    CONTAINERS_TEXT_RELEASE_TAG = (By.NAME, "releaseTag")
    CONTAINERS_TEXT_FOLDER_NAME = (By.NAME, "label")
    CONTAINERS_TEXT_JENKINS_PATH = (By.XPATH, "//tbody[@data-test='table-body']/tr[1]/td[7]/span/a")
    CONTAINERS_TEXT_BRANCH = (By.NAME, "branch")
    CONTAINERS_RADIO_DEFAULT_INSTALLATION = (By.NAME, "")
    CONTAINERS_RADIO_DISABLE_JENKINS = (By.NAME, "")
    CONTAINERS_UNSUPPORTED_COUNTRIES_DROP_DOWN_ICON = (By.CLASS_NAME, "dropdown icon")
    CONTAINERS_UNSUPPORTED_COUNTRIES = (By.XPATH, "//div[@class='recipeOwnerDropdown']/div/div[contains(text(), 'Add countries')]")
    
    
    CONTAINERS_ADDCOMPATIBLE_OS_ADD = (By.XPATH,"//span[contains(text(), 'Compatible OS')]/parent::div/div/span")
    CONTAINERS_ADDCOMPATIBLE_OS_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    CONTAINERS_ADDCOMPATIBLE_OS_TABLE = (By.XPATH,"//tbody")
    CONTAINERS_ADDCOMPATIBLE_OS_FIRST_CHECK = (By.XPATH,"//tbody/tr[1]/td[1]/div/span")
    CONTAINERS_ADDCOMPATIBLE_OS_ADD_LIST = (By.CSS_SELECTOR,".buttonClass:nth-child(2) > span")
    CONTAINERS_CANCEL_ADD_RESOURCES = (By.XPATH, "//button[@class='buttonClass cancelbuttonClass marginTop']")

    # Filter Tag field
    FILTERTAG_NAME = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder='Name in English']")
    FILTERTAG_HELP = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder=' Add Help Text Here.']")
    SELECT_FILTERTAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/input")
    SELECT_FILTER_TAG_DROPDOWN = (By.XPATH, "//div[@role='combobox']/div[contains(text(), 'Tags')]")
    DELETE_EXISTING_FILTER_TAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")

    CONTAINERS_TEXT_INSTALLATION_CMD = (By.XPATH, "//textarea[@name='consumption']")
    CONTAINERS_TEXT_CO_OWNERS = (By.XPATH, "//span[contains(text(), 'Co-Owners')]/../..//input")
    CONTAINERS_ADD_CO_OWNERS = (By.XPATH, "//div[contains(text(), 'Add Users')]/parent::div/div[@class='visible menu transition']/div")
    CONTAINERS_VERIFY_CO_OWNERS = (By.XPATH, "//div/span[contains(text(), 'Co-Owners')]/../../div[@class='recipeOwnerDropdown']/div[@role='combobox']/a")

    CONTAINERS_VERIFY_CO_OWNERS = (By.XPATH, "//div/span[contains(text(), 'Co-Owners')]/../../div[@class='recipeOwnerDropdown']/div[@role='combobox']/a")
    CONTAINERS_SAVE = (By.XPATH,"//span[contains(text(),'Save Container')]")
    CONTAINERS_CANCEL = (By.XPATH,"//button[@class='buttonClass cancelbuttonClass']/span[contains(.,'Cancel')]")
    CONTAINERS_POPUP_YES = (By.XPATH,"//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/button[2]/span[1]")
    CONTAINERS_POPUP_CLOSE = (By.XPATH, "//div[@class='modal-content']//span[contains(text(), 'Close')]")

    # TOAST MESSAGE
    CONTAINER_SAVE_SUCCESS_MESSAGE = (By.XPATH, "//span[@class='toast_submsg']")

    # ACTIONS
    COMMON_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    CONTAINERS_ACTION_OPTION = (By.CLASS_NAME,"ui dropdown  text-primary ")
    EDIT_ACTION = (By.XPATH,"//span[contains(text(),'Edit')]")
    DELETE_ACTION = (By.XPATH,"//span[contains(text(),'Delete')]")
    CLONE_ACTION = (By.XPATH,"//span[contains(text(),'Clone')]")
    PROMOTE_ACTION = (By.XPATH, "//button/span[contains(text(), 'Promote')]")
    READ_EXISTING_NAME_FROM_TABLE = (By.XPATH, '//tbody[@data-test="table-body"]/tr[1]/td[1]/span')

    # ERROR RECOVERY
    CONTAINERS_CANCEL_SAVE = (By.XPATH,"//span[contains(text(),'Cancel')]")
    CONTAINERS_POPUP_YES_BUTTON = (By.XPATH,"//button/span[contains(text(),'Yes')]")

    # READ FORM DATA
    READ_COMPATIBLE_OS = ''


    """ Containers Page Actions """

    def navigate_to_Containers_Page(self):
        self.element_click(self.CONTAINERS_LINK)

        #time.sleep(5)
        self.wait_loader_to_vanish()

    def navigate_to_Create_Container(self):
        self.element_click(self.CONTAINERS_BUTTON_CREATE_NEW)
        time.sleep(10)
    
    def read_container_name_from_section(self):
        self.wait_loader_to_vanish()
        name_of_existing_package = self.element_get_text(self.READ_EXISTING_NAME_FROM_TABLE)

        return name_of_existing_package

    def enter_Name(self,name):
        self.element_set_text(self.CONTAINERS_TEXT_NAME, name)

    def enter_Display_Name(self, displayname):
        self.element_set_text(self.CONTAINERS_TEXT_DISPLAY_NAME,displayname)

    def enter_Discription(self,description):
        self.element_set_text(self.CONTAINERS_TEXT_DESCRIPTION, description)

    def enter_More_Info(self,moreinfo):
        self.element_set_text_textarea(self.CONTAINERS_TEXT_MORE_INFO, moreinfo)

    def select_add_Translation(self):
        self.element_click(self.CONTAINERS_BUTTON_TRANSLATION)

    def select_launguage(self, language):
        self.element_click(self.CONTAINERS_SELECT_LANGUAGE)
        time.sleep(2)
        self.element_click(self.CONTAINERS_SELECT_LANGUAGE_CHINESE)

    def enter_Name_Ch(self,name):
        self.element_set_text(self.CONTAINERS_TEXT_CH_NAME, name)

    def enter_Display_Name_Ch(self, displayname):
        self.element_set_text(self.CONTAINERS_TEXT_CH_DISPLAY_NAME,displayname)

    def enter_Discription_Ch(self,description):
        self.element_set_text(self.CONTAINERS_TEXT_CH_DESCRIPTION, description)

    def enter_More_Info_Ch(self,moreinfo):
        self.element_set_text_textarea(self.CONTAINERS_TEXT_CH_MORE_INFO, moreinfo)

        
    def select_method_import(self):
        self.element_click(self.CONTAINERS_METHOD_IMPORT)

    def select_method_build(self):
        self.element_click(self.CONTAINERS_METHOD_BUILD)
        
            
    def enter_Version_Name(self,version, required_clear=False):
        self.action_chain_enter_text(self.CONTAINERS_TEXT_VERSION_NAME, version)

    def enter_Image_Name(self, imagename, required_clear=False):
        self.element_set_text(self.CONTAINERS_TEXT_IMAGE_NAME,imagename, required_clear)

    def enter_Base_Image(self,baseimg, required_clear=False):
        self.element_set_text(self.CONTAINERS_TEXT_BASE_IMAGE, baseimg, required_clear)

    def select_Compatible_OS(self, searchstring=None):
        self.element_click(self.CONTAINERS_ADDCOMPATIBLE_OS_ADD)
        time.sleep(3)
        if(searchstring != None):
            self.element_set_text(self.CONTAINERS_ADDCOMPATIBLE_OS_SEARCH, searchstring)
            time.sleep(2)
            self.element_click(self.CONTAINERS_ADDCOMPATIBLE_OS_FIRST_CHECK)
        elif(searchstring == None):
            self.element_click(self.CONTAINERS_CANCEL_ADD_RESOURCES)
            return
        else:
            self.element_click(self.CONTAINERS_ADDCOMPATIBLE_OS_FIRST_CHECK)
        self.element_click(self.CONTAINERS_ADDCOMPATIBLE_OS_ADD_LIST)

    def select_Dependency_Type(self, dependency):
        dropdw = Select(WebDriverWait(self.driver,20).until(EC.presence_of_element_located(self.CONTAINERS_SELECT_DEPENDENCY_TYPE)))
        dropdw.select_by_visible_text("AUTO_MC_0015")

    def select_Dependency_Type_public(self, dependency):
        dropdw = Select(WebDriverWait(self.driver,20).until(EC.presence_of_element_located(self.CONTAINERS_SELECT_DEPENDENCY_TYPE_PUBLIC)))
        dropdw.select_by_visible_text("AUTO_MC_0015")
    
    def enter_GIT_Path(self,gitpath):
        self.element_set_text(self.CONTAINERS_TEXT_GIT_PATH, gitpath)

    def select_Custom_Branch(self, option,branchname=None):
        print("")
        if(option.upper() == "YES"):
            self.element_click(self.CONTAINERS_CUSTOM_BRANCH_YES)
            self.element_set_text(self.CONTAINERS_RADIO_CUSTOM_BRANCH,branchname)
    
    def select_Registry_Type(self, option):
        print("selecting {0} registry".format(option))
        self.element_click(self.CONTAINERS_REGISTRY_DROPDOWN_BUTTON)
        if(option.upper() == "PUBLIC"):
            self.element_click(self.CONTAINERS_REGISTRY_PUBLIC)
        elif(option.upper() == "OTHER"):
            self.element_click(self.CONTAINERS_REGISTRY_OTHER)
        else:
            self.element_click(self.CONTAINERS_REGISTRY_PRIVATE)

    def get_elements_list(self,locator):
        elementslist = self.driver.find_elements(By.NAME, "registryType")
        return elementslist

    def enter_More_Info_Link(self, moreinfolink):
        self.element_set_text(self.CONTAINERS_TEXT_MORE_INFO_LINK, moreinfolink)

    def enter_Release_Tag(self, releasetag, required_clear=False):
        self.element_set_text(self.CONTAINERS_TEXT_RELEASE_TAG, releasetag, required_clear)


    def enter_Installation_Commands(self, installationcmd):
        self.element_set_text(self.CONTAINERS_TEXT_INSTALLATION_CMD, installationcmd)

    def get_Jenkins_Path(self):
        jenkins_url = self.element_get_attribute_value(self.CONTAINERS_TEXT_JENKINS_PATH, 'href')
        return jenkins_url


    def select_Unsupported_Countries(self, country):
        self.page_scroll_to_page_end()
        time.sleep(2)
        self.element_click(self.CONTAINERS_UNSUPPORTED_COUNTRIES)
        time.sleep(3)
        CONTAINERS_COUNTRY_OPTION = (By.XPATH,"//span[contains(text(),'{}')]".format(country))
        self.element_click(CONTAINERS_COUNTRY_OPTION)
        self.press_esc_key()

    def select_filter(self, tag_name):
        '''
        This method deals with filter tags in MC
        *It first deletes the existing filter tag selected if any are there
        *Then adds given number of filter tags
        '''
        return
        #deleting existing filter tags
        try:
            exisitng_filtertags = self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")
            for tag in exisitng_filtertags:
                tag.click()
        except Exception as e:
            # No filter tag found
            print('No exisiting filter tag found.')
        # Adding existing 2 filters
        count = 0
        self.element_click(self.SELECT_FILTER_TAG_DROPDOWN)
        if tag_name == 'existing':
            available_filter_tags =  self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/div/div[@role='option']")
            for wb in available_filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                wb.click()
                count+=1
                if count == 2:
                    break         
        else:
            filter_tags = str(tag_name).split('|')
            for item in filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                ADD_FILTERS_OPTION = (By.XPATH,"//span[contains(text(),'{0}')]".format(item))
                self.element_click(ADD_FILTERS_OPTION)

    def select_Co_Owners(self, Co_Owners):
        self.element_set_text(self.CONTAINERS_TEXT_CO_OWNERS, Co_Owners)
        time.sleep(2)
        self.press_enter_key(self.CONTAINERS_TEXT_CO_OWNERS)
    
    def save_Container(self):
        self.element_click(self.CONTAINERS_SAVE)
        success_msg = self.element_get_text(self.CONTAINER_SAVE_SUCCESS_MESSAGE)
        self.wait_loader_to_vanish()
        return success_msg


    def cancel_Create_Container(self):
        self.element_click(self.CONTAINERS_CANCEL)
        time.sleep(3)
        self.element_click(self.CONTAINERS_POPUP_YES)

    def check_Save_Button_Disables(self):
        try:
            self.element_is_clickable(self.CONTAINERS_SAVE)
            return True
        except:
            return False

    def get_GitHub_JenkinsURLs(self, containername):
        xpath = "//td/span[contains(text(),'"+containername+"')]/ancestor::tr/td[6]/span/a"
        print(xpath)
        elements = self.driver.find_elements(By.XPATH, xpath)
        urls = []
        for i in elements:
            print(i.get_attribute('href'))
            urls.append(i.get_attribute('href'))
        return urls

    def search_Container_And_Perform_Action(self,container_name, action):
        self.element_set_text(self.COMMON_SEARCH,container_name, True)
        elem = (By.XPATH,"//td/span[contains(text(),'" + container_name + "')]/ancestor::tbody/tr[1]//div[@role='listbox']")
        self.element_click(elem)
        if action == "EDIT":
            self.element_click(self.EDIT_ACTION)
        elif action == "DELETE":
            self.element_click(self.DELETE_ACTION)
        elif action == "TRIGGER BUILD":
            initialstatus = self.element_get_text(self.GET_BUILD_STATUS)
            self.element_click(self.TRIGGER_BUILD_ACTION)
            time.sleep(4)
            currentstatus = self.element_get_text(self.GET_BUILD_STATUS)
            print("Build status after build trigger :  " + currentstatus)
            self.element_click(self.GET_BUILD_STATUS_REFRESH)
            time.sleep(3)
            currentstatus = self.element_get_text(self.GET_BUILD_STATUS)
            print("Build status after refresh :  " + currentstatus)
        elif action == "PROMOTE":
            elem = (By.XPATH,"//td/span[contains(text(),'"+container_name +"')]/../..//span[contains(text(), 'Promote')]")
            self.element_click(elem)
        elif action == "CLONE":
            self.element_click(self.CLONE_ACTION)
        time.sleep(3)

    
    def check_ContainerNameDisabled(self):
        return self.element_get_attribute_value(self.CONTAINERS_TEXT_NAME,"readonly")

    def check_RegistryRadioVisibility(self):
        count = self.get_elements_list(self.CONTAINERS_REGISTRY_RADIO_BUTTON)
        if len(count) == 3:
            return True
        else:
            return False

    def check_PromoteColumnVisibility(self):
        self.element_visible(self.CONTAINERS_PROMOTE_COLUMN)
        # TODO: Add screenshot capture here
    
    def click_Popup_Close_Button(self):
        self.element_click(self.CONTAINERS_POPUP_CLOSE)
        time.sleep(10)

    def click_Popup_Yes_Button(self):
        self.element_click(self.CONTAINERS_POPUP_YES)

    def read_toast_message(self):
        success_msg = self.element_get_text(self.CONTAINER_SAVE_SUCCESS_MESSAGE)
        return success_msg

    def verify_Co_Owners(self, co_owner):
        current_owner = self.element_get_text(self.CONTAINERS_VERIFY_CO_OWNERS)
        if current_owner == co_owner:
            return True
        else:
            return False
    
    def search_Container(self,container_name):
        self.element_set_text(self.COMMON_SEARCH,container_name, required_clear=True)

    def toast_msg_close(self):
        items = self.driver.find_elements(By.XPATH, "//div[@class='Toastify']/div/div/button[@aria-label='close']")
        for item in items:
            item.click()
            time.sleep(1)

    def error_recovery(self):
        try:
            self.toast_msg_close()
        except Exception as e:
            pass
        try:
            self.element_click_fast(self.CONTAINERS_CANCEL_SAVE)
        except Exception as e:
            pass
        try:
            self.element_click_fast(self.CONTAINERS_POPUP_YES_BUTTON)
        except Exception as e:
            pass
        try:
            self.element_set_text(self.COMMON_SEARCH, '', True)
        except Exception as e:
            pass

    def promote_Container(self, container_name, promote_env):
        elem = (By.XPATH,"//td/span[contains(text(),'"+container_name +"')]/../..//span[contains(text(), 'Promote')]")
        self.element_click(elem)
        time.sleep(5)
        env_dropdown = (By.XPATH, "//option[. = '{}']".format(promote_env))
        self.element_click(env_dropdown)
        self.element_click(self.CONTAINERS_ACTION_PROMOTE)

        time.sleep(10)

    def enter_Create_Container_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()

        container_name = TestData["Name"] + uniquestr if(str(TestData["Name"]) != "None") else ""
        if not container_name.startswith('Auto_'):
            if container_name.startswith('Existing'):
                container_name = self.read_container_name_from_section()

        print("TestData")
        print(TestData["Name"])


        self.navigate_to_Containers_Page()
        self.check_PromoteColumnVisibility()
        self.navigate_to_Create_Container()
        self.enter_Name(container_name)          
        self.enter_Display_Name(TestData["Display_Name"]+uniquestr)
        self.enter_Discription( TestData["Description"]+uniquestr)
        #self.enter_More_Info(TestData["More_Info"])
        
        # Add Translations(Chinese)
        if (TestData["Add_Translation"]).upper() == 'YES':
            self.select_add_Translation()
            self.select_launguage('ch')
            self.enter_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Display_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Discription_Ch( TestData["Description"]+uniquestr if (str(TestData["Description"])!= "None") else "")
            #self.enter_More_Info_Ch('包裹_')
        
        if (TestData["Method"]).upper() == 'BUILD':
            self.select_method_build()
        else:
            self.select_method_import()
            self.select_Registry_Type(TestData["Registry_Type"])
            self.enter_Version_Name( TestData["Version_Number"]+uniquestr if (str(TestData["Version_Number"])!= "None") else "" )
            self.enter_Image_Name(TestData["Image_Name"])
            #self.enter_More_Info_Link(TestData["More_Info_Link"])


        # Validating if Registry Radio Buttons are visible
        # TODO: Result of Radio button validation needs to be added in the Report
        #self.check_RegistryRadioVisibility()

    
        if ((TestData["Registry_Type"]).upper() == "PRIVATE"):
            self.enter_Base_Image(TestData["Base_Image"])
            #self.enter_GIT_Path(TestData["Git_Path"])
            # self.select_Custom_Branch(TestData["Custom_Branch"], TestData["Branch_Name"])
            # self.enter_Release_Tag( TestData["Release_Tag"]+uniquestr if (str(TestData["Release_Tag"])!= "None") else "")
        
        self.select_Dependency_Type(TestData["Dependency_Type"])
        
        self.enter_Installation_Commands(TestData["Installation_Commands"])
        self.select_Compatible_OS(TestData["Compatible_OS"])
        self.select_Unsupported_Countries(TestData["Unsupported_Countries"])
        self.select_filter(TestData["Filter"])
        self.select_Co_Owners(TestData["Co_Owners"])
        return container_name

    def enter_Clone_Container_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()
        container_name = 'AUTO_CLONED_'+uniquestr
        self.enter_Name(container_name)
        # containers.enter_Display_Name( Display_Name+uniquestr if (str(Display_Name)!= "None") else "")
        # containers.enter_Discription( Description+uniquestr if (str(Description)!= "None") else "")
        self.enter_More_Info(TestData["More_Info"])       
        # Add Translations(Chinese)
        if (TestData["Add_Translation"]).upper() == 'YES':
            self.select_add_Translation()
            self.select_launguage('ch')
            self.enter_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Display_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Discription_Ch( TestData["Description"]+uniquestr if (str(TestData["Description"])!= "None") else "")
            #self.enter_More_Info_Ch('包裹_')
        if (TestData["Method"]).upper() == 'BUILD':
            self.select_method_build()
        else:
            self.select_method_import()
            self.select_Registry_Type(TestData["Registry_Type"])
            self.enter_Version_Name( TestData["Version_Number"]+uniquestr if (str(TestData["Version_Number"])!= "None") else "" )
            self.enter_Image_Name(TestData["Image_Name"])
            #self.enter_More_Info_Link(TestData["More_Info_Link"])
        # Validating if Registry Radio Buttons are visible
        # TODO: Result of Radio button validation needs to be added in the Report
        #self.check_RegistryRadioVisibility()
        if ((TestData["Registry_Type"]).upper() == "PRIVATE"):
            self.enter_Base_Image(TestData["Base_Image"])
            #self.enter_GIT_Path(TestData["Git_Path"])
            # self.select_Custom_Branch(TestData["Custom_Branch"], TestData["Branch_Name"])
            # self.enter_Release_Tag( TestData["Release_Tag"]+uniquestr if (str(TestData["Release_Tag"])!= "None") else "")      
        self.select_Dependency_Type(TestData["Dependency_Type"])       
        self.enter_Installation_Commands(TestData["Installation_Commands"])
        self.select_Compatible_OS(TestData["Compatible_OS"])
        #self.select_Unsupported_Countries(TestData["Unsupported_Countries"])
        self.select_filter(TestData["Filter"])
        self.select_Co_Owners(TestData["Co_Owners"])
        return container_name

    def read_Container_Data(self, TestData):
        '''This Method reads data from cloned container
        also verifies it against data from CSV'''
        try:
            print("TestData")
            print(TestData["Name"])

            data_from_clone = {}
            keys_to_be_compared = ('Installation_Commands', 'Compatible_OS', 'Version_Number', 'Image_Name', 'Base_Image', 'Co_Owners')

            #data_from_clone['Name'] = self.element_get_text_by_value(self.CONTAINERS_TEXT_NAME)
            data_from_clone['Installation_Commands'] = self.element_get_attribute_value(self.CONTAINERS_TEXT_INSTALLATION_CMD)
            data_from_clone['Compatible_OS'] = self.element_get_text((By.CLASS_NAME, "dependencyClassesHeading"))

            # items = WebDriverWait(self.driver, 20).until(EC.visibility_of_all_elements_located((By.CLASS_NAME, "dependencyClassesHeading")))

            # for i in items:
            #     vl = i.get_attribute("value")
            #     dataFromClone['Compatible_OS'] += vl
    
            data_from_clone['Version_Number']= self.element_get_attribute_value(self.CONTAINERS_TEXT_VERSION_NAME)
            data_from_clone['Image_Name']= self.element_get_attribute_value(self.CONTAINERS_TEXT_IMAGE_NAME)
        
            # TODO: Change registry type value from "PRIVATE" to some suitable input name
            if ((TestData["Registry_Type"]).upper() == "PRIVATE"):
                data_from_clone['Base_Image']=self.element_get_attribute_value(self.CONTAINERS_TEXT_BASE_IMAGE)
                data_from_clone['Git_Path']=self.element_get_attribute_value(self.CONTAINERS_TEXT_GIT_PATH)
                #data_from_clone[]=self.select_Custom_Branch(TestData["Custom_Branch"], TestData["Branch_Name"])
                data_from_clone['Release_Tag']=self.element_get_attribute_value(self.CONTAINERS_TEXT_RELEASE_TAG)
                #data_from_clone[]=self.select_Dependency_Type_private(TestData["Dependency_Type"])
            else:
                self.select_Dependency_Type_public(TestData["Dependency_Type"])

            data_from_clone['Co_Owners'] = self.element_get_attribute_value((By.XPATH, '//div[@class="recipeOwnerDropdown"]/div/a[@class="ui active label"] |  //div[@class="recipeOwnerDropdown"]/div/a[@class="ui label"]'))

            for key in keys_to_be_compared:
                if data_from_clone[key] != TestData[key]:
                    return False
            return True
        except Exception as e:
            print(e)
            return False

    def enter_Update_Containers_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()

        self.navigate_to_Containers_Page()
        self.search_Container_And_Perform_Action(TestData['Name'], 'EDIT')
        namestatus = self.check_ContainerNameDisabled()
        print(namestatus)
        self.enter_Display_Name( TestData["Display_Name"]+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
        self.enter_Discription( TestData["Description"]+uniquestr if (str(TestData["Description"])!= "None") else "")
        self.select_Registry_Type(TestData["Registry_Type"])
        self.enter_Version_Name( TestData["Version_Number"]+uniquestr if (str(TestData["Version_Number"])!= "None") else "", True )
        self.enter_Image_Name(TestData["image_Name"], True) 

        # TODO: Change registry type value from "PRIVATE" to some suitable input name
        if (str(TestData["Registry_Type"]).upper() == "PRIVATE"):
            self.enter_Base_Image( TestData["Base_Image"], True)
            self.enter_GIT_Path(TestData["Git_Path)"])
            self.select_Custom_Branch(TestData["Custom_Branch,Branch_Name"])
            self.enter_More_Info_Link(TestData["More_Info_Link"])
            self.enter_Release_Tag( TestData["Release_Tag"] +uniquestr if (str(TestData["Release_Tag"])!= "None") else "", True)
            self.select_Dependency_Type(TestData["Dependency_Type)"])
        else:
            self.select_Dependency_Type_public(TestData["Dependency_Type)"])
        
        self.enter_Installation_Commands(TestData["Installation_Commands)"])
        self.select_Compatible_OS(TestData["Compatible_OS)"])
        self.select_Unsupported_Countries(TestData["Unsupported_Countries)"])
        self.select_filter(TestData["Filter)"])
        # TODO: Result of co-owners verification needs to be added to the Report
        self.verify_Co_Owners(TestData["Co_Owners)"])
        self.select_Co_Owners(TestData["Co_Owners)"])
        

    def promote_Container_Data(self, TestData):
        self.navigate_to_Containers_Page()
        self.search_Container(TestData["Name"])
        self.promote_Container(TestData["Name"], TestData["Promote_Env"])

    def delete_Container_Data(self, TestData):
        self.navigate_to_Containers_Page()
        self.search_Container_And_Perform_Action(TestData["Name"], 'DELETE')

# Data Fetch Methods

    @staticmethod
    def get_Create_Container_Data():
        data_Create_Container = fo.File_Operations().get_csv_data(mc.containers_data_file,"CREATE")
        return data_Create_Container

    @staticmethod
    def get_Update_Container_Data():
        data_Update_Container = fo.File_Operations().get_csv_data(mc.containers_data_file,"UPDATE")
        return data_Update_Container

    @staticmethod
    def get_Delete_Container_Data():
        data_Delete_Container = fo.File_Operations().get_csv_data(mc.containers_data_file,"DELETE")
        return data_Delete_Container

    @staticmethod
    def get_Promote_Container_Data():
        data_Promote_Container = fo.File_Operations().get_csv_data(mc.containers_data_file,"PROMOTE")
        return data_Promote_Container

    @staticmethod
    def get_Parameters():
        parameterlist = mc.containers_columns_list
        return parameterlist

    @staticmethod
    def get_Container_TestData_As_JSON(action):
        data_Update_Container = fo.File_Operations().get_csv_data_as_Dataframe(mc.containers_data_file,action)
        data_Update_Container_JSON = data_Update_Container.to_json(orient="records")
        data_Update_Container_JSON = json.loads(data_Update_Container_JSON)
        print(data_Update_Container_JSON)
        return data_Update_Container_JSON