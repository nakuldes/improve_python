import time

import pytest
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select


class WebActions():

    def __init__(self, driver):
        self.driver = driver
    #Management Console
    element_username = (By.XPATH, "//input[@placeholder='Email Id']")
    element_password = (By.XPATH, "//input[@placeholder='Password']")
    element_login_button = (By.XPATH,"//p[contains(text(),'Login')]")
    #ESH UI
    esh_username = (By.ID,"txtUsername")
    esh_password = (By.ID, "txtPassword")
    esh_login_button = (By.ID,"formSubmit")

    page_loader = (By.XPATH, "//div[@class='showSpinner']")
    # //svg[@class='MuiCircularProgress-svg']
    esh_user_icon = (By.XPATH, "//span[@class='fa-intel-user-o icon-toggle-off']")
    element_logout_button = (By.XPATH,"//button[contains(text(),'Sign Out')]")


    def login_to_application(self, url, credential):
        print("Initiating application launch and login..")
        try:
            self.driver.get(url)
            title = self.driver.title
            print("Application Title : " + title)
            self.driver.maximize_window()
            self.driver.set_window_size(1920, 1080, self.driver.window_handles[0])
            self.element_set_text(self.element_username,credential["USERNAME"])
            self.element_set_text(self.element_password,credential["PASSWORD"])
            self.element_click(self.element_login_button)
            self.wait_loader_to_vanish()
            print("Successfully Logged into the application...")
            time.sleep(8)
        except Exception as e:
            print("Login failed due to error : " + str(e))

    def login_to_esh_application(self,init_browser, url, credential):
        print("Launching application...")
        print(url)
        try:
            init_browser.set_page_load_timeout(180)
            init_browser.get(url)
            init_browser.maximize_window()
            self.driver.set_window_size(1920, 1080, self.driver.window_handles[0])
            title = init_browser.title
            print(title)
            print("Launched application successfully...")
        except Exception as e:
            print("Application Launch failed due to error .. " + str(e))
            pytest.fail()
        try:
            time.sleep(5)
            self.element_set_text(self.esh_username,credential["EDGE_SOFTWARE_HUB"]["USERNAME"])
            self.element_set_text(self.esh_password,credential["EDGE_SOFTWARE_HUB"]["PASSWORD"])
            self.element_click_if_visible(self.esh_login_button)
            title = init_browser.title
            print(title)
            print("logged into the system successfully...")
        except Exception as e:
            print("User is already logged in....")

        self.wait_loader_to_vanish()
        time.sleep(8)

    def logout_from_esh_app(self):
        self.element_click(self.esh_user_icon)
        self.element_click(self.element_logout_button)
        time.sleep(10)

    def get_package_page(self, url):
        self.driver.get(url)

    def wait_loader_to_vanish(self):
        WebDriverWait(self.driver, 60).until(EC.invisibility_of_element_located(self.page_loader))

    def verify_if_element_is_displayed(self,locator):
        try:
            WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(locator))
            return True
        except:
            return False

    def wait_for_element_to_display(self,locator):
        WebDriverWait(self.driver, 30).until(EC.visibility_of_element_located(self.page_loader))

    def element_click(self,locator):
        WebDriverWait(self.driver, 40).until(EC.element_to_be_clickable(locator)).click()

    def element_click_if_visible(self,locator):
        WebDriverWait(self.driver, 40).until(EC.visibility_of_element_located(locator)).click()

    def element_click_fast(self,locator):
        WebDriverWait(self.driver, 1).until(EC.element_to_be_clickable(locator)).click()

    def element_is_clickable(self,locator):
        WebDriverWait(self.driver, 20).until(EC.element_to_be_clickable(locator))

    def upload_readme_file(self, filepath):
        locator = (By.XPATH, '//input[@name="sourceReadme"]')
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(locator)).send_keys(filepath)

    def upload_documentation_file(self, filepath):
        locator = (By.XPATH, '//input[@name="sourceDocumentationFile"]')
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(locator)).send_keys(filepath)

    def element_set_text(self,locator, text,required_clear=False):
        if(required_clear==True):
            self.element_delete_text(locator)
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(locator)).send_keys(text)

    def element_set_text_textarea(self,locator, text):
        '''This method deals with iframe which specific to TextArea in the MC UI'''
        self.driver.switch_to.default_content()
        iframe = self.driver.find_elements(By.TAG_NAME, 'iframe')[0]
        isd = iframe.get_attribute('id')
        self.driver.switch_to.frame(isd)
        WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(locator)).send_keys(text)
        self.driver.switch_to.default_content()
    
    def element_visible(self, locator):
        try:
            WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(locator))
            return True
        except Exception as e:
            return False

    def element_get_text(self, locator):
        element = WebDriverWait(self.driver, 30).until(EC.visibility_of_element_located(locator))
        return element.text

    def element_send_keys(self,locator, key):
        keys = "Keys."+key
        WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(locator)).send_keys(keys)

    def page_scroll_to_page_end(self):
        html = self.driver.find_element(By.TAG_NAME, 'html')
        html.send_keys(Keys.END)

    def press_enter_key(self,locator):
        WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(locator)).send_keys(Keys.ENTER)

    def action_chain_clear_text(self, locator):
        element = WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(locator))
        actions = ActionChains(self.driver)
        actions.move_to_element(element)
        actions.click(element)
        actions.key_down(Keys.CONTROL)
        actions.send_keys('a')
        actions.key_up(Keys.CONTROL)
        actions.send_keys(Keys.DELETE)
        actions.perform()

    def press_esc_key(self):
        html = self.driver.find_element(By.TAG_NAME, 'html')
        html.send_keys(Keys.ESCAPE)

    def get_elements_list(self,locator):
        #elementslist = self.driver.find_elements(By.CLASS_NAME,"addTextClass")
        elementslist = self.driver.find_elements(locator)
        return elementslist

    def form_Submit(self,locator):
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(locator)).submit()

    def select_element_from_dropdown(self,locator, visibleText):

        dropdown = Select(self.driver.find_element(locator))
        # dropdown.select_by_visible_text(visibleText)
        dropdown.select_by_index(2)


    def element_get_attribute_value(self, locator, attribute="value"):
        try:
            element = WebDriverWait(self.driver, 30).until(EC.presence_of_element_located(locator))
            value = element.get_attribute(attribute)
        except Exception as e:
            print("Element not found")
            value = "ELEMENTNOTFOUND"
        return value

    def action_chain_moveTo_Click(self,locator):
        element = WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(locator))
        actions = ActionChains(self.driver)
        actions.move_to_element(element)
        actions.click(element)
        actions.perform()

    def action_chain_enter_text(self,locator, key):
        self.action_chain_clear_text(locator)
        element = WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(locator))
        actions = ActionChains(self.driver)
        actions.move_to_element(element)
        actions.click(element)
        if key:
            actions.send_keys(key)
            actions.send_keys(Keys.ENTER)
        actions.perform()

    def element_click_on_presence(self,locator):
        WebDriverWait(self.driver, 30).until(EC.presence_of_element_located(locator)).click()

    def is_disabled(self,locator):
        return WebDriverWait(self.driver, 30).until(EC.visibility_of_element_located(locator)).is_enabled()

    def element_delete_text(self,locator):
        WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(locator)).send_keys(Keys.CONTROL + "a")
        WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(locator)).send_keys(Keys.DELETE)

    def press_backspace_key(self,locator):
        WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(locator)).send_keys(Keys.BACK_SPACE)


    def enable_uuid_column(self):
        customize_cols_btn = (By.XPATH, '//button[@id="picky__button__button"]')
        uuid_btn = (By.XPATH, '//input[@aria-label="UUID"]')
        WebDriverWait(self.driver, 30).until(EC.presence_of_element_located(customize_cols_btn)).click()
        WebDriverWait(self.driver, 30).until(EC.presence_of_element_located(uuid_btn)).click()
        WebDriverWait(self.driver, 30).until(EC.presence_of_element_located(customize_cols_btn)).click()

    def data_table_visiblity(self):
        table_xpath = (By.XPATH, '//thead[@data-test="datatable-head"]')
        try:
            WebDriverWait(self.driver, 30).until(EC.presence_of_element_located(table_xpath))
            return True
        except Exception as e:
            return False

    def scroll_to_bottom_of_page_using_script(self):
        ht = self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(3)

    def scroll_to_top_of_page_using_script(self):
        ht = self.driver.execute_script("window.scrollTo(0, 0);")
        time.sleep(3)
