import pytest
from selenium.webdriver.common.by import By
from .BasePage import WebActions
from selenium.webdriver.support.ui import WebDriverWait
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
import json
from utils import FileOperations as fo
from configs import ManagementConsole as mc
import utils.common



class HelmChartActions(WebActions):

    def __init__(self, driver):
        super().__init__(driver)


    """Locators"""
    HELM_LINK= (By.XPATH,"//*[@id='accordion__heading-raa-3']")
    HELM_BUTTON_CREATE_NEW = (By.XPATH,"//button/span[contains(text(),'Create Helmchart')]")
    HELM_TEXT_NAME = (By.NAME, "helmName")
    HELM_TEXT_DISPLAY_NAME=(By.NAME,"displayName")
    HELM_TEXT_DESCRIPTION= (By.NAME, "helmDesc")
    HELM_TEXT_VERSION_NAME=(By.NAME, "displayVersion")
    HELM_TEXT_HELMCHART_NAME=(By.NAME, "helmChartName")
    HELM_SELECT_DEPENDENCY_TYPE=(By.XPATH, "//select[@name='ingredientType']")
    HELM_TEXT_GIT_PATH = (By.NAME,"fullGitlabPath")
    HELM_TEXT_CUSTOM_BRANCH_YES= (By.XPATH, "//input[@name='isbranch-yes']")
    HELM_TEXT_CUSTOM_BRANCH= (By.XPATH, "//input[@name='branch']")
    HELM_TEXT_MORE_INFO_LINK= (By.NAME, "moreInfoLink")
    HELM_TEXT_RELEASE_TAG = (By.NAME, "releaseTag")
    HELM_UNSUPPORTED_COUNTRIES= (By.XPATH, "//div[@class='recipeOwnerDropdown']/div/div[contains(text(), 'Add countries')]")

    """for compatible os"""
    HELM_ADDCOMPATIBLE_OS_ADD = (By.XPATH,"//span[contains(text(), 'Compatible OS')]/parent::div/div/span")
    HELM_ADDCOMPATIBLE_COMMON_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    HELM_ADDCOMPATIBLE_COMMON_FIRST_CHECK = (By.XPATH,"//tbody/tr[1]/td[1]/div/span")
    HELM_ADDCOMPATIBLE_COMMON_ADD_LIST = (By.CSS_SELECTOR,".buttonClass:nth-child(2) > span")
    HELM_ADDCOMPATIBLE_COMMON_CANCEL= (By.CSS_SELECTOR,".buttonClass:nth-child(1) > span")

    """for method select - radio buttons"""
    BUILD_HELM_CHARTS = (By.XPATH, "//div[@role='radiogroup']//span[contains(text(), 'Build')]")
    IMPORT_HELM_CHART = (By.XPATH, "//div[@role='radiogroup']//span[contains(text(), 'Import')]")
    PUBLISH_TO_INTEL_PAH = (By.XPATH, "//div[@role='radiogroup']//span[contains(text(), 'Publish')]")

    # Filter Tag field
    FILTERTAG_NAME = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder='Name in English']")
    FILTERTAG_HELP = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder=' Add Help Text Here.']")
    SELECT_FILTERTAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/input")
    SELECT_FILTER_TAG_DROPDOWN = (By.XPATH, "//div[@role='combobox']/div[contains(text(), 'Tags')]")
    DELETE_EXISTING_FILTER_TAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")


    HELM_SAVE = (By.XPATH,"//span[contains(text(),'Save Helm Chart')]")
    TOAST_MSG_SUB_TEXT = (By.XPATH, "//span[@class='toast_submsg']")

    INSTALLATION_COMMANDS = (By.XPATH, "//textarea[@name='consumption']")

    """search adn delete helm"""
    HELM_SEARCH_TEXT=(By.XPATH,"//input['@label=Search']")
    HELM_ACTION=(By.XPATH,"//*[@id='app']/div[3]/div[2]/div/div[2]/div/div[5]/div/div[2]/div/div/div[2]/div/table/tbody/tr[1]/td[8]/div/div")
    HELM_DELETE=(By.XPATH,"//*[contains(text(), 'Delete')]")
    HELM_DELETE_YES=(By.XPATH,"//*[contains(text(), 'Yes')]")

    """Search and perform actions"""
    
    HELM_COMMON_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    HELM_ACTION_OPTION = (By.CLASS_NAME,"ui dropdown  text-primary ")
    HELM_ACTION_EDIT = (By.XPATH,"//span[contains(text(),'Edit')]")
    HELM_ACTION_DELETE= (By.XPATH,"//span[contains(text(),'Delete')]")
    HELM_ACTION_TRIGGER_BUILD = (By.XPATH,"//span[contains(text(),'Trigger Build')]")
    HELM_GET_BUILD_STATUS = (By.XPATH,"//span[@class='statusText']/span")
    HELM_GET_BUILD_STATUS_REFRESH = (By.XPATH,"//span[@class='pointerDiv']/i")
    HELM_ACTION_CLONE= (By.XPATH,"//span[contains(text(),'Clone')]")
    HELM_ACTION_PROMOTE = (By.XPATH, "//button/span[contains(text(), 'Promote')]")

    """Error Handle"""
    HELM_CANCEL_SAVE = (By.XPATH,"//span[contains(text(),'Cancel')]")
    HELM_CANCEL_YES = (By.XPATH,"//button/span[contains(text(),'Yes')]")

    """Actions"""
    def navigate_to_HelmCharts_Page(self):
        self.element_click(self.HELM_LINK)
        self.wait_loader_to_vanish()

    def navigate_to_Create_HelmChart(self):
        self.element_click(self.HELM_BUTTON_CREATE_NEW)
        self.wait_loader_to_vanish()

    def verify_helm_table_columns(self, headers_list):
        self.navigate_to_HelmCharts_Page()
        self.wait_loader_to_vanish()
        for element in headers_list:
            col_xpath = (By.XPATH, '//thead[@data-test="datatable-head"]/tr/th/span[contains(text(), "{0}")]'.format(element))
            if not self.element_visible(col_xpath):
                return False
        return True

    def enter_Name(self,name):
        self.element_set_text(self.HELM_TEXT_NAME, name)

    def enter_Display_Name(self, displayname,required_clear=False):
        self.element_set_text(self.HELM_TEXT_DISPLAY_NAME,displayname,required_clear)
    
    def enter_Discription(self,description, required_clear=False):
        self.element_set_text(self.HELM_TEXT_DESCRIPTION, description,required_clear)

    def enter_Version_Name(self,version, required_clear=False):
        self.element_set_text(self.HELM_TEXT_VERSION_NAME, version, required_clear)
    
    def enter_HelmChart_Name(self,version, required_clear=False):
        self.element_set_text(self.HELM_TEXT_HELMCHART_NAME, version, required_clear)

    def select_Dependency_Type(self, dependency):
        dropdw = Select(WebDriverWait(self.driver,20).until(EC.presence_of_element_located(self.HELM_SELECT_DEPENDENCY_TYPE)))
        dropdw.select_by_value("5fe9bbb386a072002a2199c5")
    
    def enter_GIT_Path(self,gitpath, required_clear=False):
        self.element_set_text(self.HELM_TEXT_GIT_PATH, gitpath, required_clear)

    def select_Custom_Branch(self, option,branchname=None, required_clear=False):
        if(option.upper() == "YES"):
            self.element_click(self.HELM_TEXT_CUSTOM_BRANCH_YES)
            #self.element_set_text(self.HELM_TEXT_CUSTOM_BRANCH,branchname, required_clear)

    def enter_More_Info_Link(self, moreinfolink, required_clear=False):
        self.element_set_text(self.HELM_TEXT_MORE_INFO_LINK, moreinfolink, required_clear)

    def enter_Release_Tag(self, releasetag, required_clear=False):
        self.element_set_text(self.HELM_TEXT_RELEASE_TAG, releasetag, required_clear)

    def select_Unsupported_Countries(self, country):
        self.page_scroll_to_page_end()
        time.sleep(2)
        self.element_click(self.HELM_UNSUPPORTED_COUNTRIES)
        time.sleep(3)
        HELM_COUNTRY_OPTION = (By.XPATH,"//span[contains(text(),'{}')]".format(str(country)))
        self.element_click(HELM_COUNTRY_OPTION)
        self.press_esc_key()
    
    def installation_commands(self,cmd):
        self.element_set_text(self.INSTALLATION_COMMANDS, cmd)

    def select_Compatible_OS(self, searchstring=None):
        try:
            self.element_click(self.HELM_ADDCOMPATIBLE_OS_ADD)
            time.sleep(3)
            if(searchstring != None):
                self.element_set_text(self.HELM_ADDCOMPATIBLE_COMMON_SEARCH, searchstring)
                self.element_click(self.HELM_ADDCOMPATIBLE_COMMON_FIRST_CHECK)
            else:
                self.element_click(self.HELM_ADDCOMPATIBLE_COMMON_FIRST_CHECK)
            result = self.element_click(self.HELM_ADDCOMPATIBLE_COMMON_ADD_LIST)
            time.sleep(2)
        except:
            self.element_click(self.HELM_ADDCOMPATIBLE_COMMON_CANCEL)
            self.element_click(self.HELM_LINK)
            self.element_click(self.HELM_CANCEL_YES)
            return False
    
    def check_Save_Button_Disables(self):
        # return self.is_disabled(self.MODULES_SAVE)
        try:
            self.element_is_clickable(self.HELM_SAVE)
            return True
        except:
            return False

    def save_Helm(self):
        self.element_click(self.HELM_SAVE)
        success_message = self.element_get_text(self.TOAST_MSG_SUB_TEXT)
        self.wait_loader_to_vanish()
        return success_message

    def search_helm_name(self,helmchart_name):
        self.element_set_text(self.HELM_SEARCH_TEXT,helmchart_name)

    def select_filter(self, tag_name):
        '''
        This method deals with filter tags in MC
        *It first deletes the existing filter tag selected if any are there
        *Then adds given number of filter tags
        '''
        return
        #deleting existing filter tags
        try:
            exisitng_filtertags = self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")
            for tag in exisitng_filtertags:
                tag.click()
        except Exception as e:
            # No filter tag found
            print('No exisiting filter tag found.')
        # Adding existing 2 filters
        count = 0
        self.element_click(self.SELECT_FILTER_TAG_DROPDOWN)
        if tag_name == 'existing':
            available_filter_tags =  self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/div/div[@role='option']")
            for wb in available_filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                wb.click()
                count+=1
                if count == 2:
                    break         
        else:
            filter_tags = str(tag_name).split('|')
            for item in filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                ADD_FILTERS_OPTION = (By.XPATH,"//span[contains(text(),'{0}')]".format(item))
                self.element_click(ADD_FILTERS_OPTION)
    
    def delete_helm(self):
        self.element_click(self.HELM_ACTION)
        self.element_click(self.HELM_DELETE)
        self.element_click(self.HELM_DELETE_YES)

    def search_Helm_And_Perform_Action(self,helm_name, action):
        self.element_set_text(self.HELM_COMMON_SEARCH,helm_name, True)
        elem = (By.XPATH,"//td/span[contains(text(),'" + helm_name + "')]/ancestor::tr/td[8]/div/div")
        self.element_click(elem)
        if action == "EDIT":
            self.element_click(self.HELM_ACTION_EDIT)
        elif action == "DELETE":
            self.element_click(self.HELM_ACTION_DELETE)
        elif action == "TRIGGER BUILD":
            initialstatus = self.element_get_text(self.HELM_GET_BUILD_STATUS)
            self.element_click(self.HELM_ACTION_TRIGGER_BUILD)
            time.sleep(4)
            currentstatus = self.element_get_text(self.HELM_GET_BUILD_STATUS)
            print("Build status after build trigger :  " + currentstatus)
            self.element_click(self.HELM_GET_BUILD_STATUS_REFRESH)
            time.sleep(3)
            currentstatus = self.element_get_text(self.HELM_GET_BUILD_STATUS)
            print("Build status after refresh :  " + currentstatus)
        elif action == "PROMOTE":
            elem = (By.XPATH,"//td/span[contains(text(),'"+helm_name +"')]/../..//span[contains(text(), 'Promote')]")
            self.element_click(elem)            
        elif action == "CLONE":
            self.element_click(self.HELM_ACTION_CLONE)
        time.sleep(3)

    def toast_msg_close(self):
        items = self.driver.find_elements(By.XPATH, "//div[@class='Toastify']/div/div/button[@aria-label='close']")
        for item in items:
            item.click()
            time.sleep(1)

    def error_recovery(self):
        try:
            self.toast_msg_close()
        except Exception as e:
            pass
        try:
            self.element_click_fast(self.HELM_CANCEL_SAVE)
        except Exception as e:
            pass
        try:
            self.element_click_fast(self.HELM_CANCEL_YES)
        except Exception as e:
            pass

    def enter_Create_Helmchart_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()
        helmchart_name = TestData['Name'] + uniquestr if(str(TestData['Name']) != "nan") else ""
        self.navigate_to_HelmCharts_Page()
        self.navigate_to_Create_HelmChart()
        self.enter_Name(helmchart_name)
        self.enter_Display_Name( TestData['Display_Name'] +uniquestr if (str(TestData['Display_Name'])!= "nan") else "")
        self.enter_Discription( TestData['Description'] +uniquestr if (str(TestData['Description'])!= "nan") else "")
        if TestData['Method'] == 'Build':
            self.element_click(self.BUILD_HELM_CHARTS)
            self.enter_Version_Name( TestData['Version_Number'] +uniquestr if (str( TestData['Version_Number'])!= "nan") else "" )
            self.enter_HelmChart_Name( TestData['HelmChart_Name']+uniquestr if (str(TestData['Version_Number'])!= "nan") else "")
            self.select_Dependency_Type( TestData['Dependency_Type'])
            self.enter_GIT_Path( TestData['Git_Path'])
            self.select_Custom_Branch( TestData['Custom_Branch'])
            self.enter_More_Info_Link( TestData['More_Info_Link'] if (str( TestData['More_Info_Link'])!= "nan") else "")
            self.enter_Release_Tag( TestData['Release_Tag'] +uniquestr if (str(TestData['Release_Tag'])!= "nan") else "")
        elif TestData['Method'] == 'Import':
            self.element_click(self.IMPORT_HELM_CHART)
            self.enter_Version_Name( TestData['Version_Number'] +uniquestr if (str( TestData['Version_Number'])!= "nan") else "" )
            self.enter_HelmChart_Name( TestData['HelmChart_Name']+uniquestr if (str(TestData['Version_Number'])!= "nan") else "")
            self.select_Dependency_Type( TestData['Dependency_Type'])
            self.enter_GIT_Path( TestData['Git_Path'])
        elif TestData['Method'] == 'Publish':
            self.element_click(self.PUBLISH_TO_INTEL_PAH)
            self.enter_GIT_Path( TestData['Git_Path'])
            
        self.installation_commands(TestData['Consumption'])
        self.select_Unsupported_Countries(TestData['Unsupported_Countries'])
        self.select_Compatible_OS(TestData['Compatible_OS'])
        self.select_filter(TestData['Filter_Tag'])
        
        return helmchart_name

    def enter_Clone_Helmchart_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()
        helm_name = TestData['Name']+uniquestr
        print(helm_name)
        self.enter_Name(helm_name)
        self.enter_Display_Name(TestData["Display_Name"]+uniquestr, True)
        self.enter_Discription(TestData["Description"]+uniquestr, True)
        if TestData['Method'] == 'Build':
            self.element_click(self.BUILD_HELM_CHARTS)
            self.enter_Version_Name( TestData['Version_Number'] +uniquestr if (str( TestData['Version_Number'])!= "nan") else "" )
            self.enter_HelmChart_Name( TestData['HelmChart_Name']+uniquestr if (str(TestData['Version_Number'])!= "nan") else "")
            self.select_Dependency_Type( TestData['Dependency_Type'])
            self.enter_GIT_Path( TestData['Git_Path'])
            self.select_Custom_Branch( TestData['Custom_Branch'])
            self.enter_More_Info_Link( TestData['More_Info_Link'] if (str( TestData['More_Info_Link'])!= "nan") else "")
            self.enter_Release_Tag( TestData['Release_Tag'] +uniquestr if (str(TestData['Release_Tag'])!= "nan") else "")
        elif TestData['Method'] == 'Import':
            self.element_click(self.IMPORT_HELM_CHART)
            self.enter_Version_Name( TestData['Version_Number'] +uniquestr if (str( TestData['Version_Number'])!= "nan") else "" )
            self.enter_HelmChart_Name( TestData['HelmChart_Name']+uniquestr if (str(TestData['Version_Number'])!= "nan") else "")
            self.select_Dependency_Type( TestData['Dependency_Type'])
            self.enter_GIT_Path( TestData['Git_Path'])
        elif TestData['Method'] == 'Publish':
            self.element_click(self.PUBLISH_TO_INTEL_PAH)
            self.enter_GIT_Path( TestData['Git_Path'])
        #self.select_Unsupported_Countries(Unsupported_Countries)
        self.select_Compatible_OS(TestData['Compatible_OS'])
        self.select_filter(TestData['Filter_Tag'])
        return helm_name
        
    def enter_Update_Helmchart_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()
        helmchart_name = TestData['Name']
        self.navigate_to_HelmCharts_Page()
        self.navigate_to_Create_HelmChart()
        self.enter_Name(helmchart_name)
        self.enter_Display_Name( TestData['Display_Name'] +uniquestr if (str(TestData['Display_Name'])!= "nan") else "")
        self.enter_Discription( TestData['Description'] +uniquestr if (str(TestData['Description'])!= "nan") else "")
        if TestData['Method'] == 'Build':
            self.element_click(self.BUILD_HELM_CHARTS)
            self.enter_Version_Name( TestData['Version_Number'] +uniquestr if (str( TestData['Version_Number'])!= "nan") else "" )
            self.enter_HelmChart_Name( TestData['HelmChart_Name']+uniquestr if (str(TestData['Version_Number'])!= "nan") else "")
            self.select_Dependency_Type( TestData['Dependency_Type'])
            self.enter_GIT_Path( TestData['Git_Path'])
            self.select_Custom_Branch( TestData['Custom_Branch'])
            self.enter_More_Info_Link( TestData['More_Info_Link'] if (str( TestData['More_Info_Link'])!= "nan") else "")
            self.enter_Release_Tag( TestData['Release_Tag'] +uniquestr if (str(TestData['Release_Tag'])!= "nan") else "")
        elif TestData['Method'] == 'Import':
            self.element_click(self.IMPORT_HELM_CHART)
            self.enter_Version_Name( TestData['Version_Number'] +uniquestr if (str( TestData['Version_Number'])!= "nan") else "" )
            self.enter_HelmChart_Name( TestData['HelmChart_Name']+uniquestr if (str(TestData['Version_Number'])!= "nan") else "")
            self.select_Dependency_Type( TestData['Dependency_Type'])
            self.enter_GIT_Path( TestData['Git_Path'])
        elif TestData['Method'] == 'Publish':
            self.element_click(self.PUBLISH_TO_INTEL_PAH)
            self.enter_GIT_Path( TestData['Git_Path'])
        #self.select_Unsupported_Countries(Unsupported_Countries)
        self.select_Compatible_OS(TestData['Compatible_OS'])
        self.select_filter(TestData['Filter_Tag'])

    def promote_Helm_Data(self, TestData):
        if str(TestData['Promote_Env'])!= "None":
            self.navigate_to_HelmCharts_Page()
            self.search_Helm_And_Perform_Action(TestData["Name"], "PROMOTE")

    def promote_Helm(self, promote_env):
        env_dropdown = (By.XPATH, "//div[@class='intel__catalog__container']/div[2]/div/label/span[contains(text(), '{0}')]".format(promote_env))
        self.element_click(env_dropdown)
        self.element_click(self.HELM_ACTION_PROMOTE)
        success_message = self.element_get_text(self.TOAST_MSG_SUB_TEXT)
        return success_message

    def delete_Helmchart(self, helm_name):
        self.navigate_to_HelmCharts_Page()
        self.search_Helm_And_Perform_Action(helm_name, 'DELETE')

    def select_Delete_Yes(self):
        self.element_click(self.HELM_DELETE_YES)
        self.wait_loader_to_vanish()
        # time.sleep(5)
        confirmation_message = self.element_get_text(self.TOAST_MSG_SUB_TEXT)
        return confirmation_message



# Data Fetch Methods

    @staticmethod
    def get_Parameters():
        parameterlist = mc.helmcharts_column_list
        return parameterlist

    @staticmethod
    def get_Create_HelmChart_Data():
        data_Create_HelmChart = fo.File_Operations().get_csv_data(mc.helm_data_file,"CREATE")
        return data_Create_HelmChart

    @staticmethod
    def get_Update_HelmChart_Data():
        data_Update_HelmChart = fo.File_Operations().get_csv_data(mc.helm_data_file,"UPDATE")
        return data_Update_HelmChart

    @staticmethod
    def get_Delete_Helm_Data():
        data_Delete_HelmChart = fo.File_Operations().get_csv_data(mc.helm_data_file,"DELETE")
        return data_Delete_HelmChart

    @staticmethod
    def get_Helm_TestData_As_JSON(action):
        data_Update_Helmchart = fo.File_Operations().get_csv_data_as_Dataframe(mc.helm_data_file,action)
        data_Update_Helmchart_JSON = data_Update_Helmchart.to_json(orient="records")
        data_Update_Helmchart_JSON = json.loads(data_Update_Helmchart_JSON)
        print(data_Update_Helmchart_JSON)
        return data_Update_Helmchart_JSON

