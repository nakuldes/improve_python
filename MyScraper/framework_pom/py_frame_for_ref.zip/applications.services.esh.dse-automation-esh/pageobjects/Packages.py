import pytest
from selenium.webdriver.common.by import By
from .BasePage import WebActions
from selenium.webdriver.support.ui import WebDriverWait
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from utils import FileOperations as fo
from configs import ManagementConsole as mc
import json
import utils.common
from uuid import uuid4


class PackagesActions(WebActions):

    def __init__(self, driver):
        super().__init__(driver)



    """ Package Page Locators """

    PACKAGES_LINK = (By.XPATH, "//span[contains(text(), 'Packages')]")
    PACKAGES_BUTTON_CREATE_NEW = (By.XPATH, "//span[contains(text(), 'Create Package')]")
    PACKAGES_TITLE_CREATE_PACKAGE = (By.XPATH, "//span[contains(text(), 'Create')]")
    PACKAGES_NAME = (By.NAME, "recipeName")
    PACKAGES_DISPLAY_NAME = (By.NAME, "displayName")
    PACKAGES_DESCRIPTION = (By.NAME, "recipeDesc")
    #PACKAGES_MORE_INFO = (By.CLASS_NAME, "mce-content-body ") # NEED TO FIX THIS
    PACKAGES_MORE_INFO = (By.XPATH, "//html/body[@id='tinymce']") # NEED TO FIX THIS
    PACKAGES_LICENSE_AGREEMENT = () # NEED TO ADD XPATH FOR THIS

    PACKAGES_BUTTON_TRANSLATION = (By.XPATH, "//form/div/fieldset[@class='multiLingCard'][1]//button[contains(text(), 'Add Translation')]")
    PACKAGES_SELECT_LANGUAGE = (By.XPATH, "//form/div/fieldset[2]//select")
    PACKAGES_SELECT_LANGUAGE_CHINESE = (By.XPATH, "//option[@value='ch']")
    PACKAGES_TEXT_CH_NAME = (By.XPATH, "//form/div/fieldset[@class='multiLingCard'][2]//input[@name='imageName']")
    PACKAGES_TEXT_CH_DISPLAY_NAME = (By.XPATH, "//form/div/fieldset[@class='multiLingCard'][2]//input[@name='displayName']")
    PACKAGES_TEXT_CH_DESCRIPTION = (By.XPATH, "//form/div/fieldset[@class='multiLingCard'][2]//textarea[@name='imageDesc']")
    #PACKAGES_TEXT_CH_MORE_INFO = (By.XPATH, "//body[@data-id='tiny-react_63257841111649232473361']")
    PACKAGES_TEXT_CH_MORE_INFO = (By.XPATH, "//body[@class='mce-content-body ']")

    PACKAGES_VERSION_NUMBER = (By.NAME, "displayVersion")
    PACKAGES_RADIO_ENABLE_AUTHENTICATION_YES = (By.XPATH, "//span[contains(text(), 'Is Authentication required')]/../../div[2]//div[@class='radioInput']/span[1]")
    PACKAGES_RADIO_ENABLE_AUTHENTICATION_NO = (By.XPATH, "//span[contains(text(), 'Is Authentication required')]/../../div[2]//div[@class='radioInput']/span[3]")
    PACKAGES_TAG_NAME = (By.NAME, "tagName")
    PACKAGES_IRC_ID = (By.NAME, "ircProductId")
    PACKAGES_RADIO_ENABLE_PRODUCT_KEY_YES = (By.XPATH, "//span[contains(text(), 'Enable Product Key')]/../../div[2]//div[@class='radioInput']/span[1]")
    PACKAGES_RADIO_ENABLE_PRODUCT_KEY_NO = (By.XPATH, "//span[contains(text(), 'Enable Product Key')]/../../div[2]//div[@class='radioInput']/span[3]")
    PACKAGES_GITHUB_PATH = (By.NAME, "fullGitlabPath")
    PACKAGES_JENKINS_PATH = (By.NAME, "jenkinsPath")
    PACKAGES_PACKAGE_CLASS = (By.NAME, "recipeType")
    PACKAGES_DOCUMENTATION_LINK = (By.NAME, "documentationLink")
    PACKAGES_LICENSE_TYPE = (By.NAME, "licenceType")
    PACKAGES_GSG = (By.NAME, "gettingStartedGuide")
    PACKAGES_UI_ROUTE = (By.NAME, "uiRoute")
    PACKAGES_HARDWARE_REQUIREMENTS_LINK = (By.NAME, "hardwareAndSystemRequirementLinks")
    PACKAGES_MEMORY_REQUIRED = (By.NAME, "memoryRequired")
    PACKAGES_HDISK_SPACE_REQUIRED = (By.NAME, "diskRequired")
    PACKAGES_ZIP_LABEL = (By.NAME, "zipLabel")
    PACKAGES_RADIO_IS_CUSTOMIZABLE_YES = (By.XPATH, "//span[contains(text(), 'Is it Customizable')]/../../div[2]//span[contains(text(), 'Yes')]")
    PACKAGES_IS_CUSTOMIZABLE_NO = (By.NAME, "//span[contains(text(), 'Is it Customizable')]/../../div[2]//span[contains(text(), 'No')]")
    PACKAGES_DEFAULT_HARDWARE = (By.NAME, "defaultHw")
    PACKAGES_SUPPORT_LINK = (By.NAME, "supportLink")
    PACKAGES_LEARN_MORE_LINK = (By.NAME, "learnMoreLink")

    PACKAGE_CANCEL_ADD_RESOURCES = (By.XPATH, "//button[@class='buttonClass cancelbuttonClass marginTop']")
    PACKAGES_RESOURCE_ADD = (By.XPATH,"//span[contains(text(), 'Resource')]/parent::div/div/span")
    PACKAGES_RESOURCE_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    PACKAGES_RESOURCE_TABLE = (By.XPATH,"//tbody")
    PACKAGES_RESOURCE_FIRST_CHECK = (By.XPATH,"//tbody/tr[1]/td[1]/div/span")
    PACKAGES_RESOURCE_ADD_LIST = (By.CSS_SELECTOR,".buttonClass:nth-child(2) > span")

    PACKAGES_ADDCOMPATIBLE_OS_ADD = (By.XPATH,"//span[contains(text(), 'Compatible OS')]/parent::div/div/span")
    PACKAGES_ADDCOMPATIBLE_OS_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    PACKAGES_ADDCOMPATIBLE_OS_TABLE = (By.XPATH,"//tbody")
    PACKAGES_ADDCOMPATIBLE_OS_FIRST_CHECK = (By.XPATH,"//tbody/tr[1]/td[1]/div/span")
    PACKAGES_ADDCOMPATIBLE_OS_ADD_LIST = (By.CSS_SELECTOR,".buttonClass:nth-child(2) > span")

    PACKAGES_HELMCHARTS_ADD = (By.XPATH,"//span[contains(text(), 'Helm Charts')]/parent::div/div/span")
    PACKAGES_HELMCHARTS_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    PACKAGES_HELMCHARTS_TABLE = (By.XPATH,"//tbody")
    PACKAGES_HELMCHARTS_FIRST_CHECK = (By.XPATH,"//tbody/tr[1]/td[1]/div/span")
    PACKAGES_HELMCHARTS_ADD_LIST = (By.CSS_SELECTOR,".buttonClass:nth-child(2) > span")

    PACKAGES_CONTAINERS_ADD = (By.XPATH,"//span[contains(text(), 'Containers')]/parent::div/div/span")
    PACKAGES_CONTAINERS_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    PACKAGES_CONTAINERS_TABLE = (By.XPATH,"//tbody")
    PACKAGES_CONTAINERS_FIRST_CHECK = (By.XPATH,"//tbody/tr[1]/td[1]/div/span")
    PACKAGES_CONTAINERS_ADD_LIST = (By.CSS_SELECTOR,".buttonClass:nth-child(2) > span")

    PACKAGES_MODULES_ADD = (By.XPATH,"//span[contains(text(), 'Modules')]/parent::div/div/span")
    PACKAGES_MODULES_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    PACKAGES_MODULES_TABLE = (By.XPATH,"//tbody")
    PACKAGES_MODULES_FIRST_CHECK = (By.XPATH,"//tbody/tr[1]/td[1]/div/span")
    PACKAGES_MODULES_ADD_LIST = (By.CSS_SELECTOR,".buttonClass:nth-child(2) > span")

    PACKAGES_ONLINE_DISTRIBUTION_ADD = (By.XPATH,"//div[@class='addFormClass']/span[contains(text(), 'Online Distribution')]/../div/span[contains(text(), 'Add')]")
    PACKAGES_ONLINE_DISTRIBUTION_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    PACKAGES_ONLINE_DISTRIBUTION_TABLE = (By.XPATH,"//tbody")
    PACKAGES_ONLINE_DISTRIBUTION_FIRST_CHECK = (By.XPATH,"//tbody/tr[1]/td[1]/div/span")
    PACKAGES_ONLINE_DISTRIBUTION_ADD_LIST = (By.CSS_SELECTOR,".buttonClass:nth-child(2) > span")

    # Filter Tag field
    FILTERTAG_NAME = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder='Name in English']")
    FILTERTAG_HELP = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder=' Add Help Text Here.']")
    SELECT_FILTERTAG = (By.XPATH, "//div[@class='filterDropdownForRecipe']/div/input")
    EXISTING_FILTER_TAG = (By.XPATH, "//div[@class='filterDropdownForRecipe']/div/a/i")

    # Filter Tag field
    FILTERTAG_NAME = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder='Name in English']")
    FILTERTAG_HELP = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder=' Add Help Text Here.']")
    SELECT_FILTERTAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/input")
    SELECT_FILTER_TAG_DROPDOWN = (By.XPATH, "//div[@role='combobox']/div[contains(text(), 'Tags')]")
    DELETE_EXISTING_FILTER_TAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")


    PACKAGES_ADD_NEW_APPROVER_BUTTON = (By.XPATH, "//img[@class='addApprovalTypeItem']")
    PACKAGES_SELECT_APPROVAL_TYPE = (By.XPATH, "//div[@class='typeDropdown']/div/input")
    PACKAGES_SELECT_APPROVAL_USER = (By.XPATH, "//div[@class='userDropdown']/div/input")

    PACKAGES_VERIFY_CO_OWNERS = (By.XPATH, "//div/span[contains(text(), 'Co-Owners')]/../../div[@class='recipeOwnerDropdown']/div[@role='combobox']/input")

    
    PACKAGES_COMMON_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    PACKAGES_ACTION_OPTION = (By.CLASS_NAME,"ui dropdown  text-primary ")
    PACKAGES_ACTION_EDIT = (By.XPATH,"//span[contains(text(),'Edit')]")
    PACKAGES_ACTION_DELETE= (By.XPATH,"//span[contains(text(),'Delete')]")
    PACKAGES_ACTION_CLONE= (By.XPATH,"//span[contains(text(),'Clone')]")
    PACKAGES_ACTION_PROMOTE = (By.XPATH, "//button/span[contains(text(), 'Promote')]")
    PACKAGES_ACTION_TRIGGER_BUILD = (By.XPATH,"//span[contains(text(),'Trigger Build')]")
    PACKAGES_GET_BUILD_STATUS = (By.XPATH,"//span[@class='statusText']/span")
    PACKAGES_GET_BUILD_STATUS_REFRESH = (By.XPATH,"//span[@class='pointerDiv']/i")
    PACKAGES_READ_EXISTING_NAME = (By.XPATH, '//tbody[@data-test="table-body"]/tr[1]/td[1]/span')
    PACKAGES_TEXT_JENKINS_PATH = (By.NAME, "jenkinsPath")

    #Toast Message Text fields locators
    TOAST_MSG_TEXT = (By.XPATH, "//span[@class='toast_msg']")
    TOAST_MSG_SUB_TEXT = (By.XPATH, "//span[@class='toast_submsg']")

    PACKAGES_POPUP_YES_BUTTON = (By.XPATH,"//button/span[contains(text(),'Yes')]")
    PACKAGES_POPUP_CLOSE_BUTTON = (By.XPATH,"//button/span[contains(text(),'Close')]")
    PACKAGES_SAVE = (By.XPATH,"//span[contains(text(),'Save Package')]")
    PACKAGES_CANCEL_SAVE = (By.XPATH,"//span[contains(text(),'Cancel')]")

    """ PAckage Page Actions """

    def navigate_to_Package_Page(self):
        self.element_click(self.PACKAGES_LINK)

        #time.sleep(5)
        self.wait_loader_to_vanish()

    def navigate_to_Create_Package(self):
        self.element_click(self.PACKAGES_BUTTON_CREATE_NEW)
        time.sleep(10)

    def get_pkg_name(self, testdata_name, packages_list):
        if '_OD_' in testdata_name:
            '''Get the list of OD type Packages to udpate'''
            od_type_pkg_list = [v for v in packages_list if '_OD_' in v]
            return od_type_pkg_list.pop()
        else:
            return packages_list.pop()

    def enter_Name(self,name):
        self.action_chain_enter_text(self.PACKAGES_NAME, name)

    def enter_Display_Name(self, displayname):
        self.action_chain_enter_text(self.PACKAGES_DISPLAY_NAME,displayname)

    def enter_Discription(self,description):
        self.action_chain_enter_text(self.PACKAGES_DESCRIPTION, description)

    def enter_More_Info(self,moreinfo):
        self.element_set_text_textarea(self.PACKAGES_MORE_INFO, moreinfo)

    def select_add_Translation(self):
        self.element_click(self.PACKAGES_BUTTON_TRANSLATION)

    def select_launguage(self, language):
        self.element_click(self.PACKAGES_SELECT_LANGUAGE)
        time.sleep(2)
        self.element_click(self.PACKAGES_SELECT_LANGUAGE_CHINESE)

    def enter_Name_Ch(self,name):
        self.element_set_text(self.PACKAGES_TEXT_CH_NAME, name)

    def enter_Display_Name_Ch(self, displayname):
        self.element_set_text(self.PACKAGES_TEXT_CH_DISPLAY_NAME,displayname)

    def enter_Discription_Ch(self,description):
        self.element_set_text(self.PACKAGES_TEXT_CH_DESCRIPTION, description)

    def enter_More_Info_Ch(self,moreinfo):
        self.element_set_text_textarea(self.PACKAGES_TEXT_CH_MORE_INFO, moreinfo)

        
    
    def enter_Version_Name(self,version):
        self.action_chain_enter_text(self.PACKAGES_VERSION_NUMBER, version)

    def enter_Tag_Name(self,tag_name):
        self.action_chain_enter_text(self.PACKAGES_TAG_NAME, tag_name)

    def enter_IRC_ID(self,version):
        self.action_chain_enter_text(self.PACKAGES_IRC_ID, version)

    def select_Enable_Product_Key(self, option='No'):
        if(option.upper() == "YES"):
            self.action_chain_moveTo_Click(self.PACKAGES_RADIO_ENABLE_PRODUCT_KEY_YES)
        else:
            self.action_chain_moveTo_Click(self.PACKAGES_RADIO_ENABLE_PRODUCT_KEY_NO)

    def select_Authentication(self, option='No'):
        if(option.upper() == "YES"):
            self.action_chain_moveTo_Click(self.PACKAGES_RADIO_ENABLE_AUTHENTICATION_YES)
        else:
            self.action_chain_moveTo_Click(self.PACKAGES_RADIO_ENABLE_AUTHENTICATION_NO)

    def enable_product_key(self,version):
        self.action_chain_enter_text(self.PACKAGES_RADIO_ENABLE_PRODUCT_KEY, version)

    def enter_GIThub_Path(self, git_path):
        self.action_chain_enter_text(self.PACKAGES_GITHUB_PATH, git_path)

    def enter_Jenkins_Path(self, jenkins_path):
        self.action_chain_enter_text(self.PACKAGES_JENKINS_PATH, jenkins_path)

    def enter_Packages_Class(self, package_class):
        self.action_chain_enter_text(self.PACKAGES_PACKAGE_CLASS, package_class)

    def enter_Documentation_link(self, doc_link):
        self.action_chain_enter_text(self.PACKAGES_DOCUMENTATION_LINK, doc_link)

    def enter_License_Type(self, license_type):
        self.action_chain_enter_text(self.PACKAGES_LICENSE_TYPE, license_type)

    def enter_Packages_GSG(self, pkg_gsg):
        self.action_chain_enter_text(self.PACKAGES_GSG, pkg_gsg)

    def enter_UI_Route(self, ui_route):
        self.action_chain_enter_text(self.PACKAGES_UI_ROUTE, ui_route)

    def enter_HW_Requirements_Link(self, hw_requirements):
        self.action_chain_enter_text(self.PACKAGES_HARDWARE_REQUIREMENTS_LINK, hw_requirements)

    def enter_Memory_Required(self, memory_required):
        self.action_chain_enter_text(self.PACKAGES_MEMORY_REQUIRED, str(memory_required))

    def enter_HDisk_Space_Required(self, hard_disk):
        self.action_chain_enter_text(self.PACKAGES_HDISK_SPACE_REQUIRED, str(hard_disk))

    def enter_ZIP_Lable(self,zip_lable):
        self.action_chain_enter_text(self.PACKAGES_ZIP_LABEL, zip_lable)

    def select_Customizable(self, option='No'):
        if(option.upper() == "YES"):
            self.action_chain_moveTo_Click(self.PACKAGES_RADIO_ENABLE_PRODUCT_KEY_YES)
        else:
            self.action_chain_moveTo_Click(self.PACKAGES_RADIO_ENABLE_PRODUCT_KEY_NO)


    def enter_Default_HW(self,default_hw):
        self.action_chain_enter_text(self.PACKAGES_DEFAULT_HARDWARE, default_hw)

    def enter_Support_Link(self,support_link):
        self.action_chain_enter_text(self.PACKAGES_SUPPORT_LINK, support_link)

    def enter_Learn_More_Link(self,learn_more_link):
        self.action_chain_enter_text(self.PACKAGES_LEARN_MORE_LINK, learn_more_link)


    def select_Resource(self, searchstring='Default'):
        self.element_click(self.PACKAGES_RESOURCE_ADD)
        time.sleep(3)
        if(searchstring != None):
            self.element_set_text(self.PACKAGES_RESOURCE_SEARCH, searchstring, required_clear=True)
            time.sleep(2)
            self.element_click(self.PACKAGES_RESOURCE_FIRST_CHECK)
        elif(searchstring == None):
            self.element_click(self.PACKAGE_CANCEL_ADD_RESOURCES)
            return
        else:
            self.element_click(self.PACKAGES_RESOURCE_FIRST_CHECK)
        self.element_click(self.PACKAGES_RESOURCE_ADD_LIST)

    def select_Compatible_OS(self, searchstring=None):
        self.element_click(self.PACKAGES_ADDCOMPATIBLE_OS_ADD)
        time.sleep(3)
        if(searchstring != None):
            self.element_set_text(self.PACKAGES_ADDCOMPATIBLE_OS_SEARCH, searchstring, required_clear=True)
            time.sleep(2)
            self.element_click(self.PACKAGES_ADDCOMPATIBLE_OS_FIRST_CHECK) 
        elif(searchstring == None):
            self.element_click(self.PACKAGE_CANCEL_ADD_RESOURCES)
            return 
        else:
            self.element_click(self.PACKAGES_ADDCOMPATIBLE_OS_FIRST_CHECK)
        self.element_click(self.PACKAGES_ADDCOMPATIBLE_OS_ADD_LIST)

    def select_HelmChart(self, searchstring=None):
        self.element_click(self.PACKAGES_HELMCHARTS_ADD)
        time.sleep(3)
        if(searchstring != None):
            self.element_set_text(self.PACKAGES_HELMCHARTS_SEARCH, searchstring, required_clear=True)
            time.sleep(2)
            self.element_click(self.PACKAGES_HELMCHARTS_FIRST_CHECK)
        elif(searchstring == None):
            self.element_click(self.PACKAGE_CANCEL_ADD_RESOURCES)
            return
        else:
            self.element_click(self.PACKAGES_HELMCHARTS_FIRST_CHECK)
        self.element_click(self.PACKAGES_HELMCHARTS_ADD_LIST)

    def select_Containers(self, searchstring=None):
        self.element_click(self.PACKAGES_CONTAINERS_ADD)
        time.sleep(3)
        if(searchstring != None):
            self.element_set_text(self.PACKAGES_CONTAINERS_SEARCH, searchstring, required_clear=True)
            time.sleep(2)
            self.element_click(self.PACKAGES_CONTAINERS_FIRST_CHECK)
        elif(searchstring == None):
            self.element_click(self.PACKAGE_CANCEL_ADD_RESOURCES)
            return
        else:
            self.element_click(self.PACKAGES_CONTAINERS_FIRST_CHECK)
        self.element_click(self.PACKAGES_CONTAINERS_ADD_LIST)

    def select_Modules(self, searchstring=None):
        self.element_click(self.PACKAGES_MODULES_ADD)
        time.sleep(3)
        if(searchstring != None):
            self.element_set_text(self.PACKAGES_MODULES_SEARCH, searchstring, required_clear=True)
            time.sleep(2)
            self.element_click(self.PACKAGES_MODULES_FIRST_CHECK)
        elif(searchstring == None):
            self.element_click(self.PACKAGE_CANCEL_ADD_RESOURCES)
            return
        else:
            self.element_click(self.PACKAGES_MODULES_FIRST_CHECK)
        self.element_click(self.PACKAGES_MODULES_ADD_LIST)

    def select_Online_Distribution(self, searchstring=None):
        self.element_click(self.PACKAGES_ONLINE_DISTRIBUTION_ADD)
        time.sleep(3)
        if(searchstring != None):
            ls = searchstring.split('|')
            for s in ls:
                self.element_set_text(self.PACKAGES_ONLINE_DISTRIBUTION_SEARCH, s, True)
                time.sleep(2)
                self.element_click(self.PACKAGES_ONLINE_DISTRIBUTION_FIRST_CHECK)
        elif(searchstring == None):
            self.element_click(self.PACKAGE_CANCEL_ADD_RESOURCES)
            return
        else:
            self.element_click(self.PACKAGES_ONLINE_DISTRIBUTION_FIRST_CHECK)
        self.element_click(self.PACKAGES_ONLINE_DISTRIBUTION_ADD_LIST)


    def create_Approval_Order(self, approval_data:str):

        from selenium.webdriver.common.keys import Keys
        from selenium.webdriver import ActionChains

        # Return in case of blank string for approval_data
        if not approval_data:
            return

        approval_combinations:list = approval_data.split('|')
        if len(approval_combinations) > 2:
            # Adding more input fields
            self.element_click(self.PACKAGES_ADD_NEW_APPROVER_BUTTON)
        items = WebDriverWait(self.driver, 20).until(EC.visibility_of_all_elements_located((By.CLASS_NAME, "addApprovalType")))

        def enter_details(text_to_enter, field_webelement):
            actions = ActionChains(self.driver)
            actions.move_to_element(field_webelement)
            actions.click(field_webelement)
            actions.send_keys(text_to_enter)
            actions.send_keys(Keys.ENTER)
            actions.send_keys(Keys.ESCAPE)
            actions.perform()


        for r in range(len(approval_combinations)):
            approval_c = approval_combinations[r]
            approval_type = approval_c.split('-')[0]
            approval_name = approval_c.split('-')[1]
            no_of_fields = items[r]
            approval_type_webelement = no_of_fields.find_element_by_class_name('typeDropdown')
            approval_user_webelement = no_of_fields.find_element_by_class_name('userDropdown')
            enter_details(approval_type, approval_type_webelement)
            enter_details(approval_name, approval_user_webelement)
    

    def select_Co_Owners(self, Co_Owners):
        self.element_set_text(self.PACKAGES_VERIFY_CO_OWNERS, Co_Owners)
        time.sleep(2)
        self.press_enter_key(self.PACKAGES_VERIFY_CO_OWNERS)

    def promote_Package(self, promote_env):
        env_dropdown = (By.XPATH, "//div[@class='intel__catalog__container']/div[2]/div/label/span[contains(text(), '{0}')]".format(promote_env))
        self.element_click(env_dropdown)
        self.element_click(self.PACKAGES_ACTION_PROMOTE)
        success_message = self.element_get_text(self.TOAST_MSG_SUB_TEXT)

        return success_message

    def select_Package_Save(self):
        self.element_click(self.PACKAGES_SAVE)
        success_message = self.element_get_text(self.TOAST_MSG_SUB_TEXT)
        self.wait_loader_to_vanish()

        return success_message

    def cancel_Save_Package(self):
        self.element_click(self.PACKAGES_CANCEL_SAVE)
        time.sleep(2)
        self.element_click(self.PACKAGES_POPUP_YES_BUTTON)


    def select_Delete_Yes(self):
        self.element_click(self.PACKAGES_POPUP_YES_BUTTON)
        self.wait_loader_to_vanish()
        # time.sleep(5)
        confirmation_message = self.element_get_text(self.TOAST_MSG_SUB_TEXT)
        return confirmation_message

    def select_Delete_Cancel(self):
        self.element_click(self.PACKAGES_POPUP_CLOSE_BUTTON)
        self.wait_loader_to_vanish()

    def check_Save_Button_Disables(self):
        try:
            self.element_is_clickable(self.PACKAGES_SAVE)
            return True
        except:
            return False

    def toast_msg_close(self):
        items = self.driver.find_elements(By.XPATH, "//div[@class='Toastify']/div/div/button[@aria-label='close']")
        for item in items:
            item.click()
            time.sleep(1)


    def error_recovery(self):
        try:
            self.toast_msg_close()
        except Exception as e:
            pass
        try:
            self.element_click_fast(self.PACKAGES_CANCEL_SAVE)
        except Exception as e:
            pass
        try:
            self.element_click_fast(self.PACKAGES_POPUP_YES_BUTTON)
        except Exception as e:
            pass

    def select_filter(self, tag_name):
        '''
        This method deals with filter tags in MC
        *It first deletes the existing filter tag selected if any are there
        *Then adds given number of filter tags
        '''
        return
        #deleting existing filter tags
        try:
            exisitng_filtertags = self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")
            for tag in exisitng_filtertags:
                tag.click()
        except Exception as e:
            # No filter tag found
            print('No exisiting filter tag found.')
        # Adding existing 2 filters
        count = 0
        self.element_click(self.SELECT_FILTER_TAG_DROPDOWN)
        if tag_name == 'existing':
            available_filter_tags =  self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/div/div[@role='option']")
            for wb in available_filter_tags:
                self.element_set_text(self.FILTERTAG_NAME, str(wb.text) + '_filter, ')
                self.element_set_text(self.FILTERTAG_HELP, str(wb.text) + '_filter, ')
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                wb.click()
                count+=1
                if count == 2:
                    break         
        else:
            filter_tags = str(tag_name).split('|')
            for item in filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                ADD_FILTERS_OPTION = (By.XPATH,"//span[contains(text(),'{0}')]".format(item))
                self.element_click(ADD_FILTERS_OPTION)

    def verify_packages_table_is_loaded(self):
        self.wait_loader_to_vanish()
        return self.data_table_visiblity()
    
    def verify_packages_table_columns(self, headers_list):
        self.wait_loader_to_vanish()

        for element in headers_list:
            col_xpath = (By.XPATH, '//thead[@data-test="datatable-head"]/tr/th/span[contains(text(), "{0}")]'.format(element))
            if not self.element_visible(col_xpath):
                return False
        return True

    def read_package_name_from_section(self):
        self.wait_loader_to_vanish()
        name_of_existing_package = self.element_get_text(self.PACKAGES_READ_EXISTING_NAME)

        return name_of_existing_package

    def get_build_status(self):
        self.element_click(self.PACKAGES_GET_BUILD_STATUS_REFRESH)
        time.sleep(3)
        currentstatus = self.element_get_text(self.PACKAGES_GET_BUILD_STATUS)
        return currentstatus

    def get_Jenkins_Path(self):
        jenkins_url = self.element_get_attribute_value(self.PACKAGES_TEXT_JENKINS_PATH)
        return jenkins_url
    
    def confirm_Delete_Verify_Message(self):
        try:
            self.element_click(self.PACKAGES_POPUP_YES_BUTTON)
            self.wait_loader_to_vanish()
            # time.sleep(5)
            success = self.element_get_text(self.TOAST_MSG_TEXT)
            confirmation_message = self.element_get_text(self.TOAST_MSG_SUB_TEXT)
            return confirmation_message
        except Exception as e:
            print('Failed to verify delete message -')
            return False

    def get_GitHub_JenkinsURLs(self, packagename):
        xpath = "//td/span[contains(text(),'" + packagename + "')]/ancestor::tr/td/span/a"
        print(xpath)
        elements = self.driver.find_elements(By.XPATH, xpath)
        urls = []
        for i in elements:
            print(i.get_attribute('href'))
            urls.append(i.get_attribute('href'))
        return urls

    def periodic_build_status_checker(self, pkg_name, attempts = 10):
        current_status = ''
        self.search_Package_And_Perform_Action(pkg_name, "TRIGGER BUILD")
        while (current_status != 'Success' and attempts >0):
            current_status = self.get_build_status()
            self.wait_loader_to_vanish()
            time.sleep(10)
            attempts-=1
        return True if current_status=='Success' else False
    
    def search_Package(self, package_name_uuid):
        pkg_name_uuid = str(package_name_uuid).split('/')
        if len(pkg_name_uuid) >1:
            package_name = pkg_name_uuid[0]
            package_uuid = pkg_name_uuid[1]
            self.element_set_text(self.PACKAGES_COMMON_SEARCH, package_uuid, True)

        else:
            package_name = pkg_name_uuid[0]
            self.element_set_text(self.PACKAGES_COMMON_SEARCH, package_name, True)

        elem = (By.XPATH, "//td/span[contains(text(),'" + package_name + "')]")
        return self.element_visible(elem)

    def search_Package_And_Perform_Action(self,package_name, action):
        self.element_set_text(self.PACKAGES_COMMON_SEARCH,package_name, True)
        elem = (By.XPATH,"//td/span[contains(text(),'" + package_name + "')]/ancestor::tr/td[8]/div/div")
        self.element_click(elem)
        if action == "EDIT":
            self.element_click(self.PACKAGES_ACTION_EDIT)
        elif action == "DELETE":
            pass
            #self.element_click(self.PACKAGES_ACTION_DELETE)
        elif action == "TRIGGER BUILD":
            initialstatus = self.element_get_text(self.PACKAGES_GET_BUILD_STATUS)
            self.element_click(self.PACKAGES_ACTION_TRIGGER_BUILD)
            time.sleep(4)
            currentstatus = self.element_get_text(self.PACKAGES_GET_BUILD_STATUS)
            print("Build status after build trigger :  " + currentstatus)
            self.element_click(self.PACKAGES_GET_BUILD_STATUS_REFRESH)
            time.sleep(3)
            currentstatus = self.element_get_text(self.PACKAGES_GET_BUILD_STATUS)
            print("Build status after refresh :  " + currentstatus)
        elif action == "PROMOTE":
            elem = (By.XPATH,"//td/span[contains(text(),'"+package_name +"')]/../..//span[contains(text(), 'Promote')]")
            self.element_click(elem)
        elif action == "CLONE":
            self.element_click(self.PACKAGES_ACTION_CLONE)
        time.sleep(3)

    def enter_Create_Package_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()

        print("TestData")

        package_name = TestData["Name"] + uniquestr if(str(TestData["Name"]) != "None") else ""

        self.navigate_to_Package_Page()

        if not package_name.startswith('Auto_'):
            if package_name.startswith('Existing'):
                package_name = self.read_package_name_from_section()
        print(TestData["Name"])

        self.navigate_to_Create_Package()
        self.enter_Name(package_name)
        self.enter_Display_Name(TestData["Display_Name"]+uniquestr)
        self.enter_Discription(TestData["Description"]+uniquestr)
        #self.enter_More_Info(TestData["More_Info"])

        # Add Translations(Chinese)
        if (TestData["Add_Translation"]).upper() == 'YES':
            self.select_add_Translation()
            self.select_launguage('ch')
            self.enter_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Display_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Discription_Ch( TestData["Description"]+uniquestr if (str(TestData["Description"])!= "None") else "")

        self.enter_Version_Name( TestData["Version_Number"]+uniquestr if (str(TestData["Version_Number"])!= "None") else "" )
        self.enter_IRC_ID( str(uuid4()) if (str(TestData["IRC_ID"])!= "None") else "" )
        self.enter_Documentation_link( TestData["Documentation_Link"])
        self.enter_Packages_Class(TestData["Package_Class"])
        self.enter_UI_Route( TestData["UI_Route"]+uniquestr if (str(TestData["UI_Route"])!= "None") else "" )
        self.enter_HW_Requirements_Link( TestData["HW_Requirements_Link"])
        if TestData["Package_Class"] == 'Online Distribution':
            self.select_Online_Distribution(searchstring=TestData['Online_Distribution'])
            self.select_Authentication( TestData["Is_Authentication"])
        else:
            self.enter_Tag_Name( TestData["Tag_Name"]+uniquestr if (str(TestData["Tag_Name"])!= "None") else "" )
            self.select_Enable_Product_Key( TestData["Product_Key"])
            self.enter_GIThub_Path( TestData["Git_Path"] if (str(TestData["Git_Path"])!= "None") else "" )
            #self.enter_Jenkins_Path( TestData["Jenkins_Path"]+uniquestr if (str(TestData["Jenkins_Path"])!= "None") else "" )
            self.enter_License_Type( TestData["License_Type"])
            self.enter_Packages_GSG( TestData["Packages_GSG"])
            self.enter_Memory_Required( TestData["Memory_Required"])
            self.enter_HDisk_Space_Required( TestData["HDisk_Space_Required"])
            self.enter_ZIP_Lable( TestData["ZIP_Lable"]+uniquestr if (str(TestData["ZIP_Lable"])!= "None") else "" )
            self.select_Customizable( TestData["Customizable"])
            self.enter_Default_HW( TestData["Default_HW"]+uniquestr if (str(TestData["Default_HW"])!= "None") else "" )
            self.enter_Support_Link( TestData["Support_Link"])
            self.enter_Learn_More_Link( TestData["Learn_More_Link"])
            self.select_Resource(searchstring=TestData['Resource_Name'])
            self.select_Compatible_OS(searchstring=TestData['Compatible_OS'])
            self.select_HelmChart(searchstring=TestData['Helm_Charts'])
            self.select_Containers(searchstring=TestData['Containers'])
            self.select_Modules(searchstring=TestData['Modules'])
        self.select_filter(TestData['Filter_Tag'])
        self.create_Approval_Order(TestData['Multi-Approvers'] if (str(TestData['Multi-Approvers'])!= "None") else "" )
        self.select_Co_Owners(TestData['Co_Owners'] if (str(TestData["Co_Owners"])!= "None") else "")
        if TestData['ReadMe_file']=='Yes':
            self.upload_readme_file(PackagesActions.get_readme_file_path())
        if TestData['Documentation_file']=='Yes':
            self.upload_documentation_file(PackagesActions.get_documentation_file_path())
        

        return package_name

    def enter_Update_Package_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()

        
        self.navigate_to_Package_Page()
        self.search_Package_And_Perform_Action(TestData['Name'], 'EDIT')
        #self.search_Package_And_Perform_Action('ApprovedOD_Package', 'EDIT')
        
        self.enter_Display_Name(TestData["Display_Name"]+uniquestr)
        self.enter_Discription(TestData["Description"]+uniquestr)
        #self.enter_More_Info(TestData["More_Info"])

        # Add Translations(Chinese)
        if (TestData["Add_Translation"]).upper() == 'YES':
            self.select_add_Translation()
            self.select_launguage('ch')
            self.enter_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Display_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Discription_Ch( TestData["Description"]+uniquestr if (str(TestData["Description"])!= "None") else "")

        self.enter_Version_Name( TestData["Version_Number"]+uniquestr if (str(TestData["Version_Number"])!= "None") else "" )
        self.enter_IRC_ID( TestData["IRC_ID"]+uniquestr if (str(TestData["IRC_ID"])!= "None") else "" )
        self.enter_Documentation_link( TestData["Documentation_Link"])
        self.enter_Packages_Class(TestData["Package_Class"])
        self.enter_UI_Route( TestData["UI_Route"]+uniquestr if (str(TestData["UI_Route"])!= "None") else "" )
        self.enter_HW_Requirements_Link( TestData["HW_Requirements_Link"])
        if TestData["Package_Class"] == 'Online Distribution':
            self.select_Authentication( TestData["Is_Authentication"])
            self.select_Online_Distribution(searchstring=TestData['Online_Distribution'])
        else:
            self.enter_Tag_Name( TestData["Tag_Name"]+uniquestr if (str(TestData["Tag_Name"])!= "None") else "" )
            self.select_Enable_Product_Key( TestData["Product_Key"])
            self.enter_GIThub_Path( TestData["Git_Path"] if (str(TestData["Git_Path"])!= "None") else "" )
            #self.enter_Jenkins_Path( TestData["Jenkins_Path"]+uniquestr if (str(TestData["Jenkins_Path"])!= "None") else "" )
            self.enter_License_Type( TestData["License_Type"])
            self.enter_Packages_GSG( TestData["Packages_GSG"])
            self.enter_Memory_Required( TestData["Memory_Required"])
            self.enter_HDisk_Space_Required( TestData["HDisk_Space_Required"])
            self.enter_ZIP_Lable( TestData["ZIP_Lable"]+uniquestr if (str(TestData["ZIP_Lable"])!= "None") else "" )
            self.select_Customizable( TestData["Customizable"])
            self.enter_Default_HW( TestData["Default_HW"]+uniquestr if (str(TestData["Default_HW"])!= "None") else "" )
            self.enter_Support_Link( TestData["Support_Link"])
            self.enter_Learn_More_Link( TestData["Learn_More_Link"])
            self.select_Resource(searchstring=TestData['Resource_Name'])
            self.select_Compatible_OS(searchstring=TestData['Compatible_OS'])
            self.select_HelmChart(searchstring=TestData['Helm_Charts'])
            self.select_Containers(searchstring=TestData['Containers'])
            self.select_Modules(searchstring=TestData['Modules'])
        self.select_filter(TestData['Filter_Tag'])
        self.create_Approval_Order(TestData['Multi-Approvers'] if (str(TestData['Multi-Approvers'])!= "None") else "" )
        self.select_Co_Owners(TestData['Co_Owners'] if (str(TestData["Learn_More_Link"])!= "None") else "")

    def enter_Clone_Package_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()

        print("TestData")
        print(TestData["Name"])

        self.enter_Name(TestData['Name'])
        self.enter_Display_Name(TestData["Display_Name"]+uniquestr)
        self.enter_Discription(TestData["Description"]+uniquestr)
        #self.enter_More_Info(TestData["More_Info"])

        # Add Translations(Chinese)
        if (TestData["Add_Translation"]).upper() == 'YES':
            self.select_add_Translation()
            self.select_launguage('ch')
            self.enter_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Display_Name_Ch('包裹_'+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
            self.enter_Discription_Ch( TestData["Description"]+uniquestr if (str(TestData["Description"])!= "None") else "")

        self.enter_Version_Name( TestData["Version_Number"]+uniquestr if (str(TestData["Version_Number"])!= "None") else "" )
        self.enter_IRC_ID( TestData["IRC_ID"]+uniquestr if (str(TestData["IRC_ID"])!= "None") else "" )
        self.enter_Documentation_link( TestData["Documentation_Link"]+uniquestr if (str(TestData["Documentation_Link"])!= "None") else "" )
        self.enter_Packages_Class(TestData["Package_Class"])
        self.enter_UI_Route( TestData["UI_Route"]+uniquestr if (str(TestData["UI_Route"])!= "None") else "" )
        self.enter_HW_Requirements_Link( TestData["HW_Requirements_Link"])
        if TestData["Package_Class"] == 'Online Distribution':
            self.select_Authentication( TestData["Is_Authentication"])
            self.select_Online_Distribution(searchstring=TestData['Online_Distribution'])
        else:
            self.enter_Tag_Name( TestData["Tag_Name"]+uniquestr if (str(TestData["Tag_Name"])!= "None") else "" )
            self.select_Enable_Product_Key( TestData["Product_Key"])
            self.enter_GIThub_Path( TestData["Git_Path"]+uniquestr if (str(TestData["Git_Path"])!= "None") else "" )
            #self.enter_Jenkins_Path( TestData["Jenkins_Path"]+uniquestr if (str(TestData["Jenkins_Path"])!= "None") else "" )
            self.enter_License_Type( TestData["License_Type"])
            self.enter_Packages_GSG( TestData["Packages_GSG"]+uniquestr if (str(TestData["Packages_GSG"])!= "None") else "" )
            self.enter_Memory_Required( TestData["Memory_Required"])
            self.enter_HDisk_Space_Required( TestData["HDisk_Space_Required"])
            self.enter_ZIP_Lable( TestData["ZIP_Lable"]+uniquestr if (str(TestData["ZIP_Lable"])!= "None") else "" )
            self.select_Customizable( TestData["Customizable"])
            self.enter_Default_HW( TestData["Default_HW"]+uniquestr if (str(TestData["Default_HW"])!= "None") else "" )
            self.enter_Support_Link( TestData["Support_Link"])
            self.enter_Learn_More_Link( TestData["Learn_More_Link"])

        #self.select_filter(TestData['Filter_Tag'])
        self.create_Approval_Order(TestData['Multi-Approvers'] if (str(TestData['Multi-Approvers'])!= "None") else "" )
        self.select_Co_Owners(TestData['Co_Owners'] if (str(TestData["Learn_More_Link"])!= "None") else "")

    def promote_Package_Data(self, TestData):
        if str(TestData['Promote_Env'])!= "None":
            self.navigate_to_Package_Page()
            self.search_Package_And_Perform_Action(TestData["Name"], "PROMOTE")
        # Actual package promotion happens if this is POSITIVE test case

# Data Fetch Methods

    @staticmethod
    def get_Create_Package_Data():
        data_Create_Package = fo.File_Operations().get_csv_data(mc.packages_data_file,"CREATE")
        return data_Create_Package

    @staticmethod
    def get_Update_Package_Data():
        data_Update_Package = fo.File_Operations().get_csv_data(mc.packages_data_file,"UPDATE")
        return data_Update_Package

    @staticmethod
    def get_Parameters():
        parameterlist = mc.packages_columns_list
        return parameterlist

    @staticmethod
    def get_documentation_file_path():
        doc_path = mc.documentation_file_upload
        return doc_path

    @staticmethod
    def get_readme_file_path():
        readme_path = mc.readme_file_upload
        return readme_path

    @staticmethod
    def get_Package_TestData_As_JSON(action):
        data_Update_Package = fo.File_Operations().get_csv_data_as_Dataframe(mc.packages_data_file,action)
        data_Update_Package_JSON = data_Update_Package.to_json(orient="records")
        data_Update_Package_JSON = json.loads(data_Update_Package_JSON)
        print(data_Update_Package_JSON)
        return data_Update_Package_JSON

    @staticmethod
    def get_E2E_TestData_As_JSON(action):
        data_Update_E2E = fo.File_Operations().get_csv_data_as_Dataframe(mc.e2e_data_file,action)
        data_Update_E2E_JSON = data_Update_E2E.to_json(orient="records")
        data_Update_E2E_JSON = json.loads(data_Update_E2E_JSON)
        print(data_Update_E2E_JSON)
        return data_Update_E2E_JSON