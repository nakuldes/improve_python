import pytest
from selenium.webdriver.common.by import By
from .BasePage import WebActions
from selenium.webdriver.support.ui import WebDriverWait
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from utils import FileOperations as fo
from configs import ManagementConsole as mc
import json
import utils.common


class ModulesActions(WebActions):

    def __init__(self, driver):
        super().__init__(driver)

    """ Page Locators """
    MODULES_LINK = (By.XPATH, "//span[contains(text(),'Modules')]")
    MODULES_LINK11 = (By.ID, "accordion__heading-raa-3weweew")
    MODULES_BUTTON_CREATE_NEW = (By.XPATH, "//button/span[contains(text(),'Create Module')]")
    MODULES_TITLE_CREATE_MODULE = (By.XPATH, "//span[contains(text(),'Create')]")
    MODULES_TEXT_NAME = (By.NAME, "ingrdtName")
    MODULES_TEXT_DISPLAY_NAME = (By.NAME, "displayName")
    MODULES_TEXT_DESCRIPTION = (By.NAME, "ingrdtDesc")
    MODULES_TEXT_MORE_INFO = (By.ID, "tinymce")

    MODULES_TEXT_VERSION_NAME = (By.NAME, "displayVersion")
    MODULES_SELECT_DEPENDENCY_TYPE = (By.XPATH, "//select[@name='ingredientType']")
    MODULES_TEXT_GIT_PATH = (By.NAME, "fullGitlabPath")
    MODULES_CUSTOM_BRANCH_RADIO_OPTION_YES = (By.XPATH, "//input[@name='isbranch-yes']")
    MODULES_TEXT_CUSTOM_BRANCH = (By.XPATH, "//input[@name='branch']")
    MODULES_TEXT_MORE_INFO_LINK = (By.NAME, "moreInfoLink")
    MODULES_TEXT_RELEASE_TAG = (By.NAME, "releaseTag")
    MODULES_TEXT_FOLDER_NAME = (By.NAME, "label")
    MODULES_TEXT_JENKINS_PATH = (By.NAME, "fullJenkinsPath")

    MODULES_RADIO_DEFAULT_INSTALLATION = (By.XPATH, "//input[@name='isinstall-yes']")
    # MODULES_RADIO_DISABLE_JENKINS = (By.XPATH,"//input[@name='jobNotRequired-yes']")
    MODULES_RADIO_DISABLE_JENKINS = (By.XPATH, "//input[@name = 'jobNotRequired-yes']")
    MODULES_UNSUPPORTED_COUNTRIES_DROP_DOWN_ICON = (By.CLASS_NAME, "dropdown icon")
    MODULES_UNSUPPORTED_COUNTRIES = (
    By.XPATH, "//body/div[@id='root']/div[@id='app']/div[2]/div[2]/div[1]/div[2]/div[1]/div[7]/div[2]/div[1]")

    MODULES_ADDCOMPATIBLE_OS_ADD = (By.XPATH, "//span[contains(text(),'Compatible OS')]//following-sibling::div/span")
    MODULES_ADD_COMPATIBLE_HARDWARE = (
    By.XPATH, "//span[contains(text(),'Compatible Hardware')]//following-sibling::div/span")
    MODULES_ADD_DEPENDENT_MODULES = (
    By.XPATH, "//span[contains(text(),'Dependent Modules')]//following-sibling::div/span")

    MODULES_ADDCOMPATIBLE_COMMON_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    MODULES_ADDCOMPATIBLE_COMMON_TABLE = (By.XPATH, "//tbody")
    MODULES_ADDCOMPATIBLE_COMMON_FIRST_CHECK = (By.XPATH, "//tbody/tr[1]/td[1]/div/span")
    MODULES_ADDCOMPATIBLE_COMMON_ADD_LIST = (By.CSS_SELECTOR, ".buttonClass:nth-child(2) > span")
    MODULES_ADDCOMPATIBLE_COMMON_CANCEL = (By.CSS_SELECTOR, ".buttonClass:nth-child(1) > span")

    # Filter Tag field
    FILTERTAG_NAME = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder='Name in English']")
    FILTERTAG_HELP = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder=' Add Help Text Here.']")
    SELECT_FILTERTAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/input")
    SELECT_FILTER_TAG_DROPDOWN = (By.XPATH, "//div[@role='combobox']/div[contains(text(), 'Tags')]")
    DELETE_EXISTING_FILTER_TAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")


    # MODULES_ADD_FILTERS = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/input")
    MODULES_SAVE = (By.XPATH, "//span[contains(text(),'Save Module')]")
    MODULES_CANCEL = (By.XPATH, "//button[@class='buttonClass cancelbuttonClass']/span[contains(.,'Cancel')]")
    # MODULES_CANCEL_YES = (By.XPATH,"//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/button[2]/span[1]")
    MODULES_CANCEL_YES = (By.XPATH, "//button/span[contains(text(),'Yes')]")
    MODULES_CANCEL_CLOSE = (By.XPATH, "//span[contains(text(),'Close')]")

    MODULES_COMMON_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    MODULES_ACTION_OPTION = (By.CLASS_NAME, "ui dropdown  text-primary ")
    MODULES_ACTION_EDIT = (By.XPATH, "//span[contains(text(),'Edit')]")
    MODULES_ACTION_DELETE = (By.XPATH, "//span[contains(text(),'Delete')]")
    MODULES_ACTION_TRIGGER_BUILD = (By.XPATH, "//span[contains(text(),'Trigger Build')]")
    MODULES_ACTION_CLONE = (By.XPATH, "//span[contains(text(),'Clone')]")
    MODULES_GET_BUILD_STATUS = (By.XPATH, "//span[@class='statusText']/span")
    MODULES_GET_BUILD_STATUS_REFRESH = (By.XPATH, "//span[@class='pointerDiv']/i")

    MODULE_SAVE_SUCCESS = (By.XPATH, "//span[@class='toast_msg']")
    MODULE_SAVE_SUCCESS_MESSAGE = (By.XPATH, "//span[@class='toast_submsg']")
    MODULE_ALERT_MESSAGE_CLOSE = (By.XPATH,"//button[@class='Toastify__close-button Toastify__close-button--light'")
    MODULE_GITHUB_JENKIN_URLS = (By.XPATH, "//td[contains(text(),'Auto_Module_DisplayName_20220517153058')]/ancestor::tr/td/span")


    """ MOdules Page Actions """

    def navigate_to_Modules_Page(self):
        try:
            # self.wait_loader_to_vanish()
            self.element_click(self.MODULES_LINK)
            self.wait_loader_to_vanish()
        except Exception as e:
            print("Exception occured during Module page navigation - " + str(e))
            self.driver.refresh()
            self.wait_loader_to_vanish()
            self.element_click(self.MODULES_LINK)
            self.wait_loader_to_vanish()
        # time.sleep(15)

    def navigate_to_Create_Module(self):
        self.wait_loader_to_vanish()
        time.sleep(2)
        self.element_click(self.MODULES_BUTTON_CREATE_NEW)
        self.wait_loader_to_vanish()
        # time.sleep(5)

    def enter_Name(self, name):
        self.element_set_text(self.MODULES_TEXT_NAME, name)

    def enter_Display_Name(self, displayname, required_clear=False):
        self.element_set_text(self.MODULES_TEXT_DISPLAY_NAME, displayname, required_clear)

    def enter_Discription(self, description, required_clear=False):
        self.element_set_text(self.MODULES_TEXT_DESCRIPTION, description, required_clear)

    def enter_More_Info(self, moreinfo, required_clear=False):
        self.element_set_text(self.MODULES_TEXT_MORE_INFO, moreinfo, required_clear)

    def enter_Version_Name(self, version, required_clear=False):
        self.element_set_text(self.MODULES_TEXT_VERSION_NAME, version, required_clear)

    def select_Dependency_Type(self, dependency):
        # self.select_element_from_dropdown(self.MODULES_SELECT_DEPENDENCY_TYPE,dependency)
        # option = "//option[contains(text(),'" + dependency + "')]"
        # elem = self.driver.find_element(By.XPATH,"option")
        # dropdw = Select(self.driver.find_element(self.MODULES_SELECT_DEPENDENCY_TYPE))
        dropdw = Select(
            WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(self.MODULES_SELECT_DEPENDENCY_TYPE)))
        dropdw.select_by_value("5efd7b9020e370002a12feca")

    def enter_GIT_Path(self, gitpath, required_clear=False):
        self.element_set_text(self.MODULES_TEXT_GIT_PATH, gitpath, required_clear)

    def select_Custom_Branch(self, option, branchname=None, required_clear=False):
        # select options
        if (option.upper() == "YES"):
            # self.element_click(self.MODULES_CUSTOM_BRANCH_RADIO_OPTION_YES)
            self.element_click(self.MODULES_CUSTOM_BRANCH_RADIO_OPTION_YES)
            self.element_set_text(self.MODULES_TEXT_CUSTOM_BRANCH, branchname, required_clear)

    def enter_More_Info_Link(self, moreinfolink, required_clear=False):
        self.element_set_text(self.MODULES_TEXT_MORE_INFO_LINK, moreinfolink, required_clear)

    def enter_Release_Tag(self, releasetag, required_clear=False):
        self.element_set_text(self.MODULES_TEXT_RELEASE_TAG, releasetag, required_clear)

    def enter_Folder_Name(self, foldername, required_clear=False):
        self.element_set_text(self.MODULES_TEXT_FOLDER_NAME, foldername, required_clear)

    def enter_Jenkins_Job(self, jenkinsurl):
        self.element_set_text(self.MODULES_TEXT_JENKINS_PATH, jenkinsurl)

    def select_Default_Installation(self, option):
        if (str(option).upper() == "YES"):
            self.element_click_on_presence(self.MODULES_RADIO_DEFAULT_INSTALLATION)

    def select_Disable_Jenkins(self, option):
        if (str(option).upper() == "YES"):
            self.element_click_on_presence(self.MODULES_RADIO_DISABLE_JENKINS)
            # self.action_chain_moveTo_Click(self.MODULES_RADIO_DISABLE_JENKINS)

    def select_Unsupported_Countries(self, country):
        self.page_scroll_to_page_end()
        self.element_click(self.MODULES_UNSUPPORTED_COUNTRIES)
        time.sleep(3)
        # self.element_set_text(self.MODULES_UNSUPPORTED_COUNTRIES,country)
        # self.element_send_keys(self.MODULES_UNSUPPORTED_COUNTRIES,"I")
        # time.sleep(3)
        # xpathstring = "//span[contains(text(),'" + country + "')]"
        MODULE_COUNTRY_OPTION = (By.XPATH, "//span[contains(text(),'Austria')]")
        self.element_click(MODULE_COUNTRY_OPTION)

    def select_Compatible_OS(self, searchstring=None):
        try:
            self.element_click(self.MODULES_ADDCOMPATIBLE_OS_ADD)
            time.sleep(3)
            if (searchstring != None):
                self.element_set_text(self.MODULES_ADDCOMPATIBLE_COMMON_SEARCH, searchstring)
                self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_FIRST_CHECK)
            else:
                self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_FIRST_CHECK)
            result = self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_ADD_LIST)
            time.sleep(2)
        except:
            self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_CANCEL)
            self.element_click(self.MODULES_LINK)
            self.element_click(self.MODULES_CANCEL_YES)
            return False

    def select_Compatible_Hardware(self, searchstring):
        try:
            self.element_click(self.MODULES_ADD_COMPATIBLE_HARDWARE)
            time.sleep(3)
            if (searchstring != None):
                self.element_set_text(self.MODULES_ADDCOMPATIBLE_COMMON_SEARCH, searchstring)
                time.sleep(2)
                self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_FIRST_CHECK)
            else:
                self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_FIRST_CHECK)
            result = self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_ADD_LIST)
            time.sleep(2)
        except:
            self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_CANCEL)
            self.element_click(self.MODULES_CANCEL)
            self.element_click(self.MODULES_CANCEL_YES)
            return False
            # pytest.fail(" Could not found the compatible hardware provided")

    def select_Dependent_Modules(self, modules):
        try:
            if (modules != ""):
                self.element_click(self.MODULES_ADD_DEPENDENT_MODULES)
                time.sleep(3)
                self.element_set_text(self.MODULES_ADDCOMPATIBLE_COMMON_SEARCH, modules)
                time.sleep(2)
                self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_FIRST_CHECK)
            result = self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_ADD_LIST)
            time.sleep(2)
        except:
            self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_CANCEL)
            self.element_click(self.MODULES_CANCEL)
            self.element_click(self.MODULES_CANCEL_YES)
            return False
            # pytest.fail(" Could not found the compatible hardware provided")

    def select_filter(self, tag_name):
        '''
        This method deals with filter tags in MC
        *It first deletes the existing filter tag selected if any are there
        *Then adds given number of filter tags
        '''
        #deleting existing filter tags
        return
        try:
            exisitng_filtertags = self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")
            for tag in exisitng_filtertags:
                tag.click()
        except Exception as e:
            # No filter tag found
            print('No exisiting filter tag found.')
        # Adding existing 2 filters
        count = 0
        self.element_click(self.SELECT_FILTER_TAG_DROPDOWN)
        if tag_name == 'existing':
            available_filter_tags =  self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/div/div[@role='option']")
            for wb in available_filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                wb.click()
                count+=1
                if count == 2:
                    break         
        else:
            filter_tags = str(tag_name).split('|')
            for item in filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                ADD_FILTERS_OPTION = (By.XPATH,"//span[contains(text(),'{0}')]".format(item))
                self.element_click(ADD_FILTERS_OPTION)       
        self.press_esc_key()

    def save_Module(self):

        self.element_click(self.MODULES_SAVE)
        # time.sleep(5)

        # if self.verify_if_element_is_displayed(self.MODULES_SAVE) == False and self.check_Save_Button_Disables == False:
        #     self.element_click(self.MODULES_LINK)
        #     self.element_click(self.MODULES_CANCEL_YES)
        #     pytest.fail("Module Save has failed")
        # else:
        #     # if self.verify_if_element_is_displayed(self.MODULES_TITLE_CREATE_MODULE) != False:
        #     success = self.element_get_text(self.MODULE_SAVE_SUCCESS)
        #     success_message = self.element_get_text(self.MODULE_SAVE_SUCCESS_MESSAGE)
        #     assert success == "Success"
        #     return success_message
        try:
            success = self.element_get_text(self.MODULE_SAVE_SUCCESS)
            success_message = self.element_get_text(self.MODULE_SAVE_SUCCESS_MESSAGE)
            self.wait_loader_to_vanish()
            return success_message
        except Exception:
            return "Falied to read toast msg."


    def cancel_Create_Or_Update_Module(self):
        self.element_click(self.MODULES_CANCEL)
        time.sleep(3)
        self.element_click(self.MODULES_CANCEL_YES)

    def check_Save_Button_Disables(self):
        # return self.is_disabled(self.MODULES_SAVE)
        try:
            self.element_is_clickable(self.MODULES_SAVE)
            return True
        except:
            return False

    def search_Module(self, module_name):
        self.element_set_text(self.MODULES_COMMON_SEARCH, module_name, True)

    def search_Module_And_Perform_Action(self, module_name, action):
        self.element_set_text(self.MODULES_COMMON_SEARCH, module_name, True)
        elem = (By.XPATH, "//td/span[contains(text(),'" + module_name + "')]/ancestor::tr/td[7]/div/div")
        self.element_click(elem)
        if action == "EDIT":
            self.element_click(self.MODULES_ACTION_EDIT)
        elif action == "DELETE":
            self.element_click(self.MODULES_ACTION_DELETE)
        elif action == "TRIGGER BUILD":
            initialstatus = self.element_get_text(self.MODULES_GET_BUILD_STATUS)
            self.element_click(self.MODULES_ACTION_TRIGGER_BUILD)
            time.sleep(4)
            currentstatus = self.element_get_text(self.MODULES_GET_BUILD_STATUS)
            print("Build status after build trigger :  " + currentstatus)
            self.element_click(self.MODULES_GET_BUILD_STATUS_REFRESH)
            # self.action_chain_moveTo_Click(self.MODULES_GET_BUILD_STATUS_REFRESH)
            time.sleep(3)
            currentstatus = self.element_get_text(self.MODULES_GET_BUILD_STATUS)
            print("Build status after refresh :  " + currentstatus)
        elif action == "CLONE":
            self.element_click(self.MODULES_ACTION_CLONE)
        time.sleep(3)

    def get_build_status(self):
        self.element_click(self.MODULES_GET_BUILD_STATUS_REFRESH)
        time.sleep(3)
        currentstatus = self.element_get_text(self.MODULES_GET_BUILD_STATUS)
        return currentstatus

    def confirm_Delete_Verify_Message(self):
        self.element_click(self.MODULES_CANCEL_YES)
        self.wait_loader_to_vanish()
        # time.sleep(5)
        success = self.element_get_text(self.MODULE_SAVE_SUCCESS)
        confirmation_message = self.element_get_text(self.MODULE_SAVE_SUCCESS_MESSAGE)
        return confirmation_message

    def get_GitHub_JenkinsURLs(self, modulename):
        xpath = "//td/span[contains(text(),'" + modulename + "')]/ancestor::tr/td/span/a"
        print(xpath)
        elements = self.driver.find_elements(By.XPATH, xpath)
        urls = []
        for i in elements:
            print(i.get_attribute('href'))
            urls.append(i.get_attribute('href'))
        return urls

    def click_github_jenkinslinks(self, modulename, link):

        MODULE_GITURL_LINK = (By.XPATH,"(//td/span[contains(text(),'" + modulename + "')]/ancestor::tr/td/span/a)[1]")
        MODULE_JENKINS_LINK = (By.XPATH,"(//td/span[contains(text(),'" + modulename + "')]/ancestor::tr/td/span/a)[2]")
        if link == "git":
            self.element_click(MODULE_GITURL_LINK)
        elif link == "jenkins":
            self.element_click(MODULE_JENKINS_LINK)

    def get_Jenkins_Path(self):
        jenkins_url = self.element_get_attribute_value(self.MODULES_TEXT_JENKINS_PATH)
        return jenkins_url

    def check_ModuleNameDisabled(self):
        return self.element_get_attribute_value(self.MODULES_TEXT_NAME, "readonly")


    def enter_Create_Module_Data(self, TestData):
        uniquestr = utils.common.get_Current_TimeStamp()
        self.navigate_to_Modules_Page()
        self.navigate_to_Create_Module()
        print("TestData")
        print(TestData["Name"])
        module_name = TestData["Name"] + uniquestr if (str(TestData["Name"]) != "None") else ""

        # if (TestData["Execution"] != "SKIP"):
        #     self.navigate_to_Modules_Page()
        #     self.navigate_to_Create_Module()
        self.enter_Name(module_name)
        self.enter_Display_Name(
            TestData["Display_Name"] + uniquestr if (str(TestData["Display_Name"]) != "None") else "")
        self.enter_Discription(
            TestData["Description"] + uniquestr if (str(TestData["Description"]) != "None") else "")
        # self.enter_More_Info(More_Info)
        self.enter_Version_Name(TestData["Version_Number"] + uniquestr if (str(TestData["Version_Number"]) != "None") else "")
        self.select_Dependency_Type(TestData["Dependency_Type"])
        self.enter_GIT_Path(TestData["Git_Path"])
        self.select_Custom_Branch(TestData["Custom_Branch"], TestData["Branch_Name"])
        self.enter_More_Info_Link(TestData["More_Info_Link"] if (str(TestData["More_Info_Link"]) != "None") else "")
        self.enter_Release_Tag(
            TestData["Release_Tag"] + uniquestr if (str(TestData["Release_Tag"]) != "None") else "")
        self.enter_Folder_Name(
            TestData["Folder_Name"] + uniquestr if (str(TestData["Folder_Name"]) != "None") else "")
        # self.enter_Jenkins_Job(Jenkins_Path)
        self.select_Default_Installation(TestData["Branch_Name"])
        self.select_Disable_Jenkins(TestData["Disable_Jenkins"])
        # self.select_Unsupported_Countries(Unsupported_Countries)
        assert self.select_Compatible_OS(TestData["Compatible_OS"]) != False, f"Given OS does not exists - " + \
                                                                              TestData["Compatible_OS"]
        assert self.select_Compatible_Hardware(
            TestData["Compatible_Hardware"]) != False, f"Given Harqware does not exists - " + TestData[
            "Compatible_Hardware"]
        assert self.select_Dependent_Modules(
            TestData["Dependent_Modules"]) != False, f"Given Module does not exists - " + TestData[
            "Dependent_Modules"]
        self.select_filter(TestData["Filter"])

        return module_name, uniquestr

    def error_recovery(self):
        self.element_click(self.MODULES_ADDCOMPATIBLE_COMMON_CANCEL)
        self.element_click(self.MODULES_LINK)
        self.element_click(self.MODULES_CANCEL_YES)


    def validate_prefilled_data(self, dataset, moduledata):
        assert self.element_get_attribute_value(self.MODULES_TEXT_DISPLAY_NAME, "value") == dataset["Display_Name"] + moduledata[3]
        assert dataset["Git_Path"] == self.element_get_attribute_value(self.MODULES_TEXT_GIT_PATH, "value")
        assert self.element_get_attribute_value(self.MODULES_TEXT_VERSION_NAME, "value") == dataset["Version_Number"] + moduledata[3]
        # dataset["Description"]+uniquestr if (str(TestData["Description"])!= "nan") else "",True)
        # dataset["Version_Number"]+uniquestr if (str(TestData["Version_Number"])!= "None") else "" ,True)
        # dataset["Dependency_Type"])
        # dataset["Custom_Branch"],TestData["Branch_Name"])
        # dataset["More_Info_Link"] if (str(TestData["More_Info_Link"])!= "nan") else "",True)
        # dataset["Release_Tag"]+uniquestr if (str(TestData["Release_Tag"])!= "nan") else "",True)
        # dataset["Folder_Name"]+uniquestr if (str(TestData["Folder_Name"])!= "nan") else "",True)


    @staticmethod
    def get_Create_Module_Data():
        data_Create_Module = fo.File_Operations().get_csv_data(mc.modules_data_file, "CREATE")
        return data_Create_Module

    @staticmethod
    def get_Update_Module_Data():
        data_Update_Module = fo.File_Operations().get_csv_data(mc.modules_data_file, "UPDATE")
        return data_Update_Module

    @staticmethod
    def get_Parameters():
        parameterlist = mc.modules_columns_list
        return parameterlist

    @staticmethod
    def get_Module_TestData_As_JSON(action):
        data_Update_Module = fo.File_Operations().get_csv_data_as_Dataframe(mc.modules_data_file, action)
        data_Update_Module_JSON = data_Update_Module.to_json(orient="records")
        data_Update_Module_JSON = json.loads(data_Update_Module_JSON)
        print(data_Update_Module_JSON)
        return data_Update_Module_JSON
