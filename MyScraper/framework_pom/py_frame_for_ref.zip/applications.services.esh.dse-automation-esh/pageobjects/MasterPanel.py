from selenium.webdriver.common.by import By
from configs import ManagementConsole as mc
from .BasePage import WebActions
from selenium.webdriver.support.ui import WebDriverWait



class MasterPanel(WebActions):

    def __init__(self, driver):
        super().__init__(driver)


    """ Page Locators """

    MASTER_PANEL = (By.XPATH, "//span[contains(text(),'Master Panel')]")
    PACKAGE_CLASS_LINK = (By.XPATH, "//a[contains(text(),'Package Class')]")
    PACKAGE_CLASS_CREATE_NEW = (By.CLASS_NAME, "createNewButtonClass")
    PACKAGE_CLASS_NAME = (By.NAME, "name")
    PACKAGE_CLASS_LANGUAGE = (By.XPATH,
                              "//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[5]/div[1]/form[1]/div["
                              "1]/div[2]/div[1]/select[1]")
    PACKAGE_CLASS_SAVE = (By.CSS_SELECTOR, "body.modal-open:nth-child(2) div.container-fluid.containerPositionClass:nth-child(2) div.row div.col-sm-10.list-container-expanded div:nth-child(1) div.container-fluid.headingClass:nth-child(4) div:nth-child(1) > button.buttonClass:nth-child(4)")


    def create_package_class(self,name):
        self.element_click(self.MASTER_PANEL)
        # self.element_click(self.PACKAGE_CLASS_LINK)
        self.element_click(self.PACKAGE_CLASS_CREATE_NEW)
        self.element_set_text(self.PACKAGE_CLASS_NAME,name)
        self.driver.implicitly_wait(15)
        self.element_click(self.PACKAGE_CLASS_SAVE)
