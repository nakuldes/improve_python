import pytest
from selenium.webdriver.common.by import By
from .BasePage import WebActions
from selenium.webdriver.support.ui import WebDriverWait
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from utils import FileOperations as fo
from configs import ManagementConsole as mc
import json
import utils.common


class ODActions(WebActions):

    def __init__(self, driver):
        super().__init__(driver)



    """Locators"""
    OD_LINK = (By.XPATH, "//span[contains(text(),'Online Distribution')]")
    OD_BUTTON_CREATE_NEW = (By.XPATH, "//span[contains(text(), 'Create Distribution')]")
    OD_TEXT_NAME = (By.NAME, "ingrdtName")
    OD_TEXT_DISPLAY_NAME = (By.NAME, "displayName")
    OD_TEXT_DESCRIPTION = (By.NAME, "ingrdtDesc")

    OD_TEXT_VERSION_NAME = (By.NAME, "displayVersion")
    OD_INSTALLATION_CMND = (By.NAME, "consumption")
   
    #OD_ADD_FILTER_TAGS = (By.XPATH, "//div[contains(text(),'Add Tags')]")
    OD_ADD_FILTER_TAGS = (By.XPATH, "//div[@role='combobox']")
    # OD_ADD_FILTERS_OPTION = (By.XPATH,"//span[contains(text(),'{0}')]")
    
    OD_CLEAR_FILTER_TAGS=(By.XPATH, "//*[@id='app']/div[3]/div[2]/div/div[2]/div/div[5]/div/div/div/input")

    OD_SAVE = (By.XPATH,"//span[contains(text(),'Save Distribution')]")
    OD_CANCEL = (By.XPATH,"//button[@class='buttonClass cancelbuttonClass']/span[contains(.,'Cancel')]")
    OD_CANCEL_YES = (By.XPATH,"//span[contains(text(),'Yes')]")
    OD_CANCEL_CLOSE = (By.XPATH,"//span[contains(text(),'Close')]")

    OD_COMMON_SEARCH = (By.XPATH, "//input[@placeholder='Search by Name']")
    OD_ACTION_OPTION = (By.CLASS_NAME,"ui dropdown  text-primary ")
    OD_ACTION_EDIT = (By.XPATH,"//span[contains(text(),'Edit')]")
    OD_ACTION_DELETE = (By.XPATH, "//span[contains(text(),'Delete')]")
    OD_ACTION_CLONE = (By.XPATH, "//span[contains(text(),'Clone')]")
    OD_SAVE_SUCCESS = (By.XPATH, "//span[@class='toast_msg']")
    OD_SIDE_POPUP_MSG_TEXT = (By.XPATH,"//span[@class='toast_submsg']")

    # Filter Tag field
    FILTERTAG_NAME = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder='Name in English']")
    FILTERTAG_HELP = (By.XPATH, "//div[@class='filterTagDivRecipe']/div/input[@placeholder=' Add Help Text Here.']")
    SELECT_FILTERTAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/input")
    SELECT_FILTER_TAG_DROPDOWN = (By.XPATH, "//div[@role='combobox']/div[contains(text(), 'Tags')]")
    DELETE_EXISTING_FILTER_TAG = (By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")

    """ Online Distribution Page Actions """
    def navigate_to_OD_Page(self):
        self.element_click(self.OD_LINK)
        time.sleep(10)

    def navigate_to_Create_OD(self):
        self.element_click(self.OD_BUTTON_CREATE_NEW)
        time.sleep(5)

    def enter_OD_name(self,name):
        self.element_set_text(self.OD_TEXT_NAME, name)

    def enter_OD_display_name(self,displayName, required_clear=False):
        self.element_set_text(self.OD_TEXT_DISPLAY_NAME, displayName, required_clear)

    def enter_OD_Description_Name(self, description, required_clear=False):
        self.element_set_text(self.OD_TEXT_DESCRIPTION, description, required_clear)

    def enter_OD_Version(self, version, required_clear=False):
        self.element_set_text(self.OD_TEXT_VERSION_NAME, version, required_clear)

    def enter_OD_Installation_CMND(self, installation_cmnd, required_clear=False):
        self.element_set_text(self.OD_INSTALLATION_CMND, installation_cmnd, required_clear)

    def select_filter(self, tag_name):
        '''
        This method deals with filter tags in MC
        *It first deletes the existing filter tag selected if any are there
        *Then adds given number of filter tags
        '''
        return
        #deleting existing filter tags
        try:
            exisitng_filtertags = self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/a/i")
            for tag in exisitng_filtertags:
                tag.click()
        except Exception as e:
            # No filter tag found
            print('No exisiting filter tag found.')
        # Adding existing 2 filters
        count = 0
        self.element_click(self.SELECT_FILTER_TAG_DROPDOWN)
        if tag_name == 'existing':
            available_filter_tags =  self.driver.find_elements(By.XPATH, "//div[@class='floatRightFilterDropDown']/div/div/div[@role='option']")
            for wb in available_filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                wb.click()
                count+=1
                if count == 2:
                    break         
        else:
            filter_tags = str(tag_name).split('|')
            for item in filter_tags:
                self.action_chain_moveTo_Click(self.SELECT_FILTERTAG)
                time.sleep(1)
                ADD_FILTERS_OPTION = (By.XPATH,"//span[contains(text(),'{0}')]".format(item))
                self.element_click(ADD_FILTERS_OPTION)

    def save_OD(self):
        self.element_click(self.OD_SAVE)
        success_msg = self.element_get_text(self.OD_SIDE_POPUP_MSG_TEXT)
        self.wait_loader_to_vanish()
        return success_msg

    def verify_OD_table_columns(self, headers_list):
        self.wait_loader_to_vanish()
        self.navigate_to_OD_Page()
        for element in headers_list:
            col_xpath = (By.XPATH, '//thead[@data-test="datatable-head"]/tr/th/span[contains(text(), "{0}")]'.format(element))
            if not self.element_visible(col_xpath):
                return False
        return True

    def confirm_Delete_Verify_Message(self):
        self.element_click(self.OD_CANCEL_YES)
        self.wait_loader_to_vanish()
        # time.sleep(5)
        success = self.element_get_text(self.OD_SAVE_SUCCESS)
        confirmation_message = self.element_get_text(self.OD_SIDE_POPUP_MSG_TEXT)
        return confirmation_message

    def check_Save_Button_Disables(self):
        try:
            self.element_is_clickable(self.OD_SAVE)
            return True
        except:
            return False

    def cancel_Create_OD(self):
        self.element_click(self.OD_CANCEL)
        time.sleep(3)
        self.element_click(self.OD_CANCEL_YES)

    def search_OD_And_Perform_Action(self,od_name, action):
        self.element_set_text(self.OD_COMMON_SEARCH, od_name, True)
        #elem = (By.XPATH, "//td/span[contains(text(),'" + od_name + "')]/ancestor::tr/td[7]/div/div")
        elem = (By.XPATH,"//*[@id='dataTableSort']/tbody/tr[1]/td[4]/div/div")
        self.element_click(elem)
        if action == "EDIT":
            self.element_click(self.OD_ACTION_EDIT)
        elif action == "DELETE":
            self.element_click(self.OD_ACTION_DELETE)
        elif action == "CLONE":
            self.element_click(self.OD_ACTION_CLONE)
        time.sleep(3)


    # def search_OD_And_Perform_Action(self,od_name, action):
    #     self.element_set_text(self.OD_COMMON_SEARCH,od_name)
    #     # elem = (By.XPATH,"//td/span[contains(text(),'" + od_name + "')]/ancestor::tr/td[7]/div/div")
    #     elem = (By.XPATH,"//*[@id='dataTableSort']/tbody/tr[1]/td[4]/div/div")
    #     self.element_click(elem)
    #     self.element_click(self.OD_ACTION_EDIT)
    #     time.sleep(5)

    def search_OD(self, OD_name):
        self.element_set_text(self.OD_COMMON_SEARCH, OD_name, True)


    def confirm_Delete_Verify_Message(self):
        self.element_click(self.OD_CANCEL_YES)
        self.wait_loader_to_vanish()
        # time.sleep(5)
        success = self.element_get_text(self.OD_SAVE_SUCCESS)
        confirmation_message = self.element_get_text(self.OD_SIDE_POPUP_MSG_TEXT)
        return confirmation_message

    def check_OD_NameDisabled(self):
        return self.element_get_attribute_value(self.OD_TEXT_NAME,"readonly")
   


    def enter_Update_OD_Data(self,TestData):
        uniquestr = utils.common.get_Current_TimeStamp()
        self.wait_loader_to_vanish()
        self.navigate_to_OD_Page()
        self.search_OD_And_Perform_Action(TestData["Name"],'EDIT')
        self.enter_OD_display_name(TestData["Display_Name"]+uniquestr if (str(TestData["Display_Name"])!= "None") else "",required_clear=True)
        self.enter_OD_Description_Name(TestData["Description"]+uniquestr if (str(TestData["Description"]) != "None") else "",required_clear=True)
        if str(TestData["Version_Number"]) == 'None':
            #self.enter_OD_Version(TestData["Version_Number"] if (str(TestData["Version_Number"]) != "None") else "",required_clear=True)
            self.enter_OD_Version("",required_clear=True)
        self.select_filter(TestData["Filter"] if (str(TestData["Filter"]) != "nan") else "")
        self.enter_OD_Installation_CMND(TestData["Installation_commands"] if (str(TestData["Installation_commands"]) != "None") else "",required_clear=True)
        #self.select_filter(TestData["Filter"])
        time.sleep(3)

    def enter_new_version_OD_Data(self,TestData):
        uniquestr = utils.common.get_Current_TimeStamp()
        self.wait_loader_to_vanish()
        self.navigate_to_OD_Page()
        self.search_OD_And_Perform_Action(TestData["Name"],'EDIT')
        self.enter_OD_display_name(TestData["Display_Name"]+uniquestr if (str(TestData["Display_Name"])!= "None") else "",required_clear=True)
        self.enter_OD_Description_Name(TestData["Description"]+uniquestr if (str(TestData["Description"]) != "None") else "",required_clear=True)
        self.enter_OD_Version(TestData["Version_Number"] ,required_clear=True)
        self.select_filter(TestData["Filter"] if (str(TestData["Filter"]) != "None") else "")
        self.enter_OD_Installation_CMND(TestData["Installation_commands"] if (str(TestData["Installation_commands"]) != "None") else "",required_clear=True)
        #self.select_filter(TestData["Filter"])
        time.sleep(3)

    def enter_Create_OD_Data(self,TestData):
        uniquestr = utils.common.get_Current_TimeStamp()
        
        # OD_name = TestData["Name"] + uniquestr if(str(TestData["Name"]) != "None") else ""
        
        time.sleep(3)
        self.navigate_to_OD_Page()
        time.sleep(3)
        self.navigate_to_Create_OD()
        self.enter_OD_name(TestData["Name"])
        self.enter_OD_display_name(TestData["Display_Name"]+uniquestr if (str(TestData["Display_Name"])!= "None") else "")
        self.enter_OD_Description_Name(TestData["Description"]+uniquestr if (str(TestData["Description"]) != "None") else "")
        self.enter_OD_Version(TestData["Version_Number"]+uniquestr if (str(TestData["Version_Number"]) != "None") else "")
        self.enter_OD_Installation_CMND(TestData["Installation_commands"])
        self.select_filter(TestData["Filter"])
    



    def error_recovery(self):
        try:
            self.toast_msg_close()
        except Exception as e:
            pass
        try:
            self.element_click(self.OD_CANCEL)
        except Exception as e:
            pass
        try:
            self.element_click(self.OD_CANCEL_YES)
        except Exception as e:
            pass

    # Data Fetch Methods

    @staticmethod
    def get_Create_OD_Data():
        data_Create_OD = fo.File_Operations().get_csv_data(mc.od_data_file, "CREATE")
        return data_Create_OD

    @staticmethod
    def get_Update_OD_Data():
        data_Update_OD = fo.File_Operations().get_csv_data(mc.od_data_file, "UPDATE")
        return data_Update_OD

    @staticmethod
    def get_Parameters():
        parameterlist = mc.od_columns_list
        return parameterlist

    @staticmethod
    def get_OD_TestData_As_JSON(action):
        data_Update_OD = fo.File_Operations().get_csv_data_as_Dataframe(mc.od_data_file,action,"latin1")
        data_Update_OD_JSON = data_Update_OD.to_json(orient="records")
        data_Update_OD_JSON = json.loads(data_Update_OD_JSON)
        print(data_Update_OD_JSON)
        return data_Update_OD_JSON