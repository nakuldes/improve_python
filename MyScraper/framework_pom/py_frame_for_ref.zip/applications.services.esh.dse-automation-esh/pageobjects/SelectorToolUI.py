import pandas as pd
from selenium.webdriver.common.by import By
from .BasePage import WebActions
import time
from configs import EdgeSoftwareHubUI_CLI as esh
import json
import os
import shutil
from scp import SCPClient
import paramiko
from xml.dom import minidom
from sys import platform



class SelectorToolUIActions(WebActions):

    def __init__(self, driver):
        super().__init__(driver)

    """ Page Locators """

    SELECTOR_TOOL_PACKAGE_TITLE = (By.XPATH, "//p[@class='header_siteTitle__2ZcNs']")
    SELECTOR_TOOL_PACKAGE_DESCRIPTION = (By.XPATH, "//div[@class='header_siteTitleDescription__-b3_y']")

    SELECTOR_TOOL_UI_VERSION_OR_TAG = "//div/span[contains(text(),'Version') or contains(text(),'Tag')]"
    # Add this XPath to get the complete indentifier for Version/Tag -- /ancestor::div/div/div/div[@title='2.4']
    SELECTOR_TOOL_UI_TARGET_SYSTEM = "//div/span[contains(text(),'Target System')]"
    SELECTOR_TOOL_UI_USECASE = "//div/span[contains(text(),'Select Use Case')]"
    # Add this XPath to get the complete indentifier for Target System -- /ancestor::div/div/div/div[contains(text(),'Ubuntu 18.04 LTS')]

    SELECTOR_TOOL_UI_DOWNLOAD_RECOMMENDED = (By.XPATH, "//div[@id='download']")
    SELECTOR_TOOL_UI_DOWNLOAD_CUSTOM = (By.XPATH, "//div[@id='customDownload']")
    SELECTOR_TOOL_UI_DOWNLOAD_BUTTON_DEFAULT = (By.XPATH, "//button[@id='defaultDownload']")

    SELECTOR_TOOL_UI_LEARN_MORE = (By.XPATH, "//a[contains(text(),'Learn More')]")
    SELECTOR_TOOL_UI_DOCUMENTATION = (By.XPATH, "//a[contains(text(),'Documentation')]")
    SELECTOR_TOOL_UI_AVAILABLE_SELECTION = (By.XPATH, "//img[@id='GridSelection_CollapseIcon__11sPM']")

    SELECTOR_TOOL_UI_SUBSCRIBE_NEWSLETTER = (By.XPATH, "//input[@id='optInForSubscription']")

    SELECTOR_TOOL_UI_LICENSE_DECLINE = (By.XPATH, "//button[contains(text(),'Decline')]")
    SELECTOR_TOOL_UI_LICENSE_ACCEPT = (By.XPATH, "//button[contains(text(),'Accept')]")

    SELECTOR_TOOL_UI_DOWNLOAD_PROGRESS_PERCENTAGE = (
        By.XPATH, "//div[@class='DownloadRecipe_ProgressBarSection4__3fiYC']")
    SELECTOR_TOOL_UI_DOWNLOAD_PRODUCT_KEY = (By.XPATH, "//div[@id='productKey']")

    SELECTOR_TOOL_INSTRUCTIONS_TEXT1 = (
        By.XPATH, "//div[@class='EdgeInsightDownload_packageDetailsHeader__wtrR3']/span")
    SELECTOR_TOOL_INSTRUCTIONS_TEXT2 = (
        By.XPATH, "//div[@class='//div[@class='EdgeInsightDownload_getStartedWithMain__26cuM']']")
    SELECTOR_TOOL_INSTRUCTIONS_TEXT3 = (
        By.XPATH, "//div[@class='EdgeInsightDownload_getStartedWithMain__26cuM']//following-sibling::div")
    SELECTOR_TOOL_INSTRUCTIONS_TEXT4 = (
        By.XPATH, "//div[@class='EdgeInsightDownload_getStartedWrapper__21lg-']/ancestor::div/ul/li[2]")
    SELECTOR_TOOL_INSTRUCTIONS_TEXT5 = (
        By.XPATH, "//div[@class='EdgeInsightDownload_getStartedWrapper__21lg-']/ancestor::div/ul/li[3]")
    SELECTOR_TOOL_INSTRUCTIONS_TEXT6 = (
        By.XPATH, "//div[@class='EdgeInsightDownload_getStartedWrapper__21lg-']/ancestor::div/ul/li[4]")
    SELECTOR_TOOL_GET_STARTED_GUIDE = (By.XPATH, "//h1[@class='EdgeInsightDownload_downloadInstruction__bL1Na']/a")
    SELECTOR_TOOL_SUPPORT_TEXT = (By.XPATH, "//span[@class='EdgeInsightDownload_font20__2rA3J']")
    SELECTOR_TOOL_INTEL_DEVCATALOG_TEXT = (By.XPATH, "//span[@class='EdgeInsightDownload_fontclear__32vrv']")
    SELECTOR_TOOL_INTEL_DEVCATALOG_LINK = (By.XPATH, "//span[@class='EdgeInsightDownload_fontclear__32vrv']/a")
    SELECTOR_TOOL_ONLINE_URL = (By.XPATH, "//div[@id='pullCommand']")

    def verify_page_title_and_desc(self):
        title = self.element_get_text(self.SELECTOR_TOOL_PACKAGE_TITLE)
        print(title)
        desc = self.element_get_text(self.SELECTOR_TOOL_PACKAGE_DESCRIPTION)
        print(desc)

    def select_version_or_tag(self, version):
        # version_identifier_path = self.SELECTOR_TOOL_UI_VERSION_OR_TAG + "/ancestor::div/div/div/div[@title='" + version + "']"
        version_identifier_path = self.SELECTOR_TOOL_UI_VERSION_OR_TAG + "/ancestor::div/div/div/div[text()='" + version + "']"
        version_identifier = (By.XPATH, version_identifier_path)
        self.element_click(version_identifier)

    def select_target_system(self, target_system):
        target_system_identifier_path = self.SELECTOR_TOOL_UI_TARGET_SYSTEM + "/ancestor::div/div/div/div[contains(text(),'" + target_system + "')]"
        target_system_identifier = (By.XPATH, target_system_identifier_path)
        self.element_click(target_system_identifier)

    def select_usecase(self, usecase):
        usecase_identifier_path = "//div[@title='" + usecase + "']"
        # print(usecase_identifier_path)
        usecase_identifier = (By.XPATH, usecase_identifier_path)
        self.element_click(usecase_identifier)
        # self.element_click_if_visible(usecase_identifier)

    def select_download_option(self, downloadtype):
        downloadtype_identifier_path = "//div[@title='" + downloadtype + "']"
        # print(downloadtype_identifier_path)
        usecase_identifier = (By.XPATH, downloadtype_identifier_path)
        self.element_click(usecase_identifier)

    def select_distribtion(self, distribution_type):
        if distribution_type == "RECOMMENDED":
            self.element_click(self.SELECTOR_TOOL_UI_DOWNLOAD_RECOMMENDED)
        elif distribution_type == "CUSTOM":
            self.element_click(self.SELECTOR_TOOL_UI_DOWNLOAD_CUSTOM)

    def check_available_selection(self, itemlist):
        self.element_click(self.SELECTOR_TOOL_UI_AVAILABLE_SELECTION)

    def check_learn_more(self, content):
        self.element_click(self.SELECTOR_TOOL_UI_LEARN_MORE)

    def check_documentation(self, doc):
        self.element_click(self.SELECTOR_TOOL_UI_DOCUMENTATION)

    def download_package(self, download_type, modulelist):
        if download_type == "RECOMMENDED":
            self.element_click(self.SELECTOR_TOOL_UI_DOWNLOAD_BUTTON_DEFAULT)
        elif download_type == "CUSTOM":
            self.element_click(self.SELECTOR_TOOL_UI_DOWNLOAD_BUTTON_DEFAULT)
            self.deselect_modules_for_packages(modulelist)
            self.element_click(self.SELECTOR_TOOL_UI_DOWNLOAD_BUTTON_DEFAULT)

    def deselect_modules_for_packages(self, modulelist):
        # //div/h4[contains(text(),'Reference Implementation - Multi-Camera Detection of Social Distancing')]/..//following-sibling::div/input
        loc_module_list = str(modulelist).split(";")
        NEXT_BUTTON = "//button/span[contains(text(),'Next')]"
        all_next = self.driver.find_elements(By.XPATH, NEXT_BUTTON)

        for next in all_next:
            print(loc_module_list)
            for module in loc_module_list:
                module_element_identifier = "//div/h4[contains(text(),'" + module + "')]"
                module_element = (By.XPATH, module_element_identifier)
                status = self.element_visible(module_element)
                is_disabled = self.element_get_attribute_value(module_element, "disabled")
                # disabled = self.is_disabled(module_element)
                print(str(status) + " -- " + str(is_disabled))
                if status is True and is_disabled != "ELEMENTNOTFOUND":
                    check_element_identifier = "//div/h4[contains(text(),'" + module + "')]/..//following-sibling::div/input"
                    print(check_element_identifier)
                    try:
                        check_element = (By.XPATH, check_element_identifier)
                        self.element_click_if_visible(check_element)
                        loc_module_list.remove(module)
                    except Exception as e:
                        print("Check box is disabled " + str(e))
                elif is_disabled == "ELEMENTNOTFOUND":
                    loc_module_list.remove(module)

                    # self.scroll_to_top_of_page_using_script()
            self.scroll_to_top_of_page_using_script()
            # self.element_click_if_visible(next)
            next.click()

    def verify_licence_aggreement_content(self, content):
        print(content)

    def licence_accpet_or_decline(self, aggrement):
        time.sleep(5)
        if aggrement == "ACCEPT":
            self.element_click(self.SELECTOR_TOOL_UI_LICENSE_ACCEPT)
        elif aggrement == "DECLINE":
            self.element_click(self.SELECTOR_TOOL_UI_LICENSE_DECLINE)
        time.sleep(5)

    def verify_download_completion(self):
        percentage = self.element_get_text(self.SELECTOR_TOOL_UI_DOWNLOAD_PROGRESS_PERCENTAGE)
        percentage = percentage[:-1]
        total_time_wait = 15
        status = True
        while int(percentage) < 100:
            time.sleep(15)
            percentage = self.element_get_text(self.SELECTOR_TOOL_UI_DOWNLOAD_PROGRESS_PERCENTAGE)
            percentage = percentage[:-1]
            # print(percentage)
            status = True
            if total_time_wait > 300:
                print("existing due to timeout")
                status = False
                break
        return status

    def verify_product_key(self, key):
        print("Validating produnct key...")
        if key != "NO_PRODUCT_KEY":
            key_from_application = self.element_get_text(self.SELECTOR_TOOL_UI_DOWNLOAD_PRODUCT_KEY)
            assert key == key_from_application
        else:
            print("Skipping Product Key validation as per the data...")

    def download_package_and_verify_download_status(self, TestData, download_repo_dir):
        print("Initiating package download......")
        self.select_version_or_tag(TestData["Version"])
        self.select_target_system(TestData["Target_System"])
        if (TestData["usecase"]) != "NOTREQUIRED":
            self.select_usecase(TestData["usecase"])
        if (TestData["Download_option"]) != "NOTREQUIRED":
            self.select_download_option(TestData["Download_option"])
        self.select_distribtion(TestData["Download_Type"])
        self.download_package(TestData["Download_Type"], TestData["module_list"])
        if TestData["Licence_Agreement"] == "YES":
            try:
                print("Accepting the package licence..")
                self.scroll_to_bottom_of_page_using_script()
                self.licence_accpet_or_decline(TestData["Licence_Agreement_action"])
            except Exception as e:
                print("License Accept window did not displayed")
        download_status = self.verify_download_completion()

        assert download_status == True
        print("Completed package download....")
        # assert os.path.exists(os.path.join(download_repo_dir, TestData["Download_File_Name"])) == True

    def validate_package_url(self, TestData):
        self.select_version_or_tag(TestData["Version"])
        self.select_target_system(TestData["Target_System"])
        if (TestData["usecase"]) != "NOTREQUIRED":
            self.select_usecase(TestData["usecase"])
        if (TestData["Download_option"]) != "NOTREQUIRED":
            self.select_download_option(TestData["Download_option"])
        url = self.element_get_text(self.SELECTOR_TOOL_ONLINE_URL)
        assert url == TestData["Git_Repo_url"]


    def verify_instructions_and_links(self, prod_key):
        print("Verifying the instrucation link...")
        if prod_key != "NO_PRODUCT_KEY":
            text1 = self.element_get_text(self.SELECTOR_TOOL_INSTRUCTIONS_TEXT1)
            print(text1)
        # text2 = self.element_get_text(self.SELECTOR_TOOL_INSTRUCTIONS_TEXT2)
        # print(text2)
        text3 = self.element_get_text(self.SELECTOR_TOOL_INSTRUCTIONS_TEXT3)
        print(text3)
        text4 = self.element_get_text(self.SELECTOR_TOOL_INSTRUCTIONS_TEXT4)
        print(text4)
        text5 = self.element_get_text(self.SELECTOR_TOOL_INSTRUCTIONS_TEXT5)
        print(text5)
        text6 = self.element_get_text(self.SELECTOR_TOOL_INSTRUCTIONS_TEXT6)
        print(text6)
        link1 = self.element_get_attribute_value(self.SELECTOR_TOOL_GET_STARTED_GUIDE, "href")
        link2 = self.element_get_attribute_value(self.SELECTOR_TOOL_INTEL_DEVCATALOG_LINK, "href")
        print(link1)
        print(link2)

    def verify_filesize(self, filepath, size):
        file_stat = os.stat(filepath)
        varsize = file_stat.st_size
        print(varsize)
        assert varsize > size * .75

    # def copy_package(self, OS):
    #     ssh = paramiko.SSHClient()
    #     ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
    #     ssh.connect(server, username=username, password=password)
    #     sftp = ssh.open_sftp()
    #     sftp.put(localpath, remotepath)
    #     sftp.close()
    #     ssh.close()

    def move_file(self, basepath, targetpath, filedata):
        print("Moving package file to cli_base dir with updated name..")
        filename = str(str(filedata["Download_File_Name"]).split(".")[0] + "_" + filedata["Version"] + "_" +
                       filedata["Target_System"]).replace(".", "_").replace(" ", "_")
        filename = filename + ".zip"
        shutil.copyfile(os.path.join(basepath, filedata["Download_File_Name"]), os.path.join(targetpath, filename))
        print("Successfully moved package file to cli_base dir with updated name..")
        os.remove(os.path.join(basepath, filedata["Download_File_Name"]))
        print("Successfully deleted package file from downlaodedPackages dir..")
        return filename

    def get_package_zip_file(self, targetpath, filedata):
        filename = str(str(filedata["Download_File_Name"]).split(".")[0] + "_" + filedata["Version"] + "_" +
                       filedata["Target_System"]).replace(".", "_").replace(" ", "_")
        filename = filename + ".zip"

        if os.path.isfile(os.path.join(targetpath, filename)):
            path = os.path.join(targetpath, filename)
            path = path.replace("\\", "\\\\")
            return path
        else:
            return False

    def move_zip_file_to_target_machine_and_unzip(self, ssh, srcfile, targetfile, baseDir, filename):

        # Copy
        sftp = ssh.open_sftp()
        #print(srcfile + " -- " + targetfile)
        try:
            obs = sftp.put(srcfile, targetfile)
        except Exception as e:
            print(e)
        print("Copy package file to target machine is successful..")
        # unzip
        stdin, stdout, stderr = ssh.exec_command("pwd")
        print("Current dir..")
        print(stdout.read().decode())
        unzip_cmd = "unzip -o " + filename
        cd_cmd = "cd " + baseDir + ";pwd;" + unzip_cmd
        stdin, stdout, stderr = ssh.exec_command(cd_cmd)
        print("moved to the target dir..")
        print(stdout.read().decode())
        sftp.close()

    def package_install(self, ssh, baseDir, filename, productkey):

        cmd_executable = "cd " + os.path.join(baseDir, filename) + ";pwd;chmod +x " + esh.cli_binaryname
        stdin, stdout, stderr = ssh.exec_command(cmd_executable)
        print(stdout.read().decode())

        cmd_install = "sudo -S -k ./" + esh.cli_binaryname + " " + esh.cli_install
        cmd_final = "cd " + os.path.join(baseDir, filename) + ";pwd;" + cmd_install
        print("running install command .. " + str(cmd_final))
        stdin, stdout, stderr = ssh.exec_command(cmd_final)
        stdin.write(esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"])
        stdin.write('\n')
        stdin.flush()
        stdin.write(productkey)
        stdin.write("\n")
        stdin.flush()

        if stderr.channel.recv_exit_status() != 0:
            print(f"error occured: {stderr.readline()}")
        print(stdout.read().decode())
        # Uninstall the package
        cmd_uninstall = "sudo -S ./" + esh.cli_binaryname + " " + esh.cli_uninstall
        cmd_final_uninstall = "cd " + os.path.join(baseDir, filename) + ";pwd;" + cmd_uninstall
        print("running uninstall command .. " + str(cmd_final_uninstall))
        stdin, stdout, stderr = ssh.exec_command(cmd_final_uninstall)
        stdin.write(esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"])
        stdin.write('\n')
        stdin.flush()
        if stderr.channel.recv_exit_status() != 0:
            print(f"error occured: {stderr.readline()}")
        print(stdout.read().decode())

    def initiate_cli_for_package(self, TestData,base_repo_dir,get_ubuntu_22_connection,
                                 get_ubuntu_20_connection,get_ubuntu_18_connection):
        if TestData["cli_operations"] == "YES":
            package = self.get_package_zip_file(base_repo_dir, TestData)
            if TestData["Target_System"] == "Ubuntu 22.04 LTS":
                connection= get_ubuntu_22_connection
            elif TestData["Target_System"] == "Ubuntu 20.04 LTS":
                connection= get_ubuntu_20_connection
            elif TestData["Target_System"] == "Ubuntu 18.04 LTS":
                connection= get_ubuntu_18_connection
            self.perform_cli_operations(connection, package, TestData)

    def perform_cli_operations(self, ssh, srcfile, filedata):

        if filedata["cli_operations"] == "YES":
            print("Starting with CLI installation...")
            # cmd_root = "cd /tmp/eshpackages;pwd'ls -lsr"
            # stdin, stdout, stderr = ssh.exec_command(cmd_root)
            # stdin.write(esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"])
            # stdin.write('\n')
            # stdin.flush()

            targetfile = "/tmp/eshpackages/" + filedata["Download_File_Name"]
            print("Starting copying zip file to source machine.." + targetfile)
            self.move_zip_file_to_target_machine_and_unzip(ssh, srcfile, targetfile, "/tmp/eshpackages/",
                                                           filedata["Download_File_Name"])
            # self.package_install(ssh, "/tmp/eshpackages/", str(filedata["FileName"]).split(".")[0], filedata["ProductKey"])

            baseDir = "/tmp/eshpackages/"
            filename = str(filedata["Download_File_Name"]).split(".")[0]
            productkey = filedata["Product_Key_QA"]
            cmd_executable = "cd " + os.path.join(baseDir, filename) + ";pwd;chmod +x " + esh.cli_binaryname
            stdin, stdout, stderr = ssh.exec_command(cmd_executable)
            print(stdout.read().decode())

            cmd_install = "sudo -S ./" + esh.cli_binaryname + " " + esh.cli_install
            cmd_final = "cd " + os.path.join(baseDir, filename) + ";pwd;" + cmd_install
            print("running install command .. " + str(cmd_final))
            stdin, stdout, stderr = ssh.exec_command(cmd_final)
            response = stdout.read().decode()
            if str(response).find("password") != -1:
                stdin.write(esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"])
                stdin.write('\n')
                stdin.flush()
            stdin.write(productkey)
            stdin.write("\n")
            stdin.flush()
            print(stdout.read().decode())
            if stderr.channel.recv_exit_status() != 0:
                print(f"error occured: {stderr.readline()}")


            # Uninstall the package
            cmd_uninstall = "sudo -S ./" + esh.cli_binaryname + " " + esh.cli_uninstall
            cmd_final_uninstall = "cd " + os.path.join(baseDir, filename) + ";pwd;" + cmd_uninstall
            print("running uninstall command .. " + str(cmd_final_uninstall))
            stdin, stdout, stderr = ssh.exec_command(cmd_final_uninstall)
            stdin.write(esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"])
            stdin.write('\n')
            stdin.flush()
            if stderr.channel.recv_exit_status() != 0:
                print(f"error occured: {stderr.readline()}")
            print(stdout.read().decode())

            cmd_remove_zip_file = "sudo -S rm -f " + targetfile
            stdin, stdout, stderr = ssh.exec_command(cmd_remove_zip_file)
            # stdin.write(esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"])
            # stdin.write('\n')
            # stdin.flush()
            if stderr.channel.recv_exit_status() != 0:
                print(f"error occured: {stderr.readline()}")

            print(stdout.read().decode())
            cmd_remove_zip_file = "sudo -S rm -rf /tmp/eshpackages/" + filename
            stdin, stdout, stderr = ssh.exec_command(cmd_remove_zip_file)
            # stdin.write(esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"])
            # stdin.write('\n')
            # stdin.flush()
            if stderr.channel.recv_exit_status() != 0:
                print(f"error occured: {stderr.readline()}")
            print(stdout.read().decode())
        # ssh.close()
        else:
            print("CLI Operations are not required for this package..skipping..")

    @staticmethod
    def get_download_packages_testdata_as_json(action, type, required_access, format="zip"):
        try:
            data = pd.read_csv(esh.packagesDataFile, encoding='unicode_escape')
            data = data[data["Download_Type"] == action]
            data = data[data["Type"] == type]
            data = data[data["required_access"] == required_access]
            if format == "online":
                data = data[data["format"] == "online"]
            data_UPackages_JSON = data.to_json(orient="records")
            data_UPackages_JSON = json.loads(data_UPackages_JSON)
            print(data_UPackages_JSON)
        except Exception as e:
            print("Error reading the CSV file .. " + str(e))
            data_UPackages_JSON = False
        return data_UPackages_JSON

    @staticmethod
    def get_packages_cli_testdata_as_json(action, type, required_access, os, format="zip"):
        try:
            data = pd.read_csv(esh.packagesDataFile)
            data = data[data["Download_Type"] == action]
            data = data[data["Type"] == type]
            data = data[data["required_access"] == required_access]
            data = data[data["Target_System"] == os]
            if format == "online":
                data = data[data["format"] == "online"]
            data_UPackages_JSON = data.to_json(orient="records")
            data_UPackages_JSON = json.loads(data_UPackages_JSON)
            print(data_UPackages_JSON)
        except Exception as e:
            print("Error reading the CSV file .. " + str(e))
            data_UPackages_JSON = False

        return data_UPackages_JSON

    @staticmethod
    def get_download_package_specific_testdata_as_json(action, package, required_access):
        try:
            data = pd.read_csv(esh.packagesDataFile, encoding='unicode_escape')
            # data = data[data["Download_Type"] == action]
            data = data[data["Package_Name"] == package]
            data = data[data["required_access"] == required_access]
            # if format == "online":
            #     data = data[data["format"] == "online"]
            data_UPackages_JSON = data.to_json(orient="records")
            data_UPackages_JSON = json.loads(data_UPackages_JSON)
            print(data_UPackages_JSON)
        except Exception as e:
            print("Error reading the CSV file .. " + str(e))
            data_UPackages_JSON = False
        return data_UPackages_JSON

    def validate_package_configuration_xml(self, dirpath, filename, version, localfilepath, extractfilename):
        print("Zip file path .." + str(os.path.join(dirpath, filename)))
        dirname = str(filename).split(".")[0]
        print("Dir path .. " + str(dirname))
        extractdirname = str(extractfilename).split(".")[0]

        if platform == "linux" or platform == "linux2":
            extractpath = "/tmp"
        elif platform == "win32":
            extractpath = r"C:\temp"
        # shutil.unpack_archive(os.path.join(dirpath, filename), os.path.join(dirpath, "extractedpackages"))
        shutil.unpack_archive(os.path.join(dirpath, filename), extractpath)
        print("Actual modules list from downlaoded packages..")

        dom = minidom.parse(
            # os.path.join(dirpath, "extractedpackages", extractdirname, "edgesoftware_configuration.xml"))
            os.path.join(extractpath, extractdirname, "edgesoftware_configuration.xml"))
        elements = dom.getElementsByTagName('default')
        for element in elements:
            print(element.attributes['label'].value)

        elements = dom.getElementsByTagName('project')
        for element in elements:
            print(element.attributes['version'].value + " -- " + element.attributes['label'].value)

        elements = dom.getElementsByTagName('image')
        for element in elements:
            print(element.attributes['tag'].value + " -- " + element.attributes['label'].value)

        print("Expected list of Modules....")
        main, default, project, images = self.get_package_xml_values_check(localfilepath, version)
        print(main)
        print(default)
        print(project)
        print(images)

        shutil.rmtree(os.path.join(extractpath, extractdirname))

    def get_package_xml_values_check(self, filepath, version):
        jsonfile = open(filepath, encoding="utf-8-sig")
        versiondata = json.load(jsonfile)
        print(versiondata)
        data = versiondata[version]

        main = data["main"]
        default = data["default"]
        projects = data["projects"]
        images = data["images"]
        return main, default, projects, images
