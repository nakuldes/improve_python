import os
from py.xml import html
import pytest
import utils.common
from configs import ManagementConsole as mc
import configparser

# @pytest.fixture(scope='session')
# def get_credentials():
#     config = configparser.ConfigParser()
#     config.read("configs/credentials.ini")
#     return config

def pytest_addoption(parser):
    parser.addoption("--env", action="store", default="QA")
    parser.addoption("--testurl", action="store", help="URL to run the tests against")
    parser.addoption("--username", action="store", help="User Name of the Test Url Account")
    parser.addoption("--password", action="store", help="Password of the Test Url Account")
    parser.addoption("--unauthorizedusername", action="store", help="User Name of the Test Url Account")
    parser.addoption("--unauthorizedpassword", action="store", help="Password of the Test Url Account")
    parser.addoption("--dockerhubusername", action="store", help="Username of the Docker Hub Account")
    parser.addoption("--dockerhubpassword", action="store", help="Password of the Docker Hub Account")
    parser.addoption("--amrregistryusername", action="store", help="Username of the Amr Registy Account")
    parser.addoption("--amrregistrypassword", action="store", help="Password of the Test Url Account")
    parser.addoption("--mcusername", action="store", help="Username for Management Console app")
    parser.addoption("--mcpassword", action="store", help="Password for Management Console app")
    parser.addoption("--eshusername", action="store", help="Username for ESH selector tool app")
    parser.addoption("--eshpassword", action="store", help="Password for ESH selector tool app")
    parser.addoption("--msaapigeeauth", action="store", help="Password for ESH selector tool app")

def pytest_cmdline_preparse(config, args):
    global resultdir
    date = utils.common.get_Current_TimeStamp()
    resultdir = "testResults/results_" + date
    os.mkdir(resultdir)
    os.mkdir(resultdir + "/screenshots")
    html_file = "testResults/results_" + date + "/pytest-result.html"
    args.extend(['--html', html_file, '--self-contained-html'])
    #args.extend(['--env','QA'])
    # args.extend(['--html', html_file, '--self-contained-html', '--css=highcontrast.css', '--css=accessible.css'])

""" Update the Environment section of Pytest report before execution"""
def pytest_configure(config):
    config._metadata["MC QA URL"] = mc.MC_QA
    config.addinivalue_line(
        'markers', 'builddocker: mark test to run only build docker tests'
    )
    config.addinivalue_line(
        'markers', 'authorization: mark test to run only authorization test'
    )
    config.addinivalue_line(
        'markers', 'authentication: mark test to run only authentication test'
    )
    config.addinivalue_line(
        'markers', 'buildhelmchart: mark test to run only build helm chart tests'
    )
    config.addinivalue_line(
        'markers', 'validationdocker: mark test to run only build helm chart tests'
    )
    config.addinivalue_line(
        'markers', 'buildpypi: mark test to run only build pypi tests'
    )

""" Update the Environment section of Pytest report after execution"""
# @pytest.hookimpl(tryfirst=True)
# def pytest_sessionfinish(session, exitstatus):
#     session.config._metadata["foo"] = "bar"

""" Update the Summary section of Pytest report"""
def pytest_html_results_summary(prefix, summary, postfix):
    String = "Test URL:" + mc.MC_QA + "\""
    prefix.extend([html.p(String)])


@pytest.mark.optionalhook
def pytest_html_results_table_header(cells):
    cells.append(html.th('JIRA_ID'))
    cells.append(html.th('Test Data'))
    cells.append(html.th('API Json Response'))

@pytest.mark.optionalhook
def pytest_html_results_table_row(report, cells):
    cells.append(html.td(report.JIRA_ID))
    cells.append(html.td(report.Data_Set))
    links = []
    for key in report.API_JSON_RESPONSE:
        if key != 'NA':
            links.append(html.li(html.a(key, href=key)))   
    cells.append(html.td(links))  

@pytest.hookimpl(hookwrapper=True,tryfirst=True)
def pytest_runtest_makereport(item, call):
    global driver,test_type
    pytest_html = item.config.pluginmanager.getplugin("html")
    outcome = yield
    report = outcome.get_result()
    if item.user_properties:
        test_properties = { prop[0]: prop[1] for prop in item.user_properties}
        report.JIRA_ID = test_properties.get("JIRA_ID", 'NA')
        report.TEST_TYPE = test_properties.get("Test_Type", 'NA')
        report.DRIVER = test_properties.get('Driver','NA')
        report.Data_Set = test_properties.get('Data_Set','NA')
        report.API_JSON_RESPONSE = test_properties.get('API_JSON_RESPONSE',['NA'])
        jira_id = report.JIRA_ID
        test_type = report.TEST_TYPE
        driver = report.DRIVER
        print("JIRA ID : " + jira_id + " ===== " + test_type)
        setattr(report, "duration_formatter", "%M:%S")
        # print("Myreport: " + str(report))
    extra = getattr(report, "extra", [])

    if report.when == "call":
        # always add url to report
        extra.append(pytest_html.extras.url(mc.MC_QA))
        xfail = hasattr(report, "wasxfail")
        if ((report.skipped and xfail) or (report.failed and not xfail)) and test_type == "GUI":
            # only add additional html on failure
            name = report.nodeid[35:100]
            file_name =f'{name}_.png'.replace("/","_").replace("::","__").replace("[","_")
            full_path = resultdir + "/screenshots/" + file_name
            driver.save_screenshot(full_path)
            path = "screenshots/" + file_name
            if file_name:
                html = '<div><img src="%s" atl="screenshot" style="width:300px;height:200px" ' \
                       'onclick="window.open.(this.src)" align="right"/></div>'%path
            extra.append(pytest_html.extras.html(html))
        report.extra = extra
    setattr(item, "rep_" + report.when, report)