# import os.path
# import pytest
# from pageobjects import SelectorToolUI
# from libs import commons
#
#
#
# class Test_Edge_Software_Hub:
#
#
#     @pytest.fixture(scope='class', autouse=True)
#     def esh_setup(self,init_browser):
#         """
#         This is fixture for Module class setup and perform login functionality
#         :param init_browser:
#         :param initialize_environment:
#         :param get_credentials:
#         :return: None
#         """
#         app = SelectorToolUI.SelectorToolUIActions(init_browser)
#         return app
#
#     @pytest.fixture(scope='class', autouse=True)
#     def downloaded_package_data(self):
#         package_data = []
#         print(package_data)
#         return package_data
#
#     # @pytest.mark.skip
#     @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_packages_testdata_as_json("Recommended", "RI", "NO"))
#     def test_download_package_recommended(self, TestData, esh_setup,initialize_environment,get_credentials,
#                                           record_property,init_browser, download_repo_dir, downloaded_package_data, base_repo_dir):
#
#         commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
#         if TestData["Execution"] == "RUN":
#             esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
#             esh_setup.verify_page_title_and_desc()
#             esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
#             # downloaded_package_data.append({"Name":TestData["display_name"], "Version":TestData["Version"],
#             #                                 "TargetSystem":TestData["Target_System"],"FileName":TestData["Download_File_Name"], "ProductKey":TestData["Product_Key"] })
#             esh_setup.verify_product_key(TestData["Product_Key"])
#             esh_setup.verify_instructions_and_links(TestData["Product_Key"])
#             esh_setup.verify_filesize(os.path.join(download_repo_dir, TestData["Download_File_Name"]), TestData["Download_size"])
#             print("moved the file to backup..")
#             esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)
#             # esh_setup.logout_from_esh_app()
#             # init_browser.close()
#         else:
#             pytest.skip("Package download is marked to skip for :" + TestData["Package_Name"])
#
#
#
#
#     @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_packages_cli_testdata_as_json("Recommended", "RI", "NO", "Ubuntu 20.04 LTS"))
#     def test_download_package_recommended_perform_cli_ubuntu_22(self, TestData, esh_setup,initialize_environment,get_credentials,
#                                                                 record_property,init_browser, download_repo_dir, downloaded_package_data, base_repo_dir, get_ubuntu_22_connection):
#
#         commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
#         if TestData["cli_operations"] == "YES":
#             package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
#             print("File found at llocation : " + str(package))
#             if package == False:
#                 esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
#                 esh_setup.verify_page_title_and_desc()
#                 esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
#                 # downloaded_package_data.append({"Name":TestData["display_name"], "Version":TestData["Version"],
#                 #                                 "TargetSystem":TestData["Target_System"],"FileName":TestData["Download_File_Name"], "ProductKey":TestData["Product_Key"] })
#                 # esh_setup.verify_product_key(TestData["Product_Key"])
#                 esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)
#
#             esh_setup.perform_cli_operations(get_ubuntu_22_connection, package, TestData)
#         else:
#             pytest.skip("Package download is marked to skip for :" + TestData["Package_Name"])
#
    # @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_packages_cli_testdata_as_json("Recommended", "RI", "NO", "Ubuntu 20.04 LTS"))
    # def test_download_package_recommended_perform_cli_ubuntu_20(self, TestData, esh_setup,initialize_environment,get_credentials,
    #                                                             record_property,init_browser, download_repo_dir, downloaded_package_data, base_repo_dir, get_ubuntu_20_connection):
    #
    #     commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
    #     if TestData["cli_operations"] == "YES":
    #         package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
    #         print("File found at llocation : " + str(package))
    #         if package == False:
    #             esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
    #             esh_setup.verify_page_title_and_desc()
    #             esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
    #             # downloaded_package_data.append({"Name":TestData["display_name"], "Version":TestData["Version"],
    #             #                                 "TargetSystem":TestData["Target_System"],"FileName":TestData["Download_File_Name"], "ProductKey":TestData["Product_Key"] })
    #             # esh_setup.verify_product_key(TestData["Product_Key"])
    #             esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)
    #
    #         esh_setup.perform_cli_operations(get_ubuntu_20_connection, package, TestData)
    #     else:
    #         pytest.skip("Package download is marked to skip for :" + TestData["Package_Name"])
#
#     @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_packages_cli_testdata_as_json("Recommended", "RI", "NO", "Ubuntu 20.04 LTS"))
#     def test_download_package_recommended_perform_cli_ubuntu_18(self, TestData, esh_setup,initialize_environment,get_credentials,
#                                                                 record_property,init_browser, download_repo_dir, downloaded_package_data, base_repo_dir, get_ubuntu_18_connection):
#
#         commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
#         if TestData["cli_operations"] == "YES":
#             package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
#             print("File found at llocation : " + str(package))
#             if package == False:
#                 esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
#                 esh_setup.verify_page_title_and_desc()
#                 esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
#                 # downloaded_package_data.append({"Name":TestData["display_name"], "Version":TestData["Version"],
#                 #                                 "TargetSystem":TestData["Target_System"],"FileName":TestData["Download_File_Name"], "ProductKey":TestData["Product_Key"] })
#                 # esh_setup.verify_product_key(TestData["Product_Key"])
#                 esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)
#
#             esh_setup.perform_cli_operations(get_ubuntu_18_connection, package, TestData)
#         else:
#             pytest.skip("Package download is marked to skip for :" + TestData["Package_Name"])