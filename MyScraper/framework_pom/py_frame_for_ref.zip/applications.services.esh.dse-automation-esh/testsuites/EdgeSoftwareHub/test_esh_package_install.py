import os.path
import pytest
from pageobjects import SelectorToolUI
from libs import commons



class Test_Edge_Software_Hub:


    @pytest.fixture(scope='class', autouse=True)
    def esh_setup(self,init_browser):
        """
        This is fixture for Module class setup and perform login functionality
        :param init_browser:
        :param initialize_environment:
        :param get_credentials:
        :return: None
        """
        app = SelectorToolUI.SelectorToolUIActions(init_browser)
        return app


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json
        ("Recommended", "Automated Checkout", "NO"))
    def test_package_automated_checkout(self, TestData, esh_setup, initialize_environment,
                                        get_credentials, record_property, init_browser,
                                        download_repo_dir, base_repo_dir, get_ubuntu_22_connection,
                                        get_ubuntu_20_connection, get_ubuntu_18_connection):
        """

        :param TestData:
        :param esh_setup:
        :param initialize_environment:
        :param get_credentials:
        :param record_property:
        :param init_browser:
        :param download_repo_dir:
        :param base_repo_dir:
        :param get_ubuntu_22_connection:
        :param get_ubuntu_20_connection:
        :param get_ubuntu_18_connection:
        :return:
        """

        print(TestData["Package_Name"] + " -- " + TestData["Version"] + " -- " + TestData["Target_System"] + " -- " + TestData["usecase"])
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                           get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package download is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json
        ("Recommended", "Automated License Plate Recognition", "NO"))
    def test_package_automated_license_plate_recognition(self, TestData, esh_setup, initialize_environment,
                                                         get_credentials, record_property, init_browser,
                                                         download_repo_dir, base_repo_dir, get_ubuntu_22_connection,
                                                         get_ubuntu_20_connection, get_ubuntu_18_connection):
        """

        :param TestData:
        :param esh_setup:
        :param initialize_environment:
        :param get_credentials:
        :param record_property:
        :param init_browser:
        :param download_repo_dir:
        :param base_repo_dir:
        :param get_ubuntu_22_connection:
        :param get_ubuntu_20_connection:
        :param get_ubuntu_18_connection:
        :return:
        """

        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        print(TestData["Package_Name"] + " -- " + TestData["Version"] + " -- " + TestData["Target_System"] + " -- " + TestData["usecase"])
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package download is marked to skip for :" + TestData["Package_Name"])

    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json
        ("Recommended", "Connect Edge Devices to Azure IoT", "NO"))
    def test_package_conect_edge_Devices_to_azure_iot(self, TestData, esh_setup, initialize_environment,
                                                      get_credentials, record_property, init_browser,
                                                      download_repo_dir, base_repo_dir, get_ubuntu_22_connection,
                                                      get_ubuntu_20_connection, get_ubuntu_18_connection):
        """

        :param TestData:
        :param esh_setup:
        :param initialize_environment:
        :param get_credentials:
        :param record_property:
        :param init_browser:
        :param download_repo_dir:
        :param base_repo_dir:
        :param get_ubuntu_22_connection:
        :param get_ubuntu_20_connection:
        :param get_ubuntu_18_connection:
        :return:
        """

        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        print(TestData["Package_Name"] + " -- " + TestData["Version"] + " -- " + TestData["Target_System"] + " -- " + TestData["usecase"])
        if TestData["cli_operations"] == "YES":

            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package download is marked to skip for :" + TestData["Package_Name"])

    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Converged Edge Insights", "NO"))
    def test_converged_edge_insights(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Edge AI Box for Video Analytics", "NO"))
    def test_edge_ai_box_for_video_analytics(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json
        ("Recommended", "Edge Controls for Industrial", "NO"))
    def test_package_edge_controls_industrial(self, TestData, esh_setup, initialize_environment,
                                              get_credentials, record_property, init_browser,
                                              download_repo_dir, base_repo_dir, get_ubuntu_22_connection,
                                              get_ubuntu_20_connection, get_ubuntu_18_connection):
        """

        :param TestData:
        :param esh_setup:
        :param initialize_environment:
        :param get_credentials:
        :param record_property:
        :param init_browser:
        :param download_repo_dir:
        :param base_repo_dir:
        :param get_ubuntu_22_connection:
        :param get_ubuntu_20_connection:
        :param get_ubuntu_18_connection:
        :return:
        """

        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        print(TestData["Package_Name"] + " -- " + TestData["Version"] + " -- " + TestData["Target_System"] + " -- " + TestData["usecase"])
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json
        ("Recommended", "Edge Insights for Autonomous Mobile Robots", "NO"))
    def test_package_edge_insights_for_autonomous_mobile_robots(self, TestData, esh_setup, initialize_environment,
                                                                get_credentials, record_property, init_browser,
                                                                download_repo_dir, base_repo_dir, get_ubuntu_22_connection,
                                                                get_ubuntu_20_connection, get_ubuntu_18_connection):
        """

        :param TestData:
        :param esh_setup:
        :param initialize_environment:
        :param get_credentials:
        :param record_property:
        :param init_browser:
        :param download_repo_dir:
        :param base_repo_dir:
        :param get_ubuntu_22_connection:
        :param get_ubuntu_20_connection:
        :param get_ubuntu_18_connection:
        :return:
        """

        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        print(TestData["Package_Name"] + " -- " + TestData["Version"] + " -- " + TestData["Target_System"] + " -- " + TestData["usecase"])
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json
        ("Recommended", "Edge Insights for Fleet", "NO"))
    def test_package_edge_insights_for_fleet(self, TestData, esh_setup, initialize_environment,
                                             get_credentials, record_property, init_browser,
                                             download_repo_dir, base_repo_dir, get_ubuntu_22_connection,
                                             get_ubuntu_20_connection, get_ubuntu_18_connection):
        """

        :param TestData:
        :param esh_setup:
        :param initialize_environment:
        :param get_credentials:
        :param record_property:
        :param init_browser:
        :param download_repo_dir:
        :param base_repo_dir:
        :param get_ubuntu_22_connection:
        :param get_ubuntu_20_connection:
        :param get_ubuntu_18_connection:
        :return:
        """

        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        print(TestData["Package_Name"] + " -- " + TestData["Version"] + " -- " + TestData["Target_System"] + " -- " + TestData["usecase"])
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json
        ("Recommended", "Edge Insights for Industrial", "NO"))
    def test_package_edge_insights_for_industrial_recommended(self, TestData, esh_setup, initialize_environment,
                                                              get_credentials, record_property, init_browser,
                                                              download_repo_dir, base_repo_dir, get_ubuntu_22_connection,
                                                              get_ubuntu_20_connection, get_ubuntu_18_connection):
        """

        :param TestData:
        :param esh_setup:
        :param initialize_environment:
        :param get_credentials:
        :param record_property:
        :param init_browser:
        :param download_repo_dir:
        :param base_repo_dir:
        :param get_ubuntu_22_connection:
        :param get_ubuntu_20_connection:
        :param get_ubuntu_18_connection:
        :return:
        """

        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        print(TestData["Package_Name"] + " -- " + TestData["Version"] + " -- " + TestData["Target_System"] + " -- " + TestData["usecase"])
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json
        ("Recommended", "Edge Insights for Vision", "NO"))
    def test_package_edge_insights_for_vision(self, TestData, esh_setup, initialize_environment,
                                             get_credentials, record_property, init_browser,
                                             download_repo_dir, base_repo_dir, get_ubuntu_22_connection,
                                             get_ubuntu_20_connection, get_ubuntu_18_connection):
        """

        :param TestData:
        :param esh_setup:
        :param initialize_environment:
        :param get_credentials:
        :param record_property:
        :param init_browser:
        :param download_repo_dir:
        :param base_repo_dir:
        :param get_ubuntu_22_connection:
        :param get_ubuntu_20_connection:
        :param get_ubuntu_18_connection:
        :return:
        """

        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        print(TestData["Package_Name"] + " -- " + TestData["Version"] + " -- " + TestData["Target_System"] + " -- " + TestData["usecase"])
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Industrial Surface Defect Detection", "NO"))
    def test_industrial_surface_defect_detection(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Intel® Edge Software Device Qualification For Intel® Edge Controls for Industrialesdq_eci", "NO"))
    def test_esdq_eci(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])

    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Intel® Edge Software Device Qualification for Vision", "NO"))
    def test_esdq_vision(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Intel® Smart Edge Open Developer Experience Kit", "NO"))
    def test_Smart_Edge_Open_Developer_Experience_Kits(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])

    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Intelligent Connection Management for Automated Handover", "NO"))
    def test_Intelligent_Connection_Management(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Intelligent Traffic Management", "NO"))
    def test_intelligent_traffic_management(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Multi-Camera Detection of Social Distancing", "NO"))
    def test_multi_camera_detection_of_social_distancing(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])

    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Public Transit Analytics", "NO"))
    def test_public_transit_analytics(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Real Time Sensor Fusion for Loss Detection", "NO"))
    def test_real_time_sensor_fusion_for_loss_prevention(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Rotor Bearing Defect Detector", "NO"))
    def test_rotor_bearing_defect_detector(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])

    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Smart Video and AI workload Reference Implementation", "NO"))
    def test_smart_video_ai_workload(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])

# # Social Distancing for Retail Settings

    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Textile Defect Classifier", "NO"))
    def test_textile_defect_classifier(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])

    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Video Analytics", "NO"))
    def test_video_analytics(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Wireless Network-Ready Intelligent Traffic Management", "NO"))
    def test_wireless_network_ready_intelligent_traffic_management(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


    @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_download_package_specific_testdata_as_json("Recommended", "Social Distancing Detection for Retail Settings", "NO"))
    def test_social_distancing_detection_for_retail_settings(self, TestData, esh_setup,initialize_environment,get_credentials,record_property,init_browser, download_repo_dir, base_repo_dir, get_ubuntu_22_connection,get_ubuntu_20_connection, get_ubuntu_18_connection):
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if TestData["cli_operations"] == "YES":
            package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
            print("File found at llocation : " + str(package))
            if not package:
                esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
                esh_setup.verify_page_title_and_desc()
                esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)

            esh_setup.initiate_cli_for_package(TestData, base_repo_dir, get_ubuntu_22_connection,
                                               get_ubuntu_20_connection, get_ubuntu_18_connection)
        else:
            pytest.skip("Package CLI operation is marked to skip for :" + TestData["Package_Name"])


"""
#     @pytest.mark.parametrize("TestData",SelectorToolUI.SelectorToolUIActions.get_packages_cli_testdata_as_json("Recommended", "RI", "NO", "Ubuntu 20.04 LTS"))
#     def test_download_package_recommended_perform_cli_ubuntu_22(self, TestData, esh_setup,initialize_environment,get_credentials,
#                                                                 record_property,init_browser, download_repo_dir, downloaded_package_data, base_repo_dir, get_ubuntu_22_connection):
#
#         commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
#         if TestData["cli_operations"] == "YES":
#             package = esh_setup.get_package_zip_file(base_repo_dir, TestData)
#             print("File found at llocation : " + str(package))
#             if package == False:
#                 esh_setup.login_to_esh_application(init_browser, initialize_environment + TestData["display_name"],get_credentials)
#                 esh_setup.verify_page_title_and_desc()
#                 esh_setup.download_package_and_verify_download_status(TestData, download_repo_dir)
#                 # downloaded_package_data.append({"Name":TestData["display_name"], "Version":TestData["Version"],
#                 #                                 "TargetSystem":TestData["Target_System"],"FileName":TestData["Download_File_Name"], "ProductKey":TestData["Product_Key"] })
#                 # esh_setup.verify_product_key(TestData["Product_Key"])
#                 esh_setup.move_file(download_repo_dir, base_repo_dir, TestData)
#
#             esh_setup.perform_cli_operations(get_ubuntu_22_connection, package, TestData)
#         else:
#             pytest.skip("Package download is marked to skip for :" + TestData["Package_Name"])
"""
