import pytest
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from configs import ManagementConsole as mc
from configs import EdgeSoftwareHubUI_CLI as esh
import os
import paramiko
from sys import platform
import configparser

global driver

# def download_repo_dir():
#     return str(os.path.dirname(os.path.abspath(__file__))) + "\downloadedPackages"

@pytest.fixture(scope='session')
def get_credentials():
    config = configparser.ConfigParser()
    config.read("configs/credentials.ini")
    return config

@pytest.fixture(scope='class')
def init_browser(pytestconfig):
    global driver, mc_url, esh_url, mc_api_qa, logger

    print("path :: " + str(os.path.dirname(os.path.abspath(__file__))))

    chromeOptions = webdriver.ChromeOptions()
    # chromeOptions.add_argument("download.default_directory=../..testdata/downloadedPackages")
    prefs = {"download.default_directory": os.path.join(os.path.dirname(os.path.abspath(__file__)), "downloadedPackages")}
    chromeOptions.add_experimental_option("prefs", prefs)
    # driver = webdriver.Chrome(executable_path="executables/chromedriver.exe", chrome_options=chromeOptions)
    try:
        if platform == "linux" or platform == "linux2":
            print("OS Details : " + platform)
            # chromeOptions = webdriver.ChromeOptions()
            chromeOptions.headless = True
            chromeOptions.add_argument("--start-maximized")
            chromeOptions.add_argument("--no-sandbox")
            chromeOptions.add_argument('--disable-dev-shm-usage')
            chromeOptions.add_argument('--ignore-ssl-errors=yes')
            chromeOptions.add_argument('--ignore-certificate-errors')
            # chromeOptions.add_argument('--headless')
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--no-sandbox')
            # driver = webdriver.Chrome(executable_path="/usr/bin/chromedriver", options=chromeOptions)
            driver = webdriver.Chrome(ChromeDriverManager().install(), options=chromeOptions)
            driver.set_window_size(1920, 1080, driver.window_handles[0])
            print("Driver launched successfully...")

        elif platform == "win32":
            print("OS Details : " + platform)
            driver = webdriver.Chrome(executable_path="executables/chromedriver_win32/chromedriver.exe",options=chromeOptions)
            print("Driver launched successfully...")
    except Exception as e:
        print("Driver launched failed due to error .. " + str(e))
    # yield driver
    return driver


@pytest.fixture(scope='class')
def initialize_environment(pytestconfig):
    env = pytestconfig.getoption("env")
    if (env == "QA"):
        # driver.get(mc.URL_QA)
        esh_url = esh.ESH_QA
    elif (env == "DEV"):
        esh_url = mc.MC_DEV
    print("Initialized the environment : " + esh_url)
    return esh_url


@pytest.fixture(scope='class')
def download_repo_dir():
    location = os.path.join(os.path.dirname(os.path.abspath(__file__)), "downloadedPackages")
    return location


@pytest.fixture(scope='class')
def base_repo_dir():
    location = os.path.join(os.path.dirname(os.path.abspath(__file__)), "downloadedPackages", "cli_base")
    print(location)
    return location

@pytest.fixture(scope='function')
def get_ubuntu_20_connection():
    print("Creating SSH connection for Ubuntu 20 VM....")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
    ssh.connect(esh.var_credentials["CLI_MACHINES"]["UBUNTU_20"], 22,
                esh.var_credentials["CLI_CREDENTIALS"]["USERNAME"],
                esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"],
                look_for_keys=False, allow_agent=False)
    console = ssh.invoke_shell()
    console.keep_this = ssh
    print("Successfully created SSH connection for Ubuntu 20 VM....")
    return ssh


@pytest.fixture(scope='function')
def get_ubuntu_18_connection():
    print("Creating SSH connection for Ubuntu 18 VM....")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
    ssh.connect(esh.var_credentials["CLI_MACHINES"]["UBUNTU_18"], 22,
                esh.var_credentials["CLI_CREDENTIALS"]["USERNAME"],
                esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"],
                look_for_keys=False, allow_agent=False)
    console = ssh.invoke_shell()
    console.keep_this = ssh
    print("Successfully created SSH connection for Ubuntu 18 VM....")

    return ssh

@pytest.fixture(scope='function')
def get_ubuntu_22_connection():
    print("Creating SSH connection for Ubuntu 22 VM....")
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # ssh.set_missing_host_key_policy(paramiko.MissingHostKeyPolicy())
        ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
        ssh.connect(esh.var_credentials["CLI_MACHINES"]["UBUNTU_22"], 22,
                    esh.var_credentials["CLI_CREDENTIALS"]["USERNAME"],
                    esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"],
                    look_for_keys=False, allow_agent=False)
        console = ssh.invoke_shell()
        console.keep_this = ssh
        print("Successfully created SSH connection for Ubuntu 22 VM....")
    except Exception as e:
        print("SSH Connectioned failed due to error : " + str(e))
        pytest.exit("failed to established the SSH connection")
    return ssh
