import pytest
from configs import ManagementConsole as mc


from pageobjects import Packages

from pageobjects import Containers
from pageobjects import Modules
from pageobjects import HelmCharts

from pageobjects import SelectorToolUI

from libs import commons

class Test_E2E:

    @pytest.fixture(scope='class', autouse=True)
    def e2e_setup(self,init_browser, initialize_environment,initialize_credentials):
        """
        This is fixture for Package class setup and perform login functionality
        :param init_browser:
        :param initialize_environment:
        :param get_credentials:
        :return: None
        """
        app = Packages.PackagesActions(init_browser)
        app.login_to_application(initialize_environment,initialize_credentials)
        return app
    
    @pytest.fixture(scope='class', autouse=True)
    def esh_setup(self,init_browser):
        """
        This is fixture for Module class setup and perform login functionality
        :param init_browser:
        :param initialize_environment:
        :param get_credentials:
        :return: None
        """
        app = SelectorToolUI.SelectorToolUIActions(init_browser)
        return app


    @pytest.fixture(scope='class')
    def packages_list(self):
        """
        This is package for collecting the Package Name, Version & GitHUb URLs after successfull creation
        :return:
        """
        return []
    
    @pytest.mark.parametrize("TestData", Packages.PackagesActions.get_E2E_TestData_As_JSON('create'))
    def test_create_Package(self,TestData,record_property,request,packages_list,init_browser, e2e_setup, esh_setup, download_repo_dir, base_repo_dir, initialize_esh_environment, get_credentials):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if(TestData["Execution"] != "SKIP"):
            try:    
                container_name = module_name = helm_name = None

                if str(TestData["Add_Container"]).upper()=='YES':
                    container_data = Containers.ContainerActions.get_Container_TestData_As_JSON("CREATE")
                    container_setup = Containers.ContainerActions(init_browser)
                    container_name = container_setup.enter_Create_Container_Data(container_data[0])
                    #TODO: add filter for 'Positive' sc
                    container_success_msg = container_setup.save_Container()
                    e2e_setup.wait_loader_to_vanish()

                if str(TestData["Add_Module"]).upper()=='YES':
                    module_data = Modules.ModulesActions.get_Module_TestData_As_JSON("CREATE")
                    module_setup = Modules.ModulesActions(init_browser)
                    module_name, uniquestridentifier = module_setup.enter_Create_Module_Data(module_data[0])
                    module_success_msg = module_setup.save_Module()
                    e2e_setup.wait_loader_to_vanish()

                if str(TestData["Add_Helm_Charts"]).upper()=='YES':
                    helm_data = HelmCharts.HelmChartActions.get_Helm_TestData_As_JSON("CREATE")
                    helm_setup = HelmCharts.HelmChartActions(init_browser)
                    helm_name = helm_setup.enter_Create_Helmchart_Data(helm_data[0])
                    helm_success_msg = helm_setup.save_Helm()
                    e2e_setup.wait_loader_to_vanish()
               
                package_data = Packages.PackagesActions.get_Package_TestData_As_JSON("CREATE")
                package_data[0]['Containers'] = container_name
                package_data[0]['Modules'] = module_name
                package_data[0]['Helm_Charts'] = helm_name
                package_name = e2e_setup.enter_Create_Package_Data(package_data[0])
                pkg_success_mg = e2e_setup.select_Package_Save()
                #assert pkg_success_msg == "Package '" + package_name + " (Version: " + package_data[0]["Version_Number"] + package_name.split("_")[-1] + ")' created successfully."
                e2e_setup.wait_loader_to_vanish()

                e2e_setup.periodic_build_status_checker(package_name, 1000)     

                if str(TestData["Promote"]).upper()=='YES':
                    #TODO : write code for wait
                    package_prmomte_data = Packages.PackagesActions.get_Package_TestData_As_JSON("PROMOTE")                   
                    package_prmomte_data[0]['Name'] = package_name
                    e2e_setup.promote_Package_Data(package_prmomte_data[0])  
                    e2e_setup.promote_Package(package_prmomte_data[0]["Promote_Env"])

                esh_data = SelectorToolUI.SelectorToolUIActions.get_download_packages_testdata_as_json("Recommended", "Package", "NO")
                # if str(TestData["Download"]).upper()=='YES':   
                esh_setup.login_to_esh_application(init_browser, initialize_esh_environment + esh_data[0]["display_name"],get_credentials)

                esh_setup.download_package_and_verify_download_status(esh_data[0], download_repo_dir)
                esh_setup.move_file(download_repo_dir, base_repo_dir, esh_data[0])
                #esh_setup.perform_cli_operations(get_ubuntu_22_connection, package, TestData)

            except Exception as e:
                print(e)
                pytest.fail("Package Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")

    @pytest.mark.parametrize("TestData", Packages.PackagesActions.get_E2E_TestData_As_JSON('delete'))
    def test_delete(self,TestData,record_property,request,packages_list,init_browser, e2e_setup):
        '''
        This functions first creates the container, module and helmchart. Creates package using above components and then tryies to delete the components.
        '''
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if(TestData["Execution"] != "SKIP"):
            try:
                
                container_name = module_name = helm_name = None
                if str(TestData["Add_Container"]).upper()=='YES':
                    container_data = Containers.ContainerActions.get_Container_TestData_As_JSON("CREATE")
                    container_setup = Containers.ContainerActions(init_browser)
                    container_name = container_setup.enter_Create_Container_Data(container_data[0])
                    container_success_msg = container_setup.save_Container()

                if str(TestData["Add_Module"]).upper()=='YES':
                    module_data = Modules.ModulesActions.get_Module_TestData_As_JSON("CREATE")
                    module_setup = Modules.ModulesActions(init_browser)
                    module_name, uniquestridentifier = module_setup.enter_Create_Module_Data(module_data[0])
                    module_success_msg = module_setup.save_Module()

                if str(TestData["Add_Helm_Charts"]).upper()=='YES':
                    helm_data = HelmCharts.HelmChartActions.get_Helm_TestData_As_JSON("CREATE")
                    helm_setup = HelmCharts.HelmChartActions(init_browser)
                    helm_name = helm_setup.enter_Create_Helmchart_Data(helm_data[0])
                    helm_success_msg = helm_setup.save_Helm()

                
                package_data = Packages.PackagesActions.get_Package_TestData_As_JSON("CREATE")
                package_data[0]['Containers'] = container_name
                package_data[0]['Modules'] = module_name
                package_data[0]['Helm_Charts'] = helm_name
                package_name = e2e_setup.enter_Create_Package_Data(package_data[0])
                e2e_setup.select_Package_Save()

                container_setup.delete_Container_Data(container_data)

                module_setup.navigate_to_Modules_Page()
                module_setup.search_Module_And_Perform_Action(module_name,"DELETE")
                message = module_setup.confirm_Delete_Verify_Message()
                module_setup.element_delete_text(module_setup.MODULES_COMMON_SEARCH)

                module_setup.delete_Container_Data(container_data)
                container_setup.delete_Container_Data(container_data)


            except Exception as e:
                print(e)
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")


    @pytest.mark.parametrize("TestData", Packages.PackagesActions.get_E2E_TestData_As_JSON('create'))
    def test_delete(self,TestData,record_property,request,packages_list,init_browser, e2e_setup):
        '''
        This functions is to perform individual promote for package components.
        '''
        pass
