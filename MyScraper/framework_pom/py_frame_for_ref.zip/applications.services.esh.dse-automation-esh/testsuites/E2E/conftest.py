import pytest
from selenium import webdriver
import os
from configs import ManagementConsole as mc
# from selenium.webdriver.chrome.options import Options
from sys import platform
from utils import common
from configs import EdgeSoftwareHubUI_CLI as esh
import configparser


global driver

@pytest.fixture(scope='class')
def init_browser(pytestconfig):
    global driver, mc_url, esh_url,mc_api_qa, logger
    driver = ""


    if platform == "linux" or platform == "linux2":
        print("OS Details : " + platform)
        chromeOptions = webdriver.ChromeOptions()
        chromeOptions.headless = True
        # chromeOptions.add_argument("--no-sandbox")
        driver = webdriver.Chrome(executable_path="executables/chromedriver_linux64/chromedriver", options=chromeOptions)
        # driver = webdriver.Chrome(ChromeDriverManager().install(), options=chromeOptions)
    elif platform == "win32":
        print("OS Details : " + platform)
        driver = webdriver.Chrome(executable_path="executables/chromedriver_win32/chromedriver.exe")
        # driver = webdriver.Chrome(ChromeDriverManager().install())
    print("Driver setup is successful.....")
    yield driver


@pytest.fixture(scope='class')
def initialize_environment(pytestconfig):
    env = pytestconfig.getoption("env")
    if(env == "QA"):
        # driver.get(mc.URL_QA)
        mc_url = mc.MC_QA
    elif (env == "DEV"):
        mc_url = mc.MC_DEV
    print("Environment details -- " + str(mc_url))
    return mc_url

@pytest.fixture(scope='class')
def initialize_esh_environment(pytestconfig):
    env = pytestconfig.getoption("env")
    if (env == "QA"):
        # driver.get(mc.URL_QA)
        esh_url = esh.ESH_QA
    elif (env == "DEV"):
        esh_url = mc.MC_DEV
    print("Initialized the environment : " + esh_url)
    return esh_url

@pytest.fixture(scope='session')
def get_credentials():
    config = configparser.ConfigParser()
    config.read("configs/credentials.ini")
    return config

@pytest.fixture(scope='class')
def initialize_credentials(pytestconfig):

    loc_credentials = common.get_credentials()
    env_dict={}
    if pytestconfig.getoption("mcusername"):
        env_dict['USERNAME'] = pytestconfig.getoption("mcusername")
    else:
        env_dict['USERNAME'] = loc_credentials["MANAGEMENT_CONSOLE"]["USERNAME"]

    if pytestconfig.getoption("mcpassword"):
        env_dict['PASSWORD'] = pytestconfig.getoption("mcusername")
    else:
        env_dict['PASSWORD'] = loc_credentials["MANAGEMENT_CONSOLE"]["PASSWORD"]

    return env_dict

@pytest.fixture(scope='class')
def download_repo_dir():
    location = str(os.path.dirname(os.path.abspath(__file__))) + "/downloadedPackages"
    return location


@pytest.fixture(scope='class')
def base_repo_dir():
    location = os.path.join(os.path.dirname(os.path.abspath(__file__)), "downloadedPackages/cli_base")
    print(location)
    return location

@pytest.fixture(scope='session')
def get_ubuntu_20_connection():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
    ssh.connect(esh.var_credentials["CLI_MACHINES"]["UBUNTU_20"], 22,
                esh.var_credentials["CLI_CREDENTIALS"]["USERNAME"],
                esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"],
                timeout=720000000)
    console = ssh.invoke_shell()
    console.keep_this = ssh
    return ssh


@pytest.fixture(scope='session')
def get_ubuntu_18_connection():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
    ssh.connect(esh.var_credentials["CLI_MACHINES"]["UBUNTU_18"], 22,
                esh.var_credentials["CLI_CREDENTIALS"]["USERNAME"],
                esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"])
    console = ssh.invoke_shell()
    console.keep_this = ssh
    return ssh

@pytest.fixture(scope='session')
def get_ubuntu_22_connection():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
    ssh.connect(esh.var_credentials["CLI_MACHINES"]["UBUNTU_22"], 22,
                esh.var_credentials["CLI_CREDENTIALS"]["USERNAME"],
                esh.var_credentials["CLI_CREDENTIALS"]["PASSWORD"],
                timeout=72000000)
    console = ssh.invoke_shell()
    console.keep_this = ssh
    return ssh