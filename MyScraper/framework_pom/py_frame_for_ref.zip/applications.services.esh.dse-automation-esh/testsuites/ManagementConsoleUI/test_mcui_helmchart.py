import pytest
import utils.common
from libs import commons
from pageobjects import HelmCharts


class Test_Helms:


    @pytest.fixture(scope='class', autouse=True)
    def helm_setup(self,init_browser, initialize_environment,initialize_credentials):       
        app = HelmCharts.HelmChartActions(init_browser)
        app.login_to_application(initialize_environment,initialize_credentials)
        return app

    @pytest.fixture(scope='class')
    def helmchart_list(self):
        return []

    """create"""    
    @pytest.mark.parametrize("TestData",HelmCharts.HelmChartActions.get_Helm_TestData_As_JSON("CREATE"))
    def test_create_helmchart(self,TestData,record_property, helmchart_list,init_browser,helm_setup):        
        uniquestr = utils.common.get_Current_TimeStamp()
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        print(TestData["Name"])
        if (TestData['Execution'] != "SKIP" ):
            helmchart_name = TestData['Name'] + uniquestr if(str(TestData['Name']) != "nan") else ""
            try:
                helm_setup.enter_Create_Helmchart_Data(TestData)                
                if(str(TestData['Scenario_Type']).upper() == "POSITIVE"):
                    helmchart_list.append(helmchart_name)
                    helm_setup.save_Helm()
                elif (str(TestData['Scenario_Type']).upper() == "NEGATIVE"):
                    print (helm_setup.check_Save_Button_Disables())
                    assert helm_setup.check_Save_Button_Disables() == True
            except Exception as e:
                helm_setup.error_recovery()
                pytest.fail("Helmchart Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        print(helmchart_list)

    @pytest.mark.parametrize("TestData",HelmCharts.HelmChartActions.get_Helm_TestData_As_JSON("CLONE"))
    def test_clone_helmchart(self,TestData,record_property, helmchart_list,init_browser,helm_setup):       
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData['Execution'] != "SKIP" ):
            helm_name = helmchart_list.pop()
            TestData['Name'] = helm_name
            print(helm_name)
            try:
                helm_setup.navigate_to_HelmCharts_Page()
                helm_setup.search_Helm_And_Perform_Action(helm_name, "CLONE")
                helm_setup.enter_Clone_Helmchart_Data(TestData)               
                if(str(TestData['Scenario_Type']).upper() == "POSITIVE"):
                    success_msg:str = helm_setup.save_Helm()
                    assert True == success_msg.__contains__('success')
                elif (str(TestData['Scenario_Type']).upper() == "NEGATIVE"):
                    print (helm_setup.check_Save_Button_Disables())
                    assert helm_setup.check_Save_Button_Disables() == True
            except Exception as e:
                helm_setup.error_recovery()
                pytest.fail("Helmchart Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        print(helmchart_list)

    def test_helm_section_columns(self,record_property,helmchart_list,init_browser,helm_setup):
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-5850, EETK-5843, EETK-5889", "Short_Desc":"Validate if promotion status is showing correctly for Helm Charts in promote table"},"GUI", init_browser)
        try:
            list_of_column_headers = ['Name', 'Version', 'Display Name', 'Status', 'Promote', 'Git', 'Jenkins', 'Actions']
            headers_found = helm_setup.verify_helm_table_columns(list_of_column_headers)
            assert headers_found == True
        except Exception as e:
            pytest.fail("HelmCharts Section Table Verification failed due to an error : " + str(e))


    @pytest.mark.parametrize("TestData",HelmCharts.HelmChartActions.get_Helm_TestData_As_JSON("PROMOTE"))
    def test_promote_helmchart(self,TestData,record_property, helmchart_list,init_browser,helm_setup):       
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData['Execution'] != "SKIP" ):
            helm_name = helmchart_list.pop()
            TestData['Name'] = helm_name
            print(helm_name)
            try:
                helm_setup.promote_Helm_Data(TestData)               
                if(str(TestData['Scenario_Type']).upper() == "POSITIVE"):
                    success_msg:str = helm_setup.promote_Helm(TestData["Promote_Env"])
                    assert True == success_msg.__contains__('success')
                elif (str(TestData['Scenario_Type']).upper() == "NEGATIVE"):
                    print (helm_setup.check_Save_Button_Disables())
                    assert helm_setup.check_Save_Button_Disables() == True
            except Exception as e:
                helm_setup.error_recovery()
                pytest.fail("Helmchart Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        print(helmchart_list)
        
    @pytest.mark.parametrize("TestData",HelmCharts.HelmChartActions.get_Helm_TestData_As_JSON("UPDATE"))
    def test_update_helmchart(self,TestData,record_property, helmchart_list,init_browser,helm_setup): 
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData['Execution'] != "SKIP" ):
            uniquestr = utils.common.get_Current_TimeStamp()
            TestData['Name'] = helmchart_list.pop()
            helmchart_name = TestData['Name']
            print(TestData["Name"])
            try:
                helm_setup.enter_Update_Helmchart_Data(TestData)
            except Exception as e:
                helm_setup.error_recovery()
                pytest.fail("Helmchart Update failed due to error : " + str(e))
            if(str(TestData['Scenario_Type']).upper() == "POSITIVE"):
                helmchart_list.append(helmchart_name)
                helm_setup.save_Helm()
            elif (str(TestData['Scenario_Type']).upper() == "NEGATIVE"):
                print (helm_setup.check_Save_Button_Disables())
                assert helm_setup.check_Save_Button_Disables() == True
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        print(helmchart_list)
        

    """Delete"""
    @pytest.mark.parametrize("TestData",HelmCharts.HelmChartActions.get_Helm_TestData_As_JSON("DELETE"))
    def test_delete_helmchart(self,TestData,record_property, helmchart_list,init_browser,helm_setup):        
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData["Execution"] != "SKIP" ):
            uniquestr = utils.common.get_Current_TimeStamp()
            TestData['Name'] = helmchart_list.pop()
            helmchart_name = TestData['Name']
            helm_setup.delete_Helmchart(helmchart_name)
            if(str(TestData['Scenario_Type']).upper() == "POSITIVE"):
                success_msg = helm_setup.select_Delete_Yes()
                assert True == success_msg.__contains__('success')
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        

        
        
    
    