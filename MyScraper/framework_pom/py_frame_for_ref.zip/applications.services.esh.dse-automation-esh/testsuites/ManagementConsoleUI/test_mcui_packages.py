import time
import pytest
from pageobjects import Packages
from libs import commons
from utils import common


class Test_Packages:

    @pytest.fixture(scope='class', autouse=True)
    def package_setup(self,init_browser, initialize_environment,initialize_credentials):
        """
        This is fixture for Package class setup and perform login functionality
        :param init_browser:
        :param initialize_environment:
        :param get_credentials:
        :return: None
        """
        app = Packages.PackagesActions(init_browser)
        app.login_to_application(initialize_environment,initialize_credentials)
        return app


    @pytest.fixture(scope='class')
    def packages_list(self):
        """
        This is package for collecting the Package Name, Version & GitHUb URLs after successfull creation
        :return:
        """
        return []


    @pytest.mark.parametrize("TestData",Packages.PackagesActions.get_Package_TestData_As_JSON("CREATE"))
    def test_create_packages(self,TestData,record_property,packages_list,init_browser,package_setup):
        """
        This test is for Validating the Create Package functionality based on the test data provided in data file
        :param TestData: Data used for Creating the Packages with different combinations or positive and negtive data sets
        :param record_property: Record property is in built pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param packages_list: package_list is fixture call to store the created packages Name, Vrrsion & GitHUb URL
                             for following test usages
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return: None
        """
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if(TestData["Execution"] != "SKIP"):
            try:
                package_name = package_setup.enter_Create_Package_Data(TestData)

                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    packages_list.append([package_name,TestData["Version_Number"],TestData["Git_Path"]])
                    success_msg = package_setup.select_Package_Save()
                    assert success_msg == "Package '" + package_name + " (Version: " + TestData["Version_Number"] + package_name.split("_")[-1] + ")' created successfully."
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert package_setup.check_Save_Button_Disables() == True
                    package_setup.cancel_Save_Package()
                    
            except Exception as e:
                package_setup.error_recovery()
                pytest.fail("Package Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")


    def test_verify_JenkinsPathCreated(self,packages_list,record_property,init_browser,package_setup):
        """
        This test method to validate the Jenkins URLs after successfull creation of Package
        :param packages_list: package_list is fixture call to store the created packages Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-0004", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        try:
            init_browser.refresh()
            packagename = packages_list[0]
            package_setup.navigate_to_Package_Page()
            package_setup.search_Package_And_Perform_Action(packagename,"EDIT")
            jenkins_url = package_setup.get_Jenkins_Path()

            jenkins_url_ui = "https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Packages/job/" + packagename
            assert jenkins_url == jenkins_url_ui
        except Exception as e:
            package_setup.error_recovery()
            pytest.fail("Package Jenkins Path Verification failed due to error : " + str(e))


    def test_GitHub_URL(self,packages_list,record_property,init_browser,package_setup):
        """
        This test method to validate the GitHUb URL link on the package list page
        :param packages_list: package_list is fixture call to store the created packages Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        try:
            packagename = packages_list[0]
            package_setup.navigate_to_Package_Page()
            package_setup.search_Package(packagename)
            urls = package_setup.get_GitHub_JenkinsURLs(packagename)

            assert urls[0]==packagename[2] + "/tree/" + packagename[1] + packagename[0].split("_")[-1]
        except Exception as e:
            package_setup.error_recovery()
            pytest.fail("Package GitHub URL Verification failed due to error : " + str(e))


    def test_Jenkins_URL(self,packages_list,record_property,init_browser,package_setup):
        """
        This test method to validate the Jenkins URL link on the package list page
        :param packages_list: package_list is fixture call to store the created packages Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        try:
            packagename = packages_list[0]
            package_setup.navigate_to_Package_Page()
            package_setup.search_Package(packagename)
            urls = package_setup.get_GitHub_JenkinsURLs(packagename)
            assert urls[1]=='https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Packages/job/' + packagename[0]
        except Exception as e:
            pytest.fail("Package Jenkins URL Verification failed due to error : " + str(e))


    @pytest.mark.parametrize("TestData",Packages.PackagesActions.get_Package_TestData_As_JSON("CLONE"))
    def test_clone_Package(self, TestData, packages_list,record_property,init_browser,package_setup):
        """
        This test method to validate the clone package should be allowed if the package is not linked with another package
        :param packages_list: package_list is fixture call to store the created packages Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property, {"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        if (TestData["Execution"] != "SKIP" ):
            try:
                package_setup.navigate_to_Package_Page()
                packagename= package_setup.get_pkg_name(TestData['Name'], packages_list)
                package_setup.search_Package_And_Perform_Action(packagename,"CLONE")
                package_setup.enter_Clone_Package_Data(TestData)

                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    packages_list.append([packagename,TestData["Version_Number"],TestData["Git_Path"]])
                    success_msg = package_setup.select_Package_Save()
                    assert success_msg == "Package '" + packagename + " (Version: " + TestData["Version_Number"] + packagename.split("_")[-1] + ")' created successfully."
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert package_setup.check_Save_Button_Disables() == True
                    package_setup.cancel_Save_Package()
            except Exception as e:
                package_setup.error_recovery()
                pytest.fail("Package Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        return packagename


    def test_trigger_build_for_new_package(self,record_property,packages_list,init_browser,package_setup):
        """
        This test method to validate the Trigger Build functionality for package from list page
        :param packages_list: package_list is fixture call to store the created packages Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        try:
            packagename = packages_list[0]
            package_setup.navigate_to_Package_Page()
            package_setup.search_Package_And_Perform_Action(packagename,"TRIGGER BUILD")
            finalStatus = package_setup.get_build_status()
            assert finalStatus == "Success"
        except Exception as e:
            pytest.fail("Package Trigger new build failed due to error : " + str(e))


    @pytest.mark.parametrize("TestData",Packages.PackagesActions.get_Package_TestData_As_JSON("TRIGGER BUILD"))
    def test_trigger_build_for_existing_package(self,TestData,record_property,packages_list,init_browser,package_setup):
        
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData["Execution"] != "SKIP" ):
            try:
                package_data = TestData["Name"].split(":")
                package_name = package_data[0]
                package_status = package_data[1]
                package_setup.navigate_to_Package_Page()
                package_setup.search_Package_And_Perform_Action(package_name,"TRIGGER BUILD")
                status = package_setup.get_build_status()
                assert status == package_status
            except Exception as e:
                pytest.fail("Trigger Build Failed for Package")
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")


    @pytest.mark.parametrize("TestData",Packages.PackagesActions.get_Package_TestData_As_JSON("UPDATE"))
    def test_update_packages(self,TestData,record_property,packages_list,init_browser,package_setup):
        """
        This test method to validate that user is allowed to update the Package with valid data set
        :param TestData:
        :param packages_list: package_list is fixture call to store the created packages Name, Version & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if(TestData["Execution"] != "SKIP"):
            try:
                TestData['Name'] = package_setup.get_pkg_name(TestData['Name'], packages_list)
                package_setup.enter_Update_Package_Data(TestData)

                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    packages_list.append([TestData['Name'],TestData["Version_Number"],TestData["Git_Path"]])
                    success_msg = package_setup.select_Package_Save()
                    assert success_msg == "Package '" + TestData['Name'] + " (Version: " + TestData["Version_Number"] + TestData['Name'] .split("_")[-1] + ")' updated successfully."                    
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert package_setup.check_Save_Button_Disables() == True
                    package_setup.cancel_Save_Package()
                    
            except Exception as e:
                package_setup.error_recovery()
                pytest.fail("Package Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")


    @pytest.mark.parametrize("TestData",Packages.PackagesActions.get_Package_TestData_As_JSON("PROMOTE"))
    def test_promote_packages(self,TestData,record_property,packages_list,init_browser,package_setup):
        """
        This test method to validate that user is allowed to promopte the Package with valid data set
        :param TestData:
        :param packages_list: package_list is fixture call to store the created packages Name, Version & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if(TestData["Execution"] != "SKIP"):
            try:
                package_name = package_setup.enter_Create_Package_Data(TestData)
                success_msg = package_setup.select_Package_Save()
                assert success_msg == "Package '" + package_name + " (Version: " + TestData["Version_Number"] + package_name.split("_")[-1] + ")' created successfully."
                package_name = package_setup.promote_Package_Data(TestData)
                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    packages_list.append([package_name,TestData["Version_Number"],TestData["Git_Path"]])
                    success_msg = package_setup.promote_Package(TestData["Promote_Env"])
                    assert success_msg == str("Promote to '"+str(TestData['Promote_Env']).lower()+"' environment started successfully")
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    # TODO: Can be added more validations in case required
                    package_setup.press_esc_key()
            except Exception as e:
                package_setup.error_recovery()
                pytest.fail("Package Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")


    @pytest.mark.parametrize("TestData",Packages.PackagesActions.get_Package_TestData_As_JSON("SEARCH"))
    def test_search_packages(self,TestData,record_property,packages_list,init_browser,package_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if(TestData["Execution"] != "SKIP"):
            try:
                package_name_uuid = TestData['Name']
                package_setup.enable_uuid_column()
                package_found = package_setup.search_Package(package_name_uuid)
                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    assert package_found == True
                else:
                    assert package_found == False
            except Exception as e:
                package_setup.error_recovery()
                pytest.fail("Package Search failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")


    def test_package_section_table(self,record_property,packages_list,init_browser,package_setup):
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-8418", "Short_Desc":"Validate that on opening package section in MC UI ,list of all packages is visible"},"GUI", init_browser)
        try:
            table_found = package_setup.data_table_visiblity()
            assert table_found == True
        except Exception as e:
            pytest.fail("Package Section Table Verification failed due to an error : " + str(e))
            
    def test_package_section_columns(self,record_property,packages_list,init_browser,package_setup):
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-8422", "Short_Desc":"Validate the on package section all columns (like jenkins, git, promote ,status, created by, created on, description, displayname, UUID) are fetched correctly"},"GUI", init_browser)
        try:
            list_of_column_headers = ['Name', 'Version', 'Display Name', 'Status', 'Promote', 'Git', 'Jenkins', 'Actions']
            headers_found = package_setup.verify_packages_table_columns(list_of_column_headers)
            assert headers_found == True
        except Exception as e:
            pytest.fail("Package Section Table Verification failed due to an error : " + str(e))


    def test_delete_Linked_Package(self,packages_list,record_property,init_browser,package_setup):
        """
        This test method to validate the delete package should not be allowed if the package is linked with another package
        :param packages_list: package_list is fixture call to store the created packages Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-0005", "Short_Desc":"test_delete_Linked_Package"},"GUI", init_browser)
        try:
            #TODO: Needs proper linking logic
            packagename = packages_list[0]
            packagelink = packages_list[1]
            package_setup.navigate_to_Package_Page()
            package_setup.search_Package_And_Perform_Action(packagename,"DELETE")
            message = package_setup.confirm_Delete_Verify_Message()
            #package_setup.element_delete_text(package_setup.MODULES_COMMON_SEARCH)
            assert message == "Package '" + packagename[0] + " (Version: " + packagename[1] + packagename[0].split("_")[-1] + ")' is being used by '" + packagelink[0] + " (Version:" + packagelink[1] + packagelink[0].split("_")[-1] +")' package!"
        except Exception as e:
            pytest.fail("Delete linked Package failed due to error : " + str(e))       


    @pytest.mark.parametrize("TestData",Packages.PackagesActions.get_Package_TestData_As_JSON("DELETE"))
    def test_delete_Package(self, TestData, packages_list,record_property,init_browser,package_setup):
        """
        This test method to validate the delete package should be allowed if the package is not linked with another package
        :param packages_list: package_list is fixture call to store the created packages Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param package_setup: this is fixture call for creating the Package POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        #packagename = "auto_cloned"
        if (TestData["Execution"] != "SKIP" ):
            try:
                package_name = packages_list.pop()
                package_setup.navigate_to_Package_Page()
                package_setup.search_Package_And_Perform_Action(package_name,"DELETE")
                #package_setup.element_delete_text(package_setup.PACKAGES_COMMON_SEARCH)
                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    packages_list.append([package_name,TestData["Version_Number"],TestData["Git_Path"]])
                    success_msg = package_setup.select_Delete_Yes()
                    assert success_msg == "Container '" + package_name + " (Version: " + TestData["Version_Number"] + package_name.split("_")[-1] + ")' deleted successfully."
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert package_setup.check_Save_Button_Disables() == True
                    package_setup.select_Delete_Cancel()
            except Exception as e:
                package_setup.error_recovery()
                pytest.fail("Package Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")

