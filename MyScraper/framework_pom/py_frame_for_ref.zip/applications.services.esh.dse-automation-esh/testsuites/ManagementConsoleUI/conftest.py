import pytest
from selenium import webdriver
from configs import ManagementConsole as mc
from selenium.webdriver.chrome.options import Options
from sys import platform
from utils import common

import configparser

global driver

@pytest.fixture(scope='class')
def init_browser(pytestconfig):
    global driver, mc_url, esh_url,mc_api_qa, logger
    # driver = ""

    try:
        if platform == "linux" or platform == "linux2":
            print("OS Details : " + platform)
            chromeOptions = webdriver.ChromeOptions()
            chromeOptions.add_argument("--start-maximized")
            chromeOptions.add_argument("--no-sandbox")
            chromeOptions.add_argument('--disable-dev-shm-usage')
            chromeOptions.add_argument('--ignore-ssl-errors=yes')
            chromeOptions.add_argument('--ignore-certificate-errors')
            # chromeOptions.add_argument("--proxy-server=http://ProxyHost:8080")
            chromeOptions.headless = True
            # chrome_options = Options()
            # chrome_options.add_argument("--headless")
            # chrome_options.add_argument('--no-sandbox')
            driver = webdriver.Chrome(executable_path="/usr/bin/chromedriver", options=chromeOptions)
            # driver = webdriver.Chrome(ChromeDriverManager().install(), options=chromeOptions)
            driver.set_window_size(1920, 1080, driver.window_handles[0])
            print("Launched driver successfully..")
        elif platform == "win32":
            print("OS Details : " + platform)
            driver = webdriver.Chrome(executable_path="executables/chromedriver_win32/chromedriver.exe")
            # driver = webdriver.Chrome(ChromeDriverManager().install())
            print("Driver setup is successful.....")
    except Exception as e:
        print("Driver Setup failed.." + str(e))
        driver = False
    return driver


@pytest.fixture(scope='class')
def initialize_environment(pytestconfig):
    env = pytestconfig.getoption("env")
    if(env == "QA"):
        # driver.get(mc.URL_QA)
        mc_url = mc.MC_QA
    elif (env == "DEV"):
        mc_url = mc.MC_DEV
    print("Environment details -- " + str(mc_url))
    return mc_url


@pytest.fixture(scope='class')
def initialize_credentials(pytestconfig):

    loc_credentials = common.get_credentials()
    env_dict={}
    if pytestconfig.getoption("mcusername"):
        env_dict['USERNAME'] = pytestconfig.getoption("mcusername")
    else:
        env_dict['USERNAME'] = loc_credentials["MANAGEMENT_CONSOLE"]["USERNAME"]

    if pytestconfig.getoption("mcpassword"):
        env_dict['PASSWORD'] = pytestconfig.getoption("mcusername")
    else:
        env_dict['PASSWORD'] = loc_credentials["MANAGEMENT_CONSOLE"]["PASSWORD"]
    print("Fetched the credentials successfully...")
    return env_dict

# @pytest.fixture(scope='session')
# def get_credentials():
#     config = configparser.ConfigParser()
#     config.read("configs/credentials.ini")
#     return config
