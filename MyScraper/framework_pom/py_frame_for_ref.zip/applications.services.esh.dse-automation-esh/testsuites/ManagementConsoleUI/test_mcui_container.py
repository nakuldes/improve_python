import pytest
from pageobjects import Containers
from libs import commons
from utils import common



class Test_Containers:

    @pytest.fixture(scope='class', autouse=True)
    def container_setup(self,init_browser, initialize_environment, initialize_credentials):
        app = Containers.ContainerActions(init_browser)
        app.login_to_application(initialize_environment, initialize_credentials)
        return app


    @pytest.fixture(scope='class')
    def containers_list(self):
        return []

    """ Create Container Test Case"""
    @pytest.mark.parametrize("TestData", Containers.ContainerActions.get_Container_TestData_As_JSON("CREATE"))
    def test_create_containers(self,TestData,record_property,request,containers_list,init_browser, container_setup):

        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData["Execution"] != "SKIP" ):
            try:
                container_name = container_setup.enter_Create_Container_Data(TestData)
                container_setup.read_Container_Data(TestData)

                if((TestData["Scenario_Type"]).upper() == "POSITIVE"):
                        containers_list.append(container_name)
                        success_msg = container_setup.save_Container()
                        expexcted_success_msg = "Container '" + container_name + " (Version: " + TestData["Version_Number"] + container_name.split("_")[-1] + ")' created successfully."
                        print(success_msg)
                        assert success_msg == expexcted_success_msg

                elif ((TestData["Scenario_Type"]).upper() == "NEGATIVE"):
                        assert container_setup.check_Save_Button_Disables() == True
                        container_setup.cancel_Create_Container()

            except Exception as e:
                container_setup.error_recovery()
                pytest.fail("Container Creation failed due to error : " + str(e))
        
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        print(containers_list)

    @pytest.mark.parametrize("TestData", Containers.ContainerActions.get_Container_TestData_As_JSON("UPDATE"))
    def test_update_containers(self,TestData,record_property,request,containers_list,init_browser, container_setup):

        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData["Execution"] != "SKIP" ):
            try:
                if(str(TestData["Name"]) == "None"):
                    TestData["Name"]= containers_list[0]

                print(TestData["Name"])
                container_name = container_setup.enter_Update_Container_Data(TestData)
                

                if(str(TestData["Scenario_Type"]).upper() == "POSITIVE"):
                        container_setup.save_Container()
                        success_msg = container_setup.save_Container()
                        assert success_msg == "Container '" + TestData['Name'] + " (Version: " + TestData["Version_Number"] + TestData['Name'] .split("_")[-1] + ")' updated successfully."

                elif (str(TestData["Scenario_Type"]).upper() == "NEGATIVE"):
                        print (container_setup.check_Save_Button_Disables())
                        assert container_setup.check_Save_Button_Disables() == True
                        container_setup.cancel_Create_Container()
                
            except Exception as e:
                container_setup.error_recovery()
                pytest.fail("Container Update failed due to error : " + str(e))       
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        print(containers_list)    

    @pytest.mark.parametrize("TestData", Containers.ContainerActions.get_Container_TestData_As_JSON("TRIGGER BUILD"))
    def test_trigger_build_for_existing_package(self,TestData,record_property,containers_list,init_browser,container_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)

        if (TestData["Execution"] != "SKIP" ):
            try:
                container_data = TestData["Name"].split(":")
                container_name = container_data[0]
                container_status = container_data[1]

                container_setup.navigate_to_Containers_Page()
                container_setup.ssearch_Container_And_Perform_Action(container_name,"TRIGGER BUILD")
                status = container_setup.get_build_status()
                assert status == container_status
            except Exception as e:
                container_setup.error_recovery()
                pytest.fail("Trigger Build Failed for Package")
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
            
    @pytest.mark.parametrize("TestData", Containers.ContainerActions.get_Container_TestData_As_JSON("PROMOTE"))
    def test_promote_containers(self,TestData,record_property,request,containers_list,init_browser, container_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData["Execution"] != "SKIP" ):
            try:
                if(str(TestData["Name"]) == "nan"):
                    TestData["Name"]= containers_list[0]
                container_setup.promote_Container_Data(TestData)
            except Exception as e:
                container_setup.error_recovery()
                pytest.fail("Container promotion failed due to error : " + str(e))       
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        print(containers_list)    

    @pytest.mark.parametrize("TestData", Containers.ContainerActions.get_Container_TestData_As_JSON("CLONE"))
    def test_Clone_Containers(self, TestData, record_property,request,containers_list,init_browser, container_setup):

        commons.set_Record_Property(record_property, {"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        #containername = "AUTO_CON_1219093709978476"
        if (TestData["Execution"] != "SKIP" ):
            containername = containers_list.pop()

            try:
                container_setup.navigate_to_Containers_Page()
                container_setup.search_Container_And_Perform_Action(containername,"CLONE")
                container_setup.read_Container_Data(TestData)
                container_name = container_setup.enter_Clone_Container_Data(TestData)
                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    containers_list.append([containername,TestData["Version_Number"],TestData["Git_Path"]])
                    success_msg = container_setup.save_Container()
                    assert success_msg.__contains__('success') == True
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert container_setup.check_Save_Button_Disables() == True
                    container_setup.cancel_Create_Container()
            except Exception as e:
                container_setup.error_recovery()
                pytest.fail("Container Cloning failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
        return containername


    def test_Jenkins_URL(self,containers_list,record_property,init_browser,container_setup):
        """
        This test method to validate the Jenkins URL link on the container list page
        :param containers_list: container_list is fixture call to store the created containers Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param container_setup: this is fixture call for creating the container POM class initialization
        :return:
        """
        # init_browser.refresh()
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-8447", "Short_Desc":"Create new Container in MC and validate Jenkins path"},"GUI", init_browser)
        try:
            containername = containers_list[0]
            container_setup.navigate_to_Containers_Page()
            container_setup.search_Container(containername)
            urls = container_setup.get_Jenkins_Path()

            assert urls=='https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Containers/job/' + containername
        except Exception as e:
            container_setup.error_recovery()
            pytest.fail("Container Jenkins URL Verification failed due to error : " + str(e))

    def test_GitHub_URL(self,containers_list,record_property,init_browser,container_setup):
        """
        This test method to validate the GitHUb URL link on the container list page
        :param containers_list: container_list is fixture call to store the created containers Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param container_setup: this is fixture call for creating the container POM class initialization
        :return:
        """
        # init_browser.refresh()
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},"GUI", init_browser)
        try:
            containername = containers_list[0]
            container_setup.navigate_to_Containers_Page()
            container_setup.search_Container(containername)
            urls = container_setup.get_GitHub_JenkinsURLs(containername)

            assert urls.__contains__(containername[0].split("_")[-1])
        except Exception as e:
            container_setup.error_recovery()
            pytest.fail("container GitHub URL Verification failed due to error : " + str(e))

    @pytest.mark.parametrize("TestData", Containers.ContainerActions.get_Container_TestData_As_JSON("DELETE"))
    def test_delete_containers(self,TestData,record_property,request,containers_list,init_browser, container_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)

        if (TestData["Execution"] != "SKIP" ):
            try:
                TestData["Name"]= containers_list.pop()
                container_setup.delete_Container_Data(TestData)
                if(str(TestData["Scenario_Type"]).upper() == "POSITIVE"):
                    container_setup.click_Popup_Yes_Button()
                    success_msg = container_setup.read_toast_message()
                    assert success_msg.__contains__('success') == True
                elif (str(TestData["Scenario_Type"]).upper() == "NEGATIVE"):
                    container_setup.click_Popup_Close_Button()
            except Exception as e:
                container_setup.error_recovery()
                pytest.fail("Container Deletion failed due to error : " + str(e))    
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")

        
    
