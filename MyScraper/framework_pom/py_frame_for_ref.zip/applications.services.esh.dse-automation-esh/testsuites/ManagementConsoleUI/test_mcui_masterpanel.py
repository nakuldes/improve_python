# import pytest
# from pageobjects import MasterPanel
# import conftest
#
#
# class Test_MasterPanel:
#
#     @pytest.fixture(scope='class', autouse=True)
#     def test_login_app(self):
#         loginb = MasterPanel.MasterPanel(conftest.driver)
#         loginb.login_to_application()
#
#
#     def test_create_package_class(self,record_property):
#
#         record_property("JIRA_ID","No JIRA TCs")
#
#         pageattribute = MasterPanel.MasterPanel(conftest.driver)
#
#         pageattribute.create_package_class("packageclass")