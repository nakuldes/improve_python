import time
import pytest
from pageobjects import Modules
from libs import commons
from utils import common
from selenium.webdriver.common.by import By


class Test_Modules:


    @pytest.fixture(scope='class', autouse=True)
    def module_setup(self,init_browser, initialize_environment,initialize_credentials):
        """
        This is fixture for Module class setup and perform login functionality
        :param init_browser:
        :param initialize_environment:
        :param get_credentials:
        :return: None
        """
        app = Modules.ModulesActions(init_browser)
        app.login_to_application(initialize_environment,initialize_credentials)
        return app

    @pytest.fixture(scope='class')
    def modules_list(self):
        """
        This is module for collevting the Module Name, Version & GitHUb URLs after successfull creation
        :return:
        """
        return []


    @pytest.mark.parametrize("TestData",Modules.ModulesActions.get_Module_TestData_As_JSON("CREATE"))
    def test_create_modules(self,TestData,record_property,modules_list,init_browser,module_setup):
        """
        This test is for Validating the Create Module functionality based on the test data provided in data file
        :param TestData: Data used for Creating the Modules with different combinations or positive and negtive data sets
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return: None
        """
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData["Execution"] != "SKIP"):
            try:
                module_name, unique_identifier = module_setup.enter_Create_Module_Data(TestData)
                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    success_msg = module_setup.save_Module()
                    modules_list.append([module_name,TestData["Version_Number"],TestData["Git_Path"], unique_identifier])
                    assert success_msg == "Module '" + module_name + " (Version: " + TestData["Version_Number"] + module_name.split("_")[-1] + ")' created successfully."
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert module_setup.check_Save_Button_Disables() == True
            except Exception as e:
                module_setup.error_recovery()
                pytest.fail("Module Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")


    def test_search_module(self, modules_list,record_property,init_browser,module_setup):
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-1990",
                                                     "Short_Desc": "Validate if the user is able to search using "
                                                                   "filter criteria and view the result in Modules "
                                                                   "page"}, "GUI", init_browser)
        try: 
            moduledata = modules_list[0]

            module_setup.search_Module(moduledata[0])
            elem = (By.XPATH, "//td/span[contains(text(),'" + moduledata[0] + "')]")
            assert module_setup.element_visible(elem)==True
        except Exception as e:
            module_setup.error_recovery()
            pytest.fail("Module search failed due to error : " + str(e))



    def test_cancel_create_module(self, modules_list,record_property,init_browser,module_setup):
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-2719,EETK-1957",
                                                     "Short_Desc":"Validate if a Warning alert box appears when Package manager enters some data and then clicks on Cancel button. Validate Cancel and Yes button functionality in the Warning alert box during Module creation in module page"},"GUI", init_browser)
        try:
            module_setup.navigate_to_Modules_Page()
            module_setup.navigate_to_Create_Module()
            module_setup.element_click(module_setup.MODULES_CANCEL)
            assert module_setup.element_visible(module_setup.MODULES_BUTTON_CREATE_NEW) == True
            module_setup.navigate_to_Create_Module()
            module_setup.enter_Display_Name("Temp Val")
            module_setup.cancel_Create_Or_Update_Module()
            assert module_setup.element_visible(module_setup.MODULES_BUTTON_CREATE_NEW) == True
        except Exception as e:
            module_setup.error_recovery()
            pytest.fail("Module Creation failed due to error : " + str(e))



    def test_cancel_update_module(self, modules_list,record_property,init_browser,module_setup):
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-2718", "Short_Desc":"Validate if Package manager is able to discard the changes by clicking on Cancel button during module creation/updation in module page"},"GUI", init_browser)
        try:    
            modulename = modules_list[0]
            module_setup.navigate_to_Modules_Page()
            module_setup.search_Module_And_Perform_Action(modulename[0],"EDIT")
            module_setup.element_click(module_setup.MODULES_CANCEL)
            assert module_setup.element_visible(module_setup.MODULES_BUTTON_CREATE_NEW) == True
            module_setup.search_Module_And_Perform_Action(modulename[0],"EDIT")
            module_setup.enter_Display_Name("Temp Val")
            module_setup.cancel_Create_Or_Update_Module()
            assert module_setup.element_visible(module_setup.MODULES_BUTTON_CREATE_NEW) == True
        except Exception as e:
            module_setup.error_recovery()
            pytest.fail("Module cancel_update failed due to error : " + str(e))

        

    def test_verify_JenkinsPathCreated(self,modules_list,record_property,init_browser,module_setup):
        """
        This test method to validate the Jenkins URLs after successfull creation of Module
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-1984",
                                                     "Short_Desc":"Validate Status is properly reflected in MC with "
                                                                  "respect to its Jenkins build status, and module "
                                                                  "status value changes, when Refresh icon is clicked "
                                                                  "in Modules page"}, "GUI", init_browser)
        try:
            init_browser.refresh()
            modulename = modules_list[0]

            module_setup.navigate_to_Modules_Page()
            module_setup.search_Module_And_Perform_Action(modulename,"EDIT")
            jenkins_url = module_setup.get_Jenkins_Path()
            # module_setup.cancel_Create_Or_Update_Module()
            jenkins_url_ui = "https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Modules/job/" + modulename
            assert jenkins_url == jenkins_url_ui
        except Exception as e:
            module_setup.error_recovery()
            pytest.fail("Module cancel_update failed due to error : " + str(e))


    def test_GitHub_URL(self,modules_list,record_property,init_browser,module_setup):
        """
        This test method to validate the GitHUb URL link on the module list page
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-7304",
                                                     "Short_Desc":"Create a Module with Github path and "
                                                                  "validate git icon "}, "GUI", init_browser)

        try:
            modulename = modules_list[0]
            module_setup.navigate_to_Modules_Page()
            module_setup.search_Module(modulename[0])
            urls = module_setup.get_GitHub_JenkinsURLs(modulename[0])

            assert urls[0]==modulename[2] + "/tree/" + modulename[1] + modulename[0].split("_")[-1]
        except Exception as e:
            module_setup.error_recovery()
            pytest.fail("Module cancel_update failed due to error : " + str(e))



    # @pytest.mark.parametrize("TestData",Modules.ModulesActions.get_Module_TestData_As_JSON("CLONE"))
    def test_clone_module(self, modules_list,record_property,init_browser,module_setup):
        """
        This test method to validate the delete module should not be allowed if the module is linked with another module
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-1985,EETK-3338",
                                                     "Short_Desc":"Validate if user is able to clone any module by "
                                                                  "clicking on clone button in Modules page,Validate "
                                                                  "if user having Package manager role is able to "
                                                                  "clone and save the modules"},"GUI", init_browser)
        try:
            moduledata = modules_list[0]

            module_setup.search_Module_And_Perform_Action(moduledata[0],"CLONE")
            module_setup.enter_Name(str(moduledata[0]) + "_Cloned")
            module_setup.enter_Version_Name(moduledata[1] + moduledata[3] + "-Cloned")
            module_setup.enter_GIT_Path(moduledata[2])
            module_setup.save_Module()
            module_setup.search_Module(str(moduledata[0]) + "_Cloned")
        except Exception as e:
            module_setup.error_recovery()
            pytest.fail("Module cancel_update failed due to error : " + str(e))



    def test_delete_Linked_Module(self,modules_list,record_property,init_browser,module_setup):
        """
        This test method to validate the delete module should not be allowed if the module is linked with another module
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc":"Test Case Summary"},
                                    "GUI", init_browser)
        try:
            modulename = modules_list[0]
            modulelink = modules_list[1]

            module_setup.navigate_to_Modules_Page()
            module_setup.search_Module_And_Perform_Action(modulename[0],"DELETE")
            message = module_setup.confirm_Delete_Verify_Message()
            module_setup.element_delete_text(module_setup.MODULES_COMMON_SEARCH)
            assert message == "Module '" + modulename[0] + " (Version: " + modulename[1] + modulename[0].split("_")[-1] + ")' is being used by '" + modulelink[0] + " (Version:" + modulelink[1] + modulelink[0].split("_")[-1] +")' module!"
        except Exception as e:
            module_setup.error_recovery()
            pytest.fail("Module cancel_update failed due to error : " + str(e))


    def test_delete_Module(self,modules_list,record_property,init_browser,module_setup):
        """
        This test method to validate the delete module should be allowed if the module is not linked with another module
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-2745",
                                                     "Short_Desc":"Validate if the  Package manager is able to "
                                                                  "delete the existing Modules in Modules page"},
                                    "GUI", init_browser)
        try:
            modulename = modules_list.pop()

            module_setup.navigate_to_Modules_Page()
            module_setup.search_Module_And_Perform_Action(modulename[0],"DELETE")
            message = module_setup.confirm_Delete_Verify_Message()
            module_setup.element_delete_text(module_setup.MODULES_COMMON_SEARCH)
            assert message == "Module '" + modulename[0] + " (Version: " + modulename[1] + modulename[0].split("_")[-1] + ")' deleted successfully."
        except Exception as e:
            pytest.fail("Module delete failed due to error : " + str(e))
            module_setup.error_recovery()


    def test_trigger_build_for_new_module(self,record_property,modules_list,init_browser,module_setup):
        """
        This test method to validate the Trigger Build functionality for module from list page
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return:
        """
        commons.set_Record_Property(record_property,{"JIRA_ID":"No Jira", "Short_Desc": "Test Case Summary"},
                                    "GUI", init_browser)
        try:
            modulename = modules_list[0]

            module_setup.navigate_to_Modules_Page()
            module_setup.search_Module_And_Perform_Action(modulename[0],"TRIGGER BUILD")
            finalStatus = module_setup.get_build_status()
            assert finalStatus == "Success"
        except Exception as e:
            pytest.fail("Module cancel_update failed due to error : " + str(e))


    @pytest.mark.parametrize("TestData",Modules.ModulesActions.get_Module_TestData_As_JSON("TRIGGER BUILD"))
    def test_trigger_build_for_existing_module(self,TestData,record_property,modules_list,init_browser,module_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if (TestData["Execution"] != "SKIP" ):
            try:
                module_data = TestData["Name"].split(":")
                module_name = module_data[0]
                module_status = module_data[1]
                module_setup.navigate_to_Modules_Page()
                module_setup.search_Module_And_Perform_Action(module_name,"TRIGGER BUILD")
                status = module_setup.get_build_status()
                assert status == module_status
            except Exception as e:
                pytest.fail("Trigger Build Failed for Module :" + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")


    @pytest.mark.parametrize("TestData",Modules.ModulesActions.get_Module_TestData_As_JSON("UPDATE"))
    def test_update_modules(self,TestData,record_property,modules_list,init_browser,module_setup):
        """
        This test method to validate that user is allowed to update the Module with valid data set
        :param TestData:
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return:
        """

        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        uniquestr = common.get_Current_TimeStamp()

        if (TestData["Execution"] != "SKIP" ):
            try:
                module_name = TestData["Name"] + uniquestr if(str(TestData["Name"]) != "None") else ""
                module_setup.navigate_to_Modules_Page()
                module_setup.search_Module_And_Perform_Action(module_name,"EDIT")
                namestatus = module_setup.check_ModuleNameDisabled()
                # print(namestatus)
                module_setup.enter_Display_Name(TestData["Display_Name"]+uniquestr if (str(TestData["Display_Name"])!= "nan") else "",True)
                module_setup.enter_Discription( TestData["Description"]+uniquestr if (str(TestData["Description"])!= "nan") else "",True)
                # module_setup.enter_More_Info(More_Info)
                module_setup.enter_Version_Name( TestData["Version_Number"]+uniquestr if (str(TestData["Version_Number"])!= "None") else "" ,True)
                module_setup.select_Dependency_Type(TestData["Dependency_Type"])
                module_setup.enter_GIT_Path(TestData["Git_Path"], True)
                module_setup.select_Custom_Branch(TestData["Custom_Branch"],TestData["Branch_Name"])
                module_setup.enter_More_Info_Link(TestData["More_Info_Link"] if (str(TestData["More_Info_Link"])!= "nan") else "",True)
                module_setup.enter_Release_Tag(TestData["Release_Tag"]+uniquestr if (str(TestData["Release_Tag"])!= "nan") else "",True)
                module_setup.enter_Folder_Name(TestData["Folder_Name"]+uniquestr if (str(TestData["Folder_Name"])!= "nan") else "",True)
                # module_setup.enter_Jenkins_Job(Jenkins_Path)
                module_setup.select_Default_Installation(TestData["Branch_Name"])
                module_setup.select_Disable_Jenkins(TestData["Disable_Jenkins"])
                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    success_msg = module_setup.save_Module()
                    assert success_msg == "Module '" + module_name + " (Version: " + TestData["Version_Number"] + module_name.split("_")[-1] + ")' updated successfully."
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    print (module_setup.check_Save_Button_Disables())
                    assert module_setup.check_Save_Button_Disables() == True
            except Exception as e:
                pytest.fail("Module update failed due to error : " + str(e))
                module_setup.error_recovery()
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")



    def test_Jenkins_URL_navgation(self,modules_list,record_property,init_browser,module_setup):
        """
        This test method to validate the Jenkins URL link on the module list page
        :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
                             for following test usages
        :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
                                to the pytest.html report
        :param init_browser: this is fixture call for initializing the browser
        :param module_setup: this is fixture call for creating the Module POM class initialization
        :return:
        """
        # init_browser.refresh()
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-1987", "Short_Desc":
            "Validate if user is able to redirect to Jenkins job of any module by clicking on Jenkins "
            "icon in Jenkins column in modules page"},"GUI", init_browser)

        try:
            modulename = modules_list[0]

            module_setup.navigate_to_Modules_Page()
            module_setup.search_Module(modulename[0])
            module_setup.click_github_jenkinslinks(modulename[0], "jenkins")
        except Exception as e:
            pytest.fail("Jnekins URL navigation failed due to error : " + str(e))
            module_setup.error_recovery()



    # def test_git_url_navgation(self,modules_list,record_property,init_browser,module_setup):
    #     """
    #     This test method to validate the Jenkins URL link on the module list page
    #     :param modules_list: module_list is fixture call to store the created modules Name, Vrrsion & GitHUb URL
    #                          for following test usages
    #     :param record_property: Record property is in build pytest parameter used to pass the test parameters/data
    #                             to the pytest.html report
    #     :param init_browser: this is fixture call for initializing the browser
    #     :param module_setup: this is fixture call for creating the Module POM class initialization
    #     :return:
    #     """
    #     # init_browser.refresh()
    #     modulename = modules_list[0]
    #     commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-1984", "Short_Desc":"Validate Status is
    #     properly reflected in MC with respect to its Jenkins build status, and module status value changes,
    #     when \"Refresh\" icon is clicked in Modules page"},"GUI", init_browser)
    #
    #     module_setup.navigate_to_Modules_Page()
    #     module_setup.search_Module(modulename[0])
    #     module_setup.click_github_jenkinslinks(modulename[0], "git")