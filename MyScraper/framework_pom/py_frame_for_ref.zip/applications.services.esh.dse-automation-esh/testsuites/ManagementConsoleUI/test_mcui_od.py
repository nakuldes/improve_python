import time
import pytest
from pageobjects import OD
from libs import commons
from utils import common
import utils
from selenium.webdriver.common.by import By

class Test_OD:


    @pytest.fixture(scope='class', autouse=True)
    def OD_setup(self,init_browser, initialize_environment,initialize_credentials):
        
        app = OD.ODActions(init_browser)
        app.login_to_application(initialize_environment,initialize_credentials)
        return app

    @pytest.fixture(scope='class')
    def od_list(self):
        return []

    
    @pytest.mark.parametrize("TestData",OD.ODActions.get_OD_TestData_As_JSON("CREATE"))
    def test_create_OD(self,TestData,record_property,od_list,init_browser,OD_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        
        time.sleep(7)
        uniquestr = utils.common.get_Current_TimeStamp()
        if(TestData["Execution"] != "SKIP"):
            try:
                TestData["Name"]=TestData["Name"] + uniquestr if(str(TestData["Name"]) != "None") else ""
                OD_name = TestData["Name"]
                OD_setup.enter_Create_OD_Data(TestData)

                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    od_list.append([OD_name,TestData["Version_Number"]])
                    try:
                        success_msg = OD_setup.save_OD()
                    except Exception as e:
                        pytest.fail("Online Distribution Creation failed due to error : " + str(e))
                    # Online Distribution 'Auto_OD_Name_20220722141219 (Version: 1.1.1.202207221412192s)' created successfully.
                    assert success_msg == "Online Distribution '" + OD_name + " (Version: " + TestData["Version_Number"] + OD_name.split("_")[-1] + ")' created successfully."
                    
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert OD_setup.check_Save_Button_Disables() == True
                    OD_setup.cancel_Create_OD()
                    
            except Exception as e:
                OD_setup.error_recovery()
                pytest.fail("Online Distribution Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")
    


    @pytest.mark.parametrize("TestData",OD.ODActions.get_OD_TestData_As_JSON("UPDATE"))

    def test_update_OD(self,TestData,record_property,od_list,init_browser,OD_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if(TestData["Execution"] != "SKIP"):
            try:
                if(str(TestData["Name"]) == "None"):
                    TestData["Name"]= od_list[0][0]                                                    
                OD_setup.enter_Update_OD_Data(TestData)
                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                #od_list.append([OD_name,TestData["Version_Number"]])
                    success_msg = OD_setup.save_OD()
                    # assert success_msg == "Online Distribution '" + TestData["Name"] + " (Version: " + TestData["Version_Number"] + TestData["Name"].split("_")[-1] + ")' created successfully."
                    assert success_msg == "Online Distribution Updated Succesfully."
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert OD_setup.check_Save_Button_Disables() == True
                    OD_setup.cancel_Create_OD()
                    
            except Exception as e:
                OD_setup.error_recovery()
                pytest.fail("OD Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")

    @pytest.mark.parametrize("TestData",OD.ODActions.get_OD_TestData_As_JSON("MULTIPLE_VERSION"))
    def test_create_multiple_versions_of_OD(self,TestData,record_property,od_list,init_browser,OD_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        if(TestData["Execution"] != "SKIP"):
            try:
                if(str(TestData["Name"]) == "None"):
                    TestData["Name"]= od_list[0][0]
                                                                 
                OD_setup.enter_new_version_OD_Data(TestData)
                if(TestData["Scenario_Type"].upper() == "POSITIVE"):
                    od_list.append([TestData["Name"],TestData["Version_Number"]])
                    success_msg = OD_setup.save_OD()
                    assert success_msg == "Online Distribution '" + TestData["Name"] + " (Version: " + TestData["Version_Number"]  + ")' created successfully."
                    #assert success_msg == "Online Distribution Updated Succesfully."
                elif (TestData["Scenario_Type"].upper() == "NEGATIVE"):
                    assert OD_setup.check_Save_Button_Disables() == True
                    OD_setup.cancel_Create_OD()
                    
            except Exception as e:
                OD_setup.error_recovery()
                pytest.fail("OD Creation failed due to error : " + str(e))
        else:
            pytest.skip("Skipping as this test case is marked as SKIP in test data")

    def test_OD_section_columns(self,record_property,init_browser,OD_setup):
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-6136", "Short_Desc":"Validate if user is able to see these columns on Online Distribution page a) Name b) UUID c) Version Selector d) Display Name e) Description f) Created By g) Created On h) Actions"},"GUI", init_browser)
        # list_of_column_headers = ['Name', 'Version', 'Display Name', 'UUID', 'Description', 'Created By', 'Actions', 'Created On']
        list_of_column_headers = ['Name', 'Version', 'Display Name',  'Actions']
        headers_found = OD_setup.verify_OD_table_columns(list_of_column_headers)
        assert headers_found == True




    def test_search_OD(self,record_property,od_list,init_browser,OD_setup):
        report_data = {"JIRA_ID": "EETK-8598",
                       "Short_Desc": "Validate search functionality in Online Distribution page",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "GUI",init_browser)
        ODdata = od_list[0]
        OD_setup.search_OD(ODdata[0])
        elem = (By.XPATH, "//td/span[contains(text(),'" + ODdata[0] + "')]")
        assert OD_setup.element_visible(elem)==True

    def test_clone_OD(self, od_list,record_property,init_browser,OD_setup):
        ODdata = od_list[0]
        commons.set_Record_Property(record_property,{"JIRA_ID":"EETK-6139, EETK-6135",
                                                     "Short_Desc":"Validate if user is able to clone the existing Online Distribution"},"GUI", init_browser)
        OD_name=str(ODdata[0]) + "-Cloned"
        OD_version=str(ODdata[1])
        OD_setup.search_OD_And_Perform_Action(ODdata[0],"CLONE")
        OD_setup.enter_OD_name(str(ODdata[0]) + "-Cloned")
        OD_setup.enter_OD_Version(OD_version)
        time.sleep(5)
        success_msg =OD_setup.save_OD()
        assert success_msg == "Online Distribution '" + OD_name + " (Version: " + OD_version  + ")' created successfully."
        

    @pytest.mark.parametrize("TestData",OD.ODActions.get_OD_TestData_As_JSON("DELETE"))
    def test_delete_OD(self, TestData, od_list,record_property,init_browser,OD_setup):
        commons.set_Record_Property(record_property,TestData,"GUI", init_browser)
        time.sleep(5)
        ODname = od_list.pop()
        OD_setup.wait_loader_to_vanish()
        OD_setup.navigate_to_OD_Page()
        OD_setup.search_OD_And_Perform_Action(ODname[0],"DELETE")
        message = OD_setup.confirm_Delete_Verify_Message()
        assert message == "Online Distribution deleted Succesfully."