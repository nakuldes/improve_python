import requests
import pytest
import json
from utils import FileOperations as fo
from libs import commons
from configs import ManagementConsole as mcapi
import conftest
from libs import API_responseValidation as api_validation
from libs import API_dataProvider

class Test_RecipeAPI:

    global record_prop
    record_prop = {"JIRA_ID": "No JIRA", "Short_Desc": "No Desc"}

    @pytest.mark.parametrize("TestData",API_dataProvider.fetch_package_data() )
    def test_GetRecipeData(self,record_property, TestData):

        record_prop = {"JIRA_ID":"EETK-10918","Short_Desc":"Validate fetching all recipe details using uuid via service layer APIs"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

        hosturl = conftest.service_layer_qa + "/recipe/" + TestData['pkg_uuid']+"?detail=true"
        res = requests.get(url=hosturl,verify=False)
        #conftest.logger.info("Verifying get recipe API")
        assert res.status_code==200

    
    # def test_GetDownloadRecipeInfo(self,record_property):
    #     pytest.mark.skip(reason=" ")
    #     record_prop = {"JIRA_ID":"EETK-10919","Short_Desc":"Validate fetching all available recipe details via service layer APIs"}
    #     commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

    #     hosturl = conftest.service_layer_qa + "/downloadRecipeInfo"
    #     res = requests.get(url=hosturl,verify=False)
    #     data=res.json()
    #     jsonres_validation= api_validation.getJSONSchema(data,"downloadRecipeinfoJSON")
    #     assert jsonres_validation==True
        # assert res.status_code==200

    '''def test_CreateDownloadRecipeInfo(self,record_property):
            commons.set_Record_Property(record_property,record_prop,"API", "No Browser")
        payload ={
	                "productKey":"8ced7cfa-489d-4f68-b478-58b3065addfa",
	                "components":["5e8c4742e02f17002a2a6976"],
                  "images":[],
                  "recipeId":"60cafe31801463002a7b4d77",
                  "enterpriseId":"11983028"
                  }
        hosturl = conftest.service_layer_qa + "/downloadRecipeInfo"
        res = requests.post(url=hosturl+"/downloadRecipeInfo",
                           json=payload,
                           headers={'Content-Type': 'application/json'},
                           verify=False)
        data=res.json()
        jsonres_validation= api_validation.getJSONSchema(data,"createdownloadRecipeinfoJSON")
        assert jsonres_validation==True
        assert res.status_code==200 
    '''

    def test_GetRecipe(self,record_property):
        record_prop = {"JIRA_ID":"EETK-10919","Short_Desc":"Validate fetching all available recipe details via service layer APIs"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")
        hosturl = conftest.service_layer_qa+ "/recipe"
        res = requests.get(url=hosturl,verify=False)
        data=res.json()
        jsonres_validation= api_validation.getJSONSchema(data,"AllRecipeJSON")
        assert jsonres_validation==True
        assert res.status_code==200

   
    # @pytest.mark.parametrize("TestData",API_dataProvider.fetch_package_data() )
    # def test_CreateRecipe(self,record_property,TestData):
    #     pytest.mark.skip(reason=" ")
    #     record_prop = {"JIRA_ID":"EETK-7386","Short_Desc":"Validate response of SL API for fetching S3 pre signed url for invalid module download via postman","Data": ""}
    #     commons.set_Record_Property(record_property,record_prop,"API")
    #     payLoad = {"id":TestData["pkg_uuid"]}
    #     with open(conftest.data_filepath, "r") as f:
    #             data = json.load(f)
    #             payLoad.update({"name": {
    #                             "en": TestData['pkg_name']},
    #                             "licenseAgreement" : {"en":data["licenseAgreement"]["en"][0]}})
    #     hosturl = conftest.service_layer_qa+ "/recipe"
    #     res = requests.post(url=hosturl,
    #                         json = payLoad,
    #                         headers={'Content-Type': 'application/json'},
    #                         verify=False)
    #     data=res.json()
    #     jsonres_validation= api_validation.getJSONSchema(data,"CreateJSON")
    #     assert jsonres_validation==True
    #     assert res.status_code==200

    #REPEATED
    @pytest.mark.parametrize("TestData",API_dataProvider.fetch_package_data() )
    def test_GetRecipeById(self,record_property, TestData):
        record_prop = {"JIRA_ID":"EETK-10918","Short_Desc":"Validate fetching all recipe details using uuid via service layer APIs"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

        hosturl = conftest.service_layer_qa+ "/recipe/" +TestData["pkg_uuid"]
        res = requests.get(url=hosturl,verify=False)
        data=res.json()
        jsonres_validation= api_validation.getJSONSchema(data,"RecipebyIdJSON")
        assert jsonres_validation==True
        assert res.status_code==200

    def test_GetAllUiroutes(self,record_property):
        record_prop = {"JIRA_ID":"EETK-10920","Short_Desc":"Validate fetching UI routes of all available recipies"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

        hosturl = conftest.service_layer_qa + "/recipe/getAllByUiRoute"
        res = requests.get(url=hosturl,verify=False)
        data=res.json()
        jsonres_validation= api_validation.getJSONSchema(data,"getAlluiJSON")
        assert jsonres_validation==True
        assert res.status_code==200

    @pytest.mark.parametrize("TestData",API_dataProvider.fetch_package_data() )
    def test_RecipeVersionsByName(self,record_property, TestData):
        record_prop = {"JIRA_ID":"EETK-10921","Short_Desc":"Validate fetching all version of a recipe"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

        hosturl = conftest.service_layer_qa+ "/recipe/getAllVersionByName/"+TestData['pkg_name']
        res = requests.get(url=hosturl,verify=False)
        data=res.json()
        jsonres_validation= api_validation.getJSONSchema(data,"recipeBynameJSON")
        assert jsonres_validation==True
        assert res.status_code==200

    @pytest.mark.parametrize("TestData",API_dataProvider.fetch_package_data() )
    def test_RecipeByRecipeType(self,record_property, TestData):
        record_prop = {"JIRA_ID":"EETK-10922","Short_Desc":"Validate fetching all recipes which are using same recipe type"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

        hosturl = conftest.service_layer_qa+ "/recipe/getAllByRecipeType/"+TestData['recipe_type_id']
        res = requests.get(url=hosturl,verify=False)
        data=res.json()
        jsonres_validation= api_validation.getJSONSchema(data,"recipeBynameJSON")
        assert jsonres_validation==True
        assert res.status_code==200

    def test_GetAllRecipeType(self,record_property):
        record_prop = {"JIRA_ID":"EETK-10923","Short_Desc":"Validate fetching all recipesTypes"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

        hosturl = conftest.service_layer_qa + "/recipe/recipeType"
        res = requests.get(url=hosturl,verify=False)
        data=res.json()
        jsonres_validation= api_validation.getJSONSchema(data,"recipetypeJSON")
        assert jsonres_validation==True
        assert res.status_code==200

    # A recipe with other files should be created and id of that package needs to be sent with this url
    def test_GetRecipeOtherfilesData(self,record_property):
        record_prop = {"JIRA_ID":"EETK-7395","Short_Desc":"Validate other files(readme, documentation etc) download with S3 pre signed url in browser"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

        hosturl = conftest.service_layer_qa + "/recipe/61de9445df0db0002bf82f07"
        res = requests.get(url=hosturl,verify=False)
        with open( conftest.download_dir+"/recipeotherfiles.zip", "wb") as zip:
                zip.write(res.content)
        assert res.status_code==200

    def test_RecipeOtherfilesInvalidID(self,record_property):
        record_prop = {"JIRA_ID":"EETK-7394","Short_Desc":"Validate response of SL API for fetching S3 pre signed url for invalid resource files download via postman"}
        commons.set_Record_Property(record_property,record_prop,"API", "No Browser")

        hosturl = conftest.service_layer_qa + "/recipe/61de9445df0db0002bf82f07"
        res = requests.get(url=hosturl,verify=False)
        with open( conftest.download_dir+"/recipeotherfiles.zip", "wb") as zip:
                zip.write(res.content)
        assert res.status_code==400

    def test_GetSupportedModulesUB18(self, record_property):
        record_prop = {"JIRA_ID": "EETK-10937",
                       "Short_Desc": "Validate getting list of UUIDs of all Ubuntu 18 supported modules of a recipe using service layer APIsF"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = conftest.service_layer_qa + \
            "/recipe/supportedModules/6194f54d806bce00222e8d38?osId=5e81c3132ed228002ae08bc7"
        res = requests.get(url=hosturl, verify=False)
        assert res.status_code == 200

    def test_GetSupportedModulesUB20(self, record_property):
        record_prop = {"JIRA_ID": "EETK-10939",
                       "Short_Desc": "Validate getting list of UUIDs of all Ubuntu 20 supported modules of a recipe using service layer APIs"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = conftest.service_layer_qa + \
            "/recipe/supportedModules/6194f54d806bce00222e8d38?osId=60126c55d9555f002a8049fb"
        res = requests.get(url=hosturl, verify=False)
        assert res.status_code == 200

    def test_RecipeUpgrade(self, record_property):
        record_prop = {"JIRA_ID": "EETK-10941",
                       "Short_Desc": "Validate getting XML file in response for upgrading a recipe using service layer APIs"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = conftest.service_layer_qa + "/recipe/upgrade"
        payload = {
            "recipeId": "6194f54d806bce00222e8d38",
            "productKey": "beae7862-4dec-4ce7-a8ac-8b6f9a3b787e",
            "osId": "5e81c3132ed228002ae08bc7",
            "order": "installation"
        }
        res = requests.post(url=hosturl, json=payload, verify=False)
        assert res.status_code == 200

    def test_GetXmlOfRecipe(self, record_property):
        record_prop = {"JIRA_ID": "EETK-10943",
                       "Short_Desc": "Validate getting XML file of a recipe using Service Layer APIs"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = conftest.service_layer_qa + \
            "/recipe/upgrade/6194f54d806bce00222e8d38?order=display"
        res = requests.get(url=hosturl, verify=False)
        assert res.status_code == 200

    def test_ValidateProductKey(self, record_property):
        record_prop = {"JIRA_ID": "EETK-10944",
                       "Short_Desc": "Verify working of validate product key service layer API for recipes"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = conftest.service_layer_qa + "/recipe/validateProductKey"
        payload = {
            "recipeId": "6194f54d806bce00222e8d38",
            "productKey": "beae7862-4dec-4ce7-a8ac-8b6f9a3b787e"
        }
        res = requests.post(url=hosturl, json=payload, verify=False)
        assert res.status_code == 200
