import requests
import pytest
import json
from utils import FileOperations as fo
from libs import commons
from configs import ManagementConsole as mcapi
import conftest
from libs import API_responseValidation as api_validation
from libs import API_dataProvider


class Test_HelmchartAPI:

    def test_Helmchartdownload(self, record_property):
        record_prop = {"JIRA_ID": "EETK-7391",
                       "Short_Desc": "Validate helm chart tgz file download with S3 pre signed url in browser"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        payLoad = {
            "id": "62bd63d621ae23002178aa6f",
            "productKey": ""
        }
        hosturl = conftest.service_layer_qa+"/helmChart/download"
        res = requests.post(url=hosturl,
                            json=payLoad,
                            verify=False)
        print(res.text)
        with open(conftest.download_dir+"/helmchart.zip", "wb") as zip:
            zip.write(res.content)
        assert res.status_code == 200

    def test_HelmchartdownloadInvalidID(self, record_property):
        record_prop = {"JIRA_ID": "EETK-7390",
                       "Short_Desc": "Validate response of SL API for fetching S3 pre signed url for invalid helm chart download via postman"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        payLoad = {
            "id": "62bd4b6dc8b7cc00205e969c",
            "productKey": ""
        }
        hosturl = conftest.service_layer_qa+"/helmChart/download"
        res = requests.post(url=hosturl,
                            json=payLoad,
                            verify=False)
        assert res.status_code == 404

    def test_GetHelmchartbyNameandTag(self, record_property):

        record_prop = {"JIRA_ID":"EETK-10938","Short_Desc":"Validate fetching Helmchart details by Name and Tag"}

        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")

        hosturl = conftest.service_layer_qa + "/helmChart/chart?name=" + \
            "multimodal-data-visualization-chart"+"&tag="+"3.0"
        res = requests.get(url=hosturl, verify=False)

        assert res.status_code == 200

    def test_ValidateMD5(self, record_property):

        record_prop = {"JIRA_ID":"EETK-10940","Short_Desc":"Validate helmchart MD5 value using Service Layer API"}

        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")

        data = API_dataProvider.fetch_ingredient_data()

        payLoad = {"id": "62d5313d1a93fe00214d908e",
                   "value": "0ca21e649778f044b313ebbc84a8ea87"}

        hosturl = conftest.service_layer_qa+"/helmChart/validate"
        res = requests.post(url=hosturl,
                            json=payLoad,
                            verify=False)

        assert res.status_code == 200

    def test_GetHelmchartbyId(self, record_property):

        record_prop = {"JIRA_ID":"EETK-10942","Short_Desc":"Validate fetching Helmchart details by ID using SL API"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = conftest.service_layer_qa + \
            "/helmChart/getById/"+"62d5313d1a93fe00214d908e"
        res = requests.get(url=hosturl, verify=False)

        assert res.status_code == 200
