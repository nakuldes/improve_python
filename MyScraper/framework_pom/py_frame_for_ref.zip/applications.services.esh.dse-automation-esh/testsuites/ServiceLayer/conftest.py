import pytest
import requests
from configs import ServiceLayer as sl
from configs import ManagementConsole as mc
from configs import EdgeSoftwareHubUI_CLI as eshui
from urllib3.exceptions import InsecureRequestWarning

@pytest.fixture(scope='class',autouse=True)
def init_env(pytestconfig):
    global mc_url, esh_url,mc_api_qa, logger, service_layer_qa,data_filepath,download_dir

    env = pytestconfig.getoption("env")
    data_filepath=sl.data_filepath
    download_dir=sl.download_dir
    if(env == "QA"):

        mc_url = mc.MC_QA
        esh_url = eshui.ESH_QA
        mc_api_qa = mc.MC_API_HOST_QA
        service_layer_qa = sl.SERVICE_LAYER_HOST
    elif (env == "DEV"):
        mc_url = mc.MC_DEV
        esh_url = eshui.ESH_DEV

@pytest.fixture(scope='class')
def recipe_Data():
    data={}
    data['pkg_uuid']=sl.pkg_uuid
    data['recipe_name']=sl.recipe_name
    data['recipe_type_id']=sl.recipe_type_id
    return data

@pytest.fixture(scope='class')
def docker_Data():
    data={}
    data['image_id']=sl.image_id
    data['img_productKey']=sl.img_productKey
    data['image_name']=sl.image_name
    data['image_tag']=sl.image_tag
    return data

@pytest.fixture(scope='class')
def ingredient_Data():
    data={}
    data['module_uuid']=sl.module_uuid
    data['md5sum_value']=sl.md5sum_value
    data['product_key']=sl.product_key
    return data

@pytest.fixture(scope='class')
def initialize_request():
    session = requests.Session()
    headers = {'Content-Type': 'application/json'}
    session.headers.update(headers)
    session.verify = False
    return session