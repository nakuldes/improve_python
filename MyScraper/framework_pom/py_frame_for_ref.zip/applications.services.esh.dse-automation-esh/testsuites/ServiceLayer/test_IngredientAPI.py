import requests
import pytest
import json
from utils import FileOperations as fo
from libs import commons
from configs import ManagementConsole as mcapi
import conftest
from libs import API_responseValidation as api_validation
from libs import API_dataProvider


class Test_IngredientAPI:

    global record_prop
    record_prop = {"JIRA_ID": "No JIRA", "Short_Desc": "No Desc"}

    def test_ValidateMD5(self, record_property):
        record_prop = {"JIRA_ID": "EETK-7386",
                       "Short_Desc": "Validate response of SL API for fetching S3 pre signed url for invalid module download via postman", "Data": ""}
        commons.set_Record_Property(record_property, record_prop, "API")
        data = API_dataProvider.fetch_ingredient_data()
        payLoad = {"id": data['module_uuid'],
                   "value": data['md5sum_value']}
        hosturl = conftest.service_layer_qa+"/ingredient/validate"
        res = requests.post(url=hosturl,
                            json=payLoad,
                            verify=False)
        data = res.json()
        jsonres_validation = api_validation.getJSONSchema(data, "MD5JSON")
        assert jsonres_validation == True
        assert res.status_code == 200

    # @pytest.mark.skip()
    # def test_IngredientUpdate(self,record_property):
    #     record_prop = {"JIRA_ID":"EETK-7386","Short_Desc":"Validate response of SL API for fetching S3 pre signed url for invalid module download via postman","Data": ""}
    #     commons.set_Record_Property(record_property,record_prop,"API")
    #     data=API_dataProvider.fetch_ingredient_data()
    #     payLoad={ "id": data['module_uuid'] ,
    #               "name": {"en": "ESB common"},
    #               "hashValue": data['md5sum_value']
    #             }
    #     hosturl = conftest.service_layer_qa+"/ingredient"
    #     res = requests.post(url=hosturl,
    #                        json=payLoad,
    #                        verify=False)
    #     data=res.json()
    #     jsonres_validation= api_validation.getJSONSchema(data,"CreateJSON")
    #     assert jsonres_validation==True
    #     assert res.status_code==200

    def test_Downloadzip(self, record_property):
        commons.set_Record_Property(record_property, record_prop, "API")
        data = API_dataProvider.fetch_ingredient_data()
        payLoad = {"component": data['module_uuid'],
                   "productKey": data['product_key']}
        hosturl = conftest.service_layer_qa+"/ingredient/download"
        res = requests.post(url=hosturl,
                            json=payLoad,
                            headers={'Content-Type': 'application/json'},
                            verify=False)
        with open(conftest.download_dir+"/"+data['module_uuid']+".zip", "wb") as zip:
            zip.write(res.content)
        assert res.status_code == 302

    def test_s3presignedURLvalidID(self, record_property):
        record_prop = {"JIRA_ID": "EETK-7387",
                       "Short_Desc": "Validate module zip file download with S3 pre signed url in browser", "Data": ""}
        commons.set_Record_Property(record_property, record_prop, "API")
        data = API_dataProvider.fetch_ingredient_data()
        payLoad = {
            "component": "63173c7c5193e50021cb20cc",
            "recipeId": "631748380ab3ed0014298704",
            "productKey": "beae7862-4dec-4ce7-a8ac-8b6f9a3b787e"
        }
        hosturl = conftest.service_layer_qa+"/ingredient/download"
        res = requests.post(url=hosturl,
                            json=payLoad,
                            headers={'Content-Type': 'application/json'},
                            verify=False)
        with open(conftest.download_dir+"/ingredientdownload.zip", "wb") as zip:
            zip.write(res.content)
        assert res.status_code == 302

    def test_s3presignedURLInvalidID(self, record_property):
        record_prop = {"JIRA_ID": "EETK-7386",
                       "Short_Desc": "Validate response of SL API for fetching S3 pre signed url for invalid module download via postman", "Data": ""}
        commons.set_Record_Property(record_property, record_prop, "API")
        data = API_dataProvider.fetch_ingredient_data()
        payLoad = {
            "component": "63173c7c5193e50021cb20cd",
            "recipeId": "631748380ab3ed0014298704",
            "productKey": "beae7862-4dec-4ce7-a8ac-8b6f9a3b787e"
        }
        hosturl = conftest.service_layer_qa+"/ingredient/download"
        res = requests.post(url=hosturl,
                            json=payLoad,
                            headers={'Content-Type': 'application/json'},
                            verify=False)
        assert res.status_code == 404
