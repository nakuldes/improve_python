import requests
import pytest
import json
from utils import FileOperations as fo
from libs import commons
from configs import ManagementConsole as mcapi
import conftest
from libs import API_responseValidation as api_validation
from libs import API_dataProvider


class Test_DockerAPI:

    global record_prop
    record_prop = {"JIRA_ID": "No JIRA", "Short_Desc": "No Desc"}

    def test_GetAllDockerImages(self, record_property):
        report_data = {"JIRA_ID": "EETK-10926",
                       "Short_Desc": "Validate fetching list of all container images in SL with API",
                       "Data": ""}
        commons.set_Record_Property(
            record_property, report_data, "API", "No Browser")

        hosturl = conftest.service_layer_qa + "/docker"
        res = requests.get(url=hosturl, verify=False)
        data = res.json()
        jsonres_validation = api_validation.getJSONSchema(
            data, "AllDockerJSON")
        assert jsonres_validation == True
        assert res.status_code == 200

    # @pytest.mark.parametrize("TestData", API_dataProvider.fetch_package_data())
    # def test_UpdateDocker(self, record_property, TestData):
    #     commons.set_Record_Property(
    #         record_property, record_prop, "API", "No Browser")
    #     if "image_name" in TestData:
    #         payLoad = {"id": TestData['image_id'],
    #                    "createdBy": "null",
    #                    "createdOn": "2020-02-28T04:18:02.000Z",
    #                    "description": "Automated Checkout ms-inventory Docker Image",
    #                    "modifiedBy": "null",
    #                    "modifiedOn": "2020-02-28T04:18:02.000Z",
    #                    "moreInfo": "www.intel.com",
    #                    "name": {"en": "Automated Checkout ms-inventory"},
    #                    "image": "automated-checkout/ms-inventory",
    #                    "tag": "dev"}
    #         hosturl = conftest.service_layer_qa + "/docker"

    #         res = requests.post(url=hosturl,
    #                             json=payLoad,
    #                             verify=False)
    #         data = res.json()
    #         jsonres_validation = api_validation.getJSONSchema(
    #             data, "CreateJSON")
    #         assert jsonres_validation == True
    #         assert res.status_code == 200
    #     else:
    #         pytest.skip(
    #             "Skipping this TC as Image ID doesn't exist for this Ingredient!!")

    def test_valProductKeyandGetRobotAccount(self, record_property, docker_Data):
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")

        payLoad = {"imageId": "62cd8a773b232200201f8b03",
                   "productKey": "fe25d383-5d70-4da9-b7ac-2b397f89dd65"}
        hosturl = conftest.service_layer_qa + "/docker/robot"

        res = requests.post(url=hosturl,
                            json=payLoad,
                            verify=False)
        data = res.json()
        jsonres_validation = api_validation.getJSONSchema(
            data, "RobotAccountJSON")
        assert jsonres_validation == True
        assert res.status_code == 200

    # @pytest.mark.parametrize("TestData", API_dataProvider.fetch_package_data())
    # def test_DeleteDockerImage(self, record_property, TestData):
    #     commons.set_Record_Property(
    #         record_property, record_prop, "API", "No Browser")
    #     if "image_name" in TestData:
    #         hosturl = conftest.service_layer_qa + \
    #             "/docker/image/"+TestData['image_id']
    #         res = requests.delete(url=hosturl, verify=False)
    #         assert res.status_code == 200
    #     else:
    #         pytest.skip(
    #             "Skipping this TC as Image ID doesn't exist for this Ingredient!!")

    @pytest.mark.parametrize("TestData", API_dataProvider.fetch_package_data())
    def test_GetimagebyNameandTag(self, record_property, TestData):
        report_data = {"JIRA_ID": "EETK-10927",
                       "Short_Desc": "Validate fetching container image details by using image name and image tag via ServiceLayer API",
                       "Data": ""}
        commons.set_Record_Property(
            record_property, report_data, "API", "No Browser")
        if "image_name" in TestData:
            hosturl = conftest.service_layer_qa+"/docker/image?name=" + \
                TestData['image_name']+"&tag="+TestData['image_tag']
            res = requests.get(url=hosturl,
                               verify=False)
            assert res.status_code == 200
        else:
            pytest.skip(
                "Skipping this TC as Image ID doesn't exist for this Ingredient!!")

    def test_ValidateImageProductKey(self, record_property):
        record_prop = {"JIRA_ID": "EETK-10945",
                       "Short_Desc": "Verify working of validate product key service layer API for containers"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = conftest.service_layer_qa + "/docker/validate/productkey"
        payload = {
            "imageId": "62f3ba929d0187002145de11",
            "productKey": "c3d654c0-aa22-42c2-b361-972ffd0b507e"
        }
        res = requests.post(url=hosturl, json=payload, verify=False)
        assert res.status_code == 200
