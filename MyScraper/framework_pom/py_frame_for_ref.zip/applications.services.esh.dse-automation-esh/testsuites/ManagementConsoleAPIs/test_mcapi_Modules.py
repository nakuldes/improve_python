import utils
import requests
import pytest
from utils import FileOperations as fo
from configs import ManagementConsole as mcapi
from libs import commons
import json
from libs import API_responseValidation as api_validation
from libs.ManagementConsole import MC_APIsDataProvider as mc_dp
from libs.ManagementConsole import MC_APIsResponseValidation as mc_validator


class Test_ModulesAPI:

    createModuleData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_Module_JSON, "CREATE")
    updateModuleData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_Module_JSON, "update")
    @pytest.fixture(scope='class')
    def collectModuleId_existing(self):
        return []

    @pytest.fixture(scope='class')
    def collectModuleId_new(self):
        return []

    def test_getModules(self, record_property, collectModuleId_existing, init_env, initialize_request):
        report_data = {"JIRA_ID": "EETK-9308",
                       "Short_Desc": "Validate the user is able to fetch Modules data using getModule api",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")

        res = initialize_request.get(url=init_env + mcapi.ModuleEndPoint)
        # print(str(res.status_code) + str(res.json()))
        assert res.status_code == 200
        assert len(res.json()) > 0
        for i in range (0,10):
            collectModuleId_existing.append(res.json()[i]['id'])



    def test_get_module_by_id(self, record_property, collectModuleId_existing, init_env, initialize_request):
        report_data = {"JIRA_ID": "EETK-9309",
                       "Short_Desc": "Validate the user is able to fetch specific Module data using getModuleById api",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        module_id = str(collectModuleId_existing.pop())
        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        res = initialize_request.get(url=hosturl, verify=False)

        assert res.status_code == 200
        assert res.json()['id'] == module_id

    def test_get_module_by_invalid_id(self, record_property, collectModuleId_existing, init_env, initialize_request,fetch_dependent_ids):
        report_data = {"JIRA_ID": "EETK-7778,EETK-11167",
                       "Short_Desc": "Validate ModulesGetByID api by passing invalid Modules id,Validate error message in response while running getModuleById API with invalid Module ID",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        hosturl = init_env + mcapi.ModuleEndPoint + fetch_dependent_ids["osIds"][0] + "/"
        res = initialize_request.get(url=hosturl, verify=False)

        assert res.status_code == 400
        assert res.json()["errors"][0]['message'] == "Module 5e81c3132ed228002ae08bc7 not found!"
        if "Module " + fetch_dependent_ids["osIds"][0] + " not found!" not in str(res.json()):
            pytest.fail("Error message is not correct. " + str(res.json()))

    @pytest.mark.parametrize("TestData", createModuleData)
    def test_create_modules(self, TestData, record_property, init_env, initialize_request, collectModuleId_new,
                            fetch_dependent_ids):

        commons.set_Record_Property(record_property, TestData, "API", "No Browser")

        payload = json.loads(TestData["request_payload"])
        payload = mc_dp.update_name_and_version_in_payload(payload)
        payload = mc_dp.update_module_dependent_values(payload, fetch_dependent_ids)
        res = initialize_request.post(init_env + mcapi.ModuleEndPoint, json=payload)

        if TestData["response_code"] == 200:
            assert res.status_code == 200, res.json()
            collectModuleId_new.append(res.json()['id'])
            mc_validator.validate_module_response_json(res.json(), payload)
        else:
            assert res.status_code == TestData["response_code"]

        mc_validator.validate_mc_api_response_data(res.status_code, res.json(), TestData["expected_message_code"],
                                                   TestData["expected_message"])
        mc_validator.validate_json_schema(res.json(), "CreateModule")


    def test_create_module_with_existing_name(self, record_property, init_env, initialize_request, collectModuleId_new,
                                              fetch_module_request_json):

        name = "Auto_existing" + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-7786",
                   "Short_Desc": "Validate creating already existing Modules with API",
                   "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")

        fetch_module_request_json["name"]["en"] = name
        fetch_module_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        res = initialize_request.post(init_env + mcapi.ModuleEndPoint, json=fetch_module_request_json)
        assert res.status_code == 200
        res = initialize_request.post(init_env + mcapi.ModuleEndPoint, json=fetch_module_request_json)
        assert res.status_code == 400
        mc_validator.validate_mc_api_response_data(res.status_code, res.json(), "IngredientXAlreadyExists",
                                                   "Module Already Exists with id")


    def test_create_module_with_dependent_module(self, record_property, init_env, initialize_request,
                                                 collectModuleId_new, fetch_module_request_json):

        report_data = {"JIRA_ID": "EETK-7818",
                       "Short_Desc": "Validate creating a module by adding dependent module"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        module_id = str(collectModuleId_new.pop())
        fetch_module_request_json["dependencies"] = [module_id]
        fetch_module_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        res = initialize_request.post(init_env + mcapi.ModuleEndPoint, json=fetch_module_request_json)
        assert res.status_code == 200
        hosturl = init_env + mcapi.ModuleEndPoint + res.json()["id"]
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.json()["dependencies"][0] == module_id


    def test_create_module_with_multiple_versions(self, record_property, init_env, initialize_request,
                                                  collectModuleId_new, fetch_module_request_json):
        name = "Auto_Multi_" + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-EETK-7777, EETK-7796, EETK-8460",
                       "Short_Desc": "Create different version of Modules and validate if API is fetching all the details of Modules, Validate creating multiple version of a Modules by giving version no. in version using post api",
                       "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")

        fetch_module_request_json["name"]["en"] = name
        fetch_module_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        res1 = initialize_request.post(init_env + mcapi.ModuleEndPoint, json=fetch_module_request_json)
        assert res1.status_code == 200
        fetch_module_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        res2 = initialize_request.post(init_env + mcapi.ModuleEndPoint, json=fetch_module_request_json)
        assert res2.status_code == 200

        get_module1 = initialize_request.get(url=init_env + mcapi.ModuleEndPoint + res1.json()["id"] + "/", verify=False)
        get_module2 = initialize_request.get(url=init_env + mcapi.ModuleEndPoint + res2.json()["id"] + "/", verify=False)
        assert get_module1.json()["name"]["en"] == get_module2.json()["name"]["en"]
        assert get_module1.json()["fullJenkinsPath"] == get_module2.json()["fullJenkinsPath"]


    @pytest.mark.parametrize("TestData", updateModuleData)
    def test_updateModule(self, TestData, record_property, collectModuleId_new, init_env, initialize_request, fetch_dependent_ids):
        commons.set_Record_Property(
            record_property, TestData, "API", "No Browser")
        payload = json.loads(TestData["request_payload"])
        updated_param=TestData["updated_param"]
        if(TestData["UUID"] != ""):
            UUID = TestData["UUID"]
        else:
            UUID=collectModuleId_new[0]
        getHostUrl = init_env + mcapi.ModuleEndPoint + UUID + '/'
        getRes = requests.get(url=getHostUrl, verify=False)

        payload["name"]["en"] = getRes.json()["name"]["en"]
        if (payload["version"] == "blank"):
            payload["version"] = getRes.json()["version"]

        hosturl = init_env + mcapi.ModuleEndPoint + UUID + "/"
        res = requests.put(url=hosturl, json=payload, verify=False)
        data=res.json()
        if TestData["response_code"] == 200:
            assert res.status_code == 200, print(str(res.json())+str(payload))
            mc_validator.validate_module_response_json(
                res.json(), payload)
            assert payload[updated_param]==data["data"][updated_param]
        else:
            if TestData["expected_message_code"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["messageCode"],TestData["expected_message_code"])
            if TestData["expected_message"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["message"],TestData["expected_message"])
        assert res.status_code==TestData['response_code']

    def test_update_module_with_valid_data(self, record_property, init_env, initialize_request, collectModuleId_new, fetch_module_request_json, fetch_dependent_ids):

        report_data = {"JIRA_ID": "EETK-8200",
                       "Short_Desc": "Validate Jenkins job after updating module"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        module_id = collectModuleId_new[0]
        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.status_code == 200, str(res.json())
        mc_dp.update_module_dependent_values(fetch_module_request_json, fetch_dependent_ids)
        fetch_module_request_json["name"]["en"] = res.json()["name"]["en"]
        fetch_module_request_json["version"] = res.json()["version"]
        #Updated needs to be done for modules
        fetch_module_request_json["description"]["en"] = "Updated Description"
        fetch_module_request_json["displayName"]["en"] = "Updated displayName"
        fetch_module_request_json["moreInfo"]["en"] = "Updated moreInfo"
        # fetch_module_request_json["releaseTag"] = "Updated New tag"
        update = initialize_request.put(init_env + mcapi.ModuleEndPoint + module_id + "/", json=fetch_module_request_json)
        assert update.status_code == 200, str(update.json())
        assert update.json()["data"]["description"]["en"] == "Updated Description"
        assert update.json()["data"]["displayName"]["en"] == "Updated displayName"
        assert update.json()["data"]["moreInfo"]["en"] == "Updated moreInfo"
        assert update.json()["data"]["fullJenkinsPath"] == res.json()["fullJenkinsPath"]


    def test_update_module_name(self, record_property, init_env, initialize_request, collectModuleId_new, fetch_module_request_json, fetch_dependent_ids):
        report_data = {"JIRA_ID": "EETK-7820",
                       "Short_Desc": "Validate updating module name by using UpdateModuleAPI"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        module_id = collectModuleId_new[0]
        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        res = initialize_request.get(url=hosturl, verify=False)
        assert  res.status_code == 200
        mc_dp.update_module_dependent_values(fetch_module_request_json, fetch_dependent_ids)
        fetch_module_request_json["name"]["en"] = "Update Name"
        fetch_module_request_json["version"] = res.json()["version"]
        #Updated needs to be done for modules
        fetch_module_request_json["description"]["en"] = "Updated Description"

        update = initialize_request.put(init_env + mcapi.ModuleEndPoint + module_id + "/", json=fetch_module_request_json)
        assert update.status_code == 400
        if "Module name cannot be updated." not in str(update.json()):
            pytest.fail("Error message is not correct. " + str(update.json()) )


    

    def test_update_existing_module(self, record_property, init_env, initialize_request, collectModuleId_existing, fetch_module_request_json, fetch_dependent_ids):

        report_data = {"JIRA_ID": "EETK-7779",
                       "Short_Desc": "Update existing Modules in MC and validate API is fetching with latest details"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        module_id = collectModuleId_existing[2]
        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        res = initialize_request.get(url=hosturl, verify=False)
        assert  res.status_code == 200, str(res.json())
        mc_dp.update_module_dependent_values(fetch_module_request_json, fetch_dependent_ids)
        fetch_module_request_json["name"]["en"] = res.json()["name"]["en"]
        fetch_module_request_json["version"] = res.json()["version"]
        mc_dp.update_module_dependent_values(fetch_module_request_json, fetch_dependent_ids)
        #Updated needs to be done for modules
        fetch_module_request_json["osIds"] = fetch_dependent_ids["updatedosIds"]
        update = initialize_request.put(init_env + mcapi.ModuleEndPoint + module_id + "/", json=fetch_module_request_json)
        assert update.status_code == 200, print(update.json())


    def test_delete_dependent_modules(self, record_property, init_env, initialize_request, collectModuleId_new, fetch_module_request_json):

        report_data = {"JIRA_ID": "EETK-9394,EETK-7826,EETK-7982",
                       "Short_Desc": "Validate deleting module used as dependency in another module,Create two modules, create dependency and validate Modules deletion with API, Validate deleting module with dependency using deleteModule API"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        module_id = "63511b2575c5efa74035e9db"
        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        value = {"user": "eshautomate"}
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 424 , print(res.json())


    def test_delete_module_with_valid_user(self, record_property, init_env, initialize_request, collectModuleId_new):

        report_data = {"JIRA_ID": "EETK-7976,EETK-7785, EETK-7781",
                       "Short_Desc": "Validate if module is deleted using deleteModule API,"
                                     "Validate deleting already deleted Modules with API, "
                                     "Create Modules and validate its deletion"}
        
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        hosturl = init_env + mcapi.ModuleEndPoint + "INVALID" + "/"
        value = {"user": "eshautomate"}
        res = initialize_request.delete(hosturl, params=value)
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        module_id = str(collectModuleId_new.pop())
        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        value = {"user": "eshautomate"}
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 200
        # Try to delete again
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 400

        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        res = initialize_request.get(url=hosturl)
        assert res.status_code == 400
        assert res.json()["errors"][0]["code"] == 404

    def test_delete_module_with_invalid_user(self, record_property, init_env, initialize_request, collectModuleId_new):

        report_data = {"JIRA_ID": "EETK-7784",
                       "Short_Desc": "Validate Modules deletion by giving invalid idsid in 'user' field",
                       "Data": "invaliduser"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")

        module_id = str(collectModuleId_new.pop())
        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        value = {"user": "invaliduser"}
        res = initialize_request.delete(hosturl, params=value)

        assert res.status_code == 400
        assert res.json()["errors"][0]["code"] == 400
        assert res.json()["errors"][0]["param"] == "user"
        assert res.json()["errors"][0]["message"] == "'invaliduser' is not a valid username"

    def test_delete_module_without_user(self, record_property, init_env, initialize_request, collectModuleId_new):

        report_data = {"JIRA_ID": "EETK-11208",
                       "Short_Desc": "Validate Modules deletion by not giving idsid,Validate module deletion without passing module id ",
                       "Data": "invaliduser"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")

        module_id = str(collectModuleId_new.pop())
        hosturl = init_env + mcapi.ModuleEndPoint + module_id + "/"
        # value={"user":"invaliduser"}
        res = initialize_request.delete(hosturl)

        assert res.status_code == 400
        if "UsernameMandatory" not in str(res.json()):
            pytest.fail("Message Code is not correct or present")
        if "User IDSID Mandatory to provide" not in str(res.json()):
            pytest.fail("Message is not correct or present")
