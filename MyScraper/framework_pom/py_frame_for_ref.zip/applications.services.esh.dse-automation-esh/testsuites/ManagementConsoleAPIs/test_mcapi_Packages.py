import json
import pytest
import utils
from configs import ManagementConsole as mcapi
from utils.FileOperations import File_Operations as fo
from libs.ManagementConsole import MC_APIsDataProvider as mc_dp
from libs.ManagementConsole import MC_APIsResponseValidation as mc_validator
from libs import commons


class Test_PackagesAPI:

    @pytest.fixture(scope='class')
    def collect_packages_id_existing(self):
        return []

    @pytest.fixture(scope='class')
    def collect_packages_id_new(self):
        return []

    @pytest.fixture(scope='class')
    def collect_packages_id_od(self):
        return []

    def test_get_packages(self, record_property, collect_packages_id_existing, init_env, initialize_request):
        report_data = {"JIRA_ID": "EETK-7170",
                       "Short_Desc": "Validate if API is fetching the list of all recipes in MC",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")

        res = initialize_request.get(url=init_env + mcapi.PackageEndPoint)
        collect_packages_id_existing.append(res.json()[0]['id'])
        collect_packages_id_existing.append(res.json()[1]['id'])
        collect_packages_id_existing.append(res.json()[2]['id'])
        assert res.status_code == 200
        assert len(res.json()) > 0

    def test_get_package_by_id(self, record_property, collect_packages_id_existing, init_env, initialize_request):
        report_data = {"JIRA_ID": "EETK-9732",
                       "Short_Desc": "Validate the user is able to fetch specific Package data using getRecipeById api",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        package_id = str(collect_packages_id_existing.pop())
        hosturl = init_env + mcapi.PackageEndPoint + package_id
        res = initialize_request.get(url=hosturl, verify=False)

        assert res.status_code == 200
        assert res.json()['id'] == package_id

    def test_get_package_by_invalid_id(self, record_property, init_env, initialize_request, fetch_dependent_ids):
        report_data = {"JIRA_ID": "EETK-7174",
                       "Short_Desc": "Validate getRecipeById api by passing invalid id",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        hosturl = init_env + mcapi.PackageEndPoint + fetch_dependent_ids["osIds"][0]
        res = initialize_request.get(url=hosturl, verify=False)

        assert res.status_code == 400
        assert res.json()["errors"][0]["message"] == "Recipe " + fetch_dependent_ids["osIds"][0] + " not found!"


    # @pytest.mark.skip
    @pytest.mark.parametrize("TestData", fo().get_json_file_filtered_data(mcapi.file_path_create_Packages_JSON, "CREATE"))
    def test_create_packages(self, TestData, record_property, init_env, initialize_request, collect_packages_id_new,
                             fetch_dependent_ids):

        commons.set_Record_Property(record_property, TestData, "API", "No Browser")

        payload = json.loads(TestData["request_payload"])
        payload = mc_dp.update_package_final_payload(initialize_request, init_env, payload, TestData["Dependencies"], fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        if TestData["response_code"] == 201:
            assert res.status_code == 201, res.json()
            collect_packages_id_new.append(res.json()['id'])
            # mc_validator.validate_module_response_json(res.json(), payload)
        else:
            print(res.json())
            if TestData["expected_message_code"] != "":
                mc_validator.validateJSONFieldData(res.json()["errors"][0]["messageCode"],
                                                     TestData["expected_message_code"])
                mc_validator.validateJSONFieldData(res.json()["errors"][0]["message"], TestData["expected_message"])
                assert res.status_code == TestData['response_code']
            else:
                assert res.status_code == TestData["response_code"]
                mc_validator.validate_mc_api_response_data(res.status_code, res.json(),
                                                           TestData["expected_response_code"],
                                                           TestData["expected_message"])


    # @pytest.mark.skip
    def test_create_package_with_existing_details(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                                  fetch_dependent_ids, fetch_package_request_json):
        """

        :param record_property:
        :param init_env:
        :param initialize_request:
        :param collect_packages_id_new:
        :param fetch_dependent_ids:
        :param fetch_package_request_json:
        :return:
        """
        report_data = {"JIRA_ID": "EETK-7213, EETK-7198",
                       "Short_Desc": "Validate creating Package with API by giving UI route/name/IRC id which is already used",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "GET"}, fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 201
        # Validate with Existing Name
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 400
        mc_validator.validate_mc_api_response_data(res.status_code, res.json(),"recipeXAlreadyExists",
                                                       "Recipe Already Exists with id")
        # Validate with Existing uiRoute
        uniquestr = utils.common.get_Current_TimeStamp()
        uniquestr = uniquestr[4:14]
        payload["name"]["en"] = str(payload["name"]["en"]) + str(uniquestr)
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        print(res.json())
        assert res.status_code == 400
        mc_validator.validate_mc_api_response_data(res.status_code, res.json(),"uiRouteAlreadyExists",
                                                   "uiRoute Already Exists")
        # Validate with Existing Product IRC
        payload["uiRoute"] = str(payload["uiRoute"]) + str(uniquestr)
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 400
        mc_validator.validate_mc_api_response_data(res.status_code, res.json(),"IRCAlreadyExists",
                                                   "Product IRC Already Exists!")

    # @pytest.mark.skip
    def test_verify_package_jenkins_url(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                                  fetch_dependent_ids, fetch_package_request_json):
        """

        :param record_property:
        :param init_env:
        :param initialize_request:
        :param collect_packages_id_new:
        :param fetch_dependent_ids:
        :param fetch_package_request_json:
        :return:
        """
        report_data = {"JIRA_ID": "EETK-8464, EETK-7172,EETK-7175",
                       "Short_Desc": "Create new Package in MC via API and validate Jenkins path, Create a Package in MC and validate if API is fetching all the details of package",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "GET"}, fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)

        assert res.status_code == 201
        hosturl = init_env + mcapi.PackageEndPoint + res.json()["id"] + "/"
        gerres = initialize_request.get(url=hosturl, verify=False)

        assert gerres.json()["jenkinsLink"] == "https://cje-ba-prod01.devtools.intel.com/iotg-dse-rbac/job/ESH-MC/job/QA/job/Packages/job/" + payload["name"]["en"]
        assert gerres.json()["defaultOs"] == payload["defaultOs"]
        assert gerres.json()["defaultHw"] == payload["defaultHw"]
        assert gerres.json()["fullGitlabPath"] == payload["fullGitlabPath"]
        assert gerres.json()["installationOrder"] == payload["installationOrder"]

    # @pytest.mark.skip
    @pytest.mark.parametrize("TestData", fo().get_json_file_filtered_data(mcapi.file_path_create_Packages_JSON, "UPDATE"))
    def test_update_package(self,TestData, record_property, init_env, initialize_request, collect_packages_id_new,
                            fetch_dependent_ids):
        """

        :param TestData:
        :param record_property:
        :param init_env:
        :param initialize_request:
        :param collect_packages_id_new:
        :param fetch_dependent_ids:
        :return:
        """

        commons.set_Record_Property(record_property, TestData, "API", "No Browser")
        payload = json.loads(TestData["master_payload"])
        payload = mc_dp.update_package_final_payload(initialize_request, init_env, payload, TestData["Dependencies"], fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 201, res.json()
        uniquestr = str(utils.common.get_Current_TimeStamp()[4:14])
        if list(TestData["request_payload"].keys())[0] in [ "version", "uiRoute"]:
            key = list(TestData["request_payload"].keys())[0]
            TestData["request_payload"][key] = str(TestData["request_payload"][key]) + uniquestr
            payload.update(TestData["request_payload"])
        elif(list(TestData["request_payload"].keys())[0] == "ircProductId"):
             payload = mc_dp.update_ircproductid_in_payload(payload)
        elif (list(TestData["request_payload"].keys())[0] == "name"):
             TestData["request_payload"]["name"]["en"] = str(TestData["request_payload"]["name"]["en"]) + uniquestr
             payload.update(TestData["request_payload"])
        elif(list(TestData["request_payload"].keys())[0] == "fullGitlabPath"):
             TestData["request_payload"]["fullGitlabPath"] = str(TestData["request_payload"]["fullGitlabPath"])
             payload.update(TestData["request_payload"])
        update = initialize_request.put(init_env +mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload,timeout=180)
        assert update.status_code == TestData["response_code"]
        mc_validator.validate_mc_api_response_data(res.status_code, update.json(), TestData["expected_message_code"],
                                                   TestData["expected_message"])

    # @pytest.mark.skip
    def test_update_module_for_package(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                fetch_dependent_ids, fetch_package_request_json):

        report_data = {"JIRA_ID": "EETK-7104,EETK-9773,EETK-9774",
                       "Short_Desc": "Validate updating 'Modules' of an existing package,"
                                     "Validate updating 'Modules' of an existing package without updating "
                                     "DisplayOrder and installation order, Validate updating 'Modules' of an existing "
                                     "package without updating is recommended ",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")

        payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "CREATE"}, fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 201

        moduleid = mc_dp.create_module_for_package(initialize_request,init_env, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "GET"}, fetch_dependent_ids)
        payload["ingredients"] = moduleid
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 400
        mc_validator.validate_mc_api_response_data(res.status_code, update.json(), "invalidValue","Invalid Value")
        mc_dp.update_display_order_for_packages(payload)
        mc_dp.update_installation_order_for_packages(payload)
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 400
        mc_validator.validate_mc_api_response_data(res.status_code, update.json(), "isRecommended","id is not selected in ingredients/helmcharts/containers")
        payload = mc_dp.update_is_recommended_for_packages(payload)
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 200


    # @pytest.mark.skip
    def test_update_container_for_package(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                       fetch_dependent_ids, fetch_package_request_json):

        report_data = {"JIRA_ID": "EETK-7103",
                       "Short_Desc": "Validate updating 'Containers' of an existing package",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")

        payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json,{"Module": 1, "Container": 1, "HemlChart": 1, "action": "CREATE"}, fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 201, res.json()

        containerid = mc_dp.create_container_for_package(initialize_request,init_env, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "GET"}, fetch_dependent_ids)
        payload["containerIds"] = containerid
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 400, update.json()
        mc_validator.validate_mc_api_response_data(res.status_code, update.json(), "invalidValue","Invalid Value")
        mc_dp.update_display_order_for_packages(payload)
        mc_dp.update_installation_order_for_packages(payload)
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 400, update.json()
        mc_validator.validate_mc_api_response_data(res.status_code, update.json(), "isRecommended","id is not selected in ingredients/helmcharts/containers")
        payload = mc_dp.update_is_recommended_for_packages(payload)
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 200, update.json()


    # @pytest.mark.skip
    def test_update_helmchart_for_package(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                              fetch_dependent_ids, fetch_package_request_json):

        report_data = {"JIRA_ID": "EETK-7103",
                       "Short_Desc": "Validate updating 'Helmchat' of an existing package",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")

        payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "CREATE"}, fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 201, res.json()

        helmchartid = mc_dp.create_helmchart_for_package(initialize_request,init_env, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "GET"}, fetch_dependent_ids)
        payload["helmchartIds"] = helmchartid
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 400, update.json()
        mc_validator.validate_mc_api_response_data(res.status_code, update.json(), "invalidValue","Invalid Value")
        mc_dp.update_package_payload_for_display_installation_order(payload, "helmcharts", helmchartid)
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 400, update.json()
        mc_validator.validate_mc_api_response_data(res.status_code, update.json(), "isRecommended","id is not selected in ingredients/helmcharts/containers")
        payload = mc_dp.update_is_recommended_for_packages(payload)
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 200, update.json()

    def test_update_os_hw_ids_for_package(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                          fetch_dependent_ids, fetch_package_request_json):

        report_data = {"JIRA_ID": "EETK-7101, EETK-7097",
                       "Short_Desc": "Validate updating 'Compatible OS' &  'Default Hardware' of an existing package",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "CREATE"}, fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 201, res.json()
        payload["osIds"] = fetch_dependent_ids["updatedosIds"]
        payload = mc_dp.update_default_os_hwids(payload, fetch_dependent_ids["updatedosIds"])
        update = initialize_request.put(init_env +mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 200, update.json()
        payload["hwIds"] = fetch_dependent_ids["updatedhwIds"]
        payload = mc_dp.update_default_os_hwids(payload,fetch_dependent_ids["updatedhwIds"])
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 200, update.json()
        payload["resourceIds"] = fetch_dependent_ids["updatedresourceIds"]
        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
        assert update.status_code == 200, update.json()

    # @pytest.mark.skip
    def test_delete_package(self,record_property, init_env, initialize_request, collect_packages_id_new,fetch_dependent_ids ):
        report_data = {"JIRA_ID": "EETK-7176, EETK-7180, EETK-7977, EETK-7177",
                       "Short_Desc": "Create a Package and validate its deletion with API,"
                                     "Validate deleting already deleted Recipe with API, "
                                     "Validate if package is delete using deleteRecipe API,"
                                     "Validate Recipe deletion with API by giving invalid recipe ID"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        package_id = str(collect_packages_id_new.pop())
        hosturl = init_env + mcapi.PackageEndPoint + package_id + "/"
        value = {"user": "eshautomate"}
        res = initialize_request.delete(hosturl, params=value)
        print(res.json())
        assert res.status_code == 200, res.json()
        # Try to delete again
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 400, res.json()
        hosturl = init_env + mcapi.PackageEndPoint + fetch_dependent_ids["ingredientType"] + "/"
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 400, res.json()

    # @pytest.mark.skip
    def test_delete_package_with_invalid_user(self,record_property, init_env, initialize_request, collect_packages_id_new ):


        report_data = {"JIRA_ID": "EETK-7179",
                       "Short_Desc": "Validate Recipe deletion by giving invalid idsid in 'user' field"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        package_id = str(collect_packages_id_new.pop())
        hosturl = init_env + mcapi.PackageEndPoint + package_id + "/"
        value = {"user": "invalid"}
        res = initialize_request.delete(hosturl, params=value)
        print(res.json())
        assert res.status_code == 400, res.json()
        assert res.json()["errors"][0]["code"] == 400
        assert res.json()["errors"][0]["param"] == "user"
        assert res.json()["errors"][0]["message"] == "'invalid' is not a valid username"

    # @pytest.mark.skip
    def test_delete_package_without_user(self,record_property, init_env, initialize_request, collect_packages_id_new ):


        report_data = {"JIRA_ID": "EETK-7179",
                       "Short_Desc": "Validate Recipe deletion by giving invalid idsid in 'user' field"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        package_id = str(collect_packages_id_new.pop())
        hosturl = init_env + mcapi.PackageEndPoint + package_id + "/"
        # value = {"user": ""}
        res = initialize_request.delete(hosturl)
        assert res.status_code == 400, res.json()
        if "usernameMandatory" not in str(res.json()):
            print(res.json())
            pytest.fail("Message Code is not correct or present")
        if "Please provide idsid of the user" not in str(res.json()):
            print(res.json())
            pytest.fail("Message is not correct or present")


    # @pytest.mark.skip
    def test_delete_dependent_module_helm_container_for_package(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                                  fetch_dependent_ids, fetch_package_request_json):
        report_data = {"JIRA_ID": "EETK-7024,EETK-7904,EETK-7782,EETK-8258",
                       "Short_Desc": "Create container, create a package with this container and validate container deletion with API, "
                                     "Create HelmCHart, create a package with this HelmChart and validate HelmChart deletion with API, "
                                     "Create Modules, create a package with this Modules and validate Modules deletion with API",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json, {"Module": 1, "Container": 1, "HemlChart": 1, "action": "CREATE"}, fetch_dependent_ids )
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 201, res.json()
        value = {"user": "eshautomate"}
        hosturl = init_env + mcapi.ModuleEndPoint + payload["ingredients"][0] + "/"
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 424, res.json()
        hosturl = init_env + mcapi.ContainerEndPoint + payload["containerIds"][0] + "/"
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 424, res.json()
        hosturl = init_env + mcapi.HelmChartEndPoint + payload["helmchartIds"][0] + "/"
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 424, res.json()


    # @pytest.mark.skip
    @pytest.mark.parametrize("TestData", fo().get_json_file_filtered_data(mcapi.file_path_create_Packages_OD_JSON, "CREATE"))
    def test_create_packages_for_online_distribution(self, TestData, record_property, init_env, initialize_request, collect_packages_id_od,
                             fetch_dependent_ids, get_online_distribution_recipe_type_id):
        """

        :param TestData:
        :param record_property:
        :param init_env:
        :param initialize_request:
        :param collect_packages_id_od:
        :param fetch_dependent_ids:
        :param get_online_distribution_recipe_type_id:
        :return:
        """

        commons.set_Record_Property(record_property, TestData, "API", "No Browser")

        payload = json.loads(TestData["request_payload"])
        payload = mc_dp.update_name_and_version_in_payload(payload)
        payload = mc_dp.update_uiroute_and_ircproductid_in_payload(payload)
        payload = mc_dp.update_filtertag_in_payload_for_container(payload, fetch_dependent_ids)
        dependencies = TestData["Dependencies"]

        if dependencies["OnlineDistribution"] >= 1 and dependencies["action"] == "CREATE":
            odids = mc_dp.create_online_distribution(initialize_request, init_env, dependencies, fetch_dependent_ids)
        elif dependencies["OnlineDistribution"] >= 1 and dependencies["action"] == "GET":
            odids = mc_dp.get_online_distribution(initialize_request, init_env, dependencies)
        else:
            odids = []

        payload["distributionIds"] = odids
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        if TestData["response_code"] == 201:
            assert res.status_code == 201, res.json()
            collect_packages_id_od.append(res.json()['id'])
        else:
            print(res.json())
            if TestData["expected_message_code"] != "":
                mc_validator.validateJSONFieldData(res.json()["errors"][0]["messageCode"],
                                                   TestData["expected_message_code"])
                mc_validator.validateJSONFieldData(res.json()["errors"][0]["message"], TestData["expected_message"])
                assert res.status_code == TestData['response_code']
            else:
                assert res.status_code == TestData["response_code"]
                mc_validator.validate_mc_api_response_data(res.status_code, res.json(),
                                                           TestData["expected_response_code"],
                                                           TestData["expected_message"])


    # @pytest.mark.skip
    def test_create_packages_for_online_distribution_existing_details(self, record_property, init_env, initialize_request, collect_packages_id_od,
                                                     fetch_dependent_ids, get_online_distribution_recipe_type_id, fetch_od_package_request_json):

        report_data = {"JIRA_ID": "EETK-7261, EETK-7263",
                       "Short_Desc": "Validate creating Package with API by giving UI route/name/IRC id which is already used",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")

        # payload = json.loads(TestData["request_payload"])
        payload = mc_dp.update_name_and_version_in_payload(fetch_od_package_request_json)
        payload = mc_dp.update_uiroute_and_ircproductid_in_payload(payload)
        payload = mc_dp.update_filtertag_in_payload_for_container(payload, fetch_dependent_ids)
        dependencies = {"OnlineDistribution": 1, "action": "GET"}

        if dependencies["OnlineDistribution"] >= 1 and dependencies["action"] == "CREATE":
            odids = mc_dp.create_online_distribution(initialize_request, init_env, dependencies, fetch_dependent_ids)
        elif dependencies["OnlineDistribution"] >= 1 and dependencies["action"] == "GET":
            odids = mc_dp.get_online_distribution(initialize_request, init_env, dependencies)
        else:
            odids = []

        payload["distributionIds"] = odids
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 201, res.json()
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 400, res.json()

        mc_validator.validate_mc_api_response_data(res.status_code, res.json(),"recipeXAlreadyExists",
                                                       "Recipe Already Exists with id")
        uniquestr = utils.common.get_Current_TimeStamp()
        uniquestr = uniquestr[4:14]
        payload["name"]["en"] = str(payload["name"]["en"]) + str(uniquestr)
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        print(res.json())
        assert res.status_code == 400, res.json()
        mc_validator.validate_mc_api_response_data(res.status_code, res.json(),"uiRouteAlreadyExists",
                                                   "uiRoute Already Exists")
        payload["uiRoute"] = str(payload["uiRoute"]) + str(uniquestr)
        res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
        assert res.status_code == 400, res.json()
        mc_validator.validate_mc_api_response_data(res.status_code, res.json(),"IRCAlreadyExists",
                                                   "Product IRC Already Exists!")



    @pytest.mark.parametrize("TestData", fo().get_json_file_filtered_data(mcapi.file_path_create_Packages_OD_JSON, "UPDATE"))
    def test_update_package_online_distribution(self,TestData, record_property, init_env, initialize_request, collect_packages_id_od,
                            fetch_dependent_ids, fetch_od_package_request_json):
        """
        :param TestData:
        :param record_property:
        :param init_env:
        :param initialize_request:
        :param collect_packages_id_new:
        :param fetch_dependent_ids:
        :return:
        """
        commons.set_Record_Property(record_property, TestData, "API", "No Browser")

        packageid = collect_packages_id_od[0]
        # packageid = "62f4bf0e5c5701002074c2a2"
        res = initialize_request.get(url=init_env + mcapi.PackageEndPoint + packageid + "/")
        fetch_od_package_request_json["name"]["en"] = res.json()["name"]["en"]
        fetch_od_package_request_json["version"] = res.json()["version"]
        fetch_od_package_request_json["uiRoute"] = res.json()["uiRoute"]
        fetch_od_package_request_json["ircProductId"] = res.json()["ircProductId"]
        uniquestr = str(utils.common.get_Current_TimeStamp()[4:14])
        if list(TestData["request_payload"].keys())[0] in ["version", "uiRoute"]:
            key = list(TestData["request_payload"].keys())[0]
            TestData["request_payload"][key] = str(TestData["request_payload"][key]) + uniquestr
            fetch_od_package_request_json.update(TestData["request_payload"])

        elif (list(TestData["request_payload"].keys())[0] == "ircProductId"):
            fetch_od_package_request_json = mc_dp.update_ircproductid_in_payload(fetch_od_package_request_json)

        elif (list(TestData["request_payload"].keys())[0] == "name"):
            TestData["request_payload"]["name"]["en"] = str(TestData["request_payload"]["name"]["en"]) + uniquestr
            fetch_od_package_request_json.update(TestData["request_payload"])

        update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=fetch_od_package_request_json,timeout=180)
        assert update.status_code == TestData["response_code"], print(update.json())

        if TestData["response_code"] == 200:
            assert update.status_code == 200, update.json()

        else:
            if TestData["expected_message_code"] != "":
                mc_validator.validateJSONFieldData(update.json()["errors"][0]["messageCode"],
                                                   TestData["expected_message_code"])
                mc_validator.validateJSONFieldData(update.json()["errors"][0]["message"], TestData["expected_message"])
                assert update.status_code == TestData['response_code']
            else:
                assert update.status_code == TestData["response_code"]
                mc_validator.validate_mc_api_response_data(update.status_code, update.json(),
                                                           TestData["expected_response_code"],
                                                           TestData["expected_message"])


    def test_delete_package_online_distribution(self,record_property, init_env, initialize_request, collect_packages_id_od,fetch_dependent_ids ):

        report_data = {"JIRA_ID": "EETK-7468",
                       "Short_Desc": "Create Online Distribution, create a package with this Online Distribution and Validate its deletion using API"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        package_id = str(collect_packages_id_od.pop())
        hosturl = init_env + mcapi.PackageEndPoint + package_id + "/"
        value = {"user": "eshautomate"}
        res = initialize_request.delete(hosturl, params=value)
        print(res.json())
        assert res.status_code == 200, res.json()
        # Try to delete again
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 400, res.json()

    def test_package_with_multiple_versions(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                 fetch_dependent_ids, fetch_package_request_json):

        name = "Auto_Multi_" + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-8465, EETK-7173, EETK-7171, EETK-7183",
                       "Short_Desc": "Create different version of Package and validate if API is fetching all the details of Package, "
                                     "Create another version of an existing Package in MC via API and validate Jenkins path"
                                     "Create multiple versions of a package and validate if API is fetching the list of all recipes and its versions in MC"
                                     "Create two versions of a package and validate if API is deleting first created version of package",
                       "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")
        payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json,
                                                     {"Module": 1, "Container": 1, "HemlChart": 1, "action": "GET"},
                                                     fetch_dependent_ids)

        fetch_package_request_json["name"]["en"] = name
        fetch_package_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])

        res1 = initialize_request.post(init_env + mcapi.PackageEndPoint, json=fetch_package_request_json)
        assert res1.status_code == 201
        fetch_package_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        res2 = initialize_request.post(init_env + mcapi.PackageEndPoint, json=fetch_package_request_json)
        assert res2.status_code == 201

        get_package1 = initialize_request.get(url=init_env + mcapi.PackageEndPoint + res1.json()["id"] + "/", verify=False)
        get_package2 = initialize_request.get(url=init_env + mcapi.PackageEndPoint + res2.json()["id"] + "/", verify=False)
        assert get_package1.json()["name"]["en"] == get_package2.json()["name"]["en"]
        assert get_package1.json()["fullJenkinsPath"] == get_package2.json()["fullJenkinsPath"]
        assert get_package1.json()["version"] != get_package2.json()["version"]

        #validate deleting first package
        hosturl = init_env + mcapi.PackageEndPoint + res1.json()["id"] + "/"
        value = {"user": "eshautomate"}
        res = initialize_request.delete(hosturl, params=value)
        assert res.status_code == 200, res.json()

    def test_create_recipeType_for_package(self, record_property, init_env, initialize_request, collect_packages_id_new,
                                           fetch_dependent_ids, fetch_package_request_json):
            report_data = {"JIRA_ID": "EETK-7088,EETK-7166",
                           "Short_Desc": "Validate updating 'Package Class' of an existing package,"
                                         "Create RecipeType, create a package with this RecipeType and validate RecipeType deletion with API",
                           "Data": ""}
            commons.set_Record_Property(record_property, report_data, "API")
            payload = mc_dp.update_package_final_payload(initialize_request, init_env, fetch_package_request_json,
                                                         {"Module": 1, "Container": 0, "HemlChart": 0,
                                                          "action": "CREATE"}, fetch_dependent_ids)
            res = initialize_request.post(init_env + mcapi.PackageEndPoint, json=payload)
            assert res.status_code == 201

            recipeTypeid = mc_dp.create_recipeType_for_package(initialize_request, init_env)
            payload["recipeType"] = recipeTypeid
            update = initialize_request.put(init_env + mcapi.PackageEndPoint + res.json()["id"] + "/", json=payload)
            assert update.status_code == 200

            #validate deleting recipeType for package
            hosturl = init_env + "/recipe/recipeType/"+str(recipeTypeid)
            value = {"user": "eshautomate"}

            res = initialize_request.delete(hosturl, params=value)
            assert res.status_code == 424, res.json()
            mc_validator.validate_mc_api_response_data(res.status_code, res.json(),"recipeTypeRecipeDependency",
                                                        "Recipe Type Dependent on Recipe")