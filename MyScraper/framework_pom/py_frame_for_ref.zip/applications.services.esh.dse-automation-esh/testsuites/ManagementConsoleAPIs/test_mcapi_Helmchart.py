import utils
import pytest
import requests
from utils import FileOperations as fo
from configs import ManagementConsole as mcapi
from libs import commons
import json
from libs import API_responseValidation as api_validation
from libs.ManagementConsole import MC_APIsDataProvider as mc_dp
from libs.ManagementConsole import MC_APIsResponseValidation as mc_validator


class Test_HelmchartAPI:
    global createHelmchartData
    createHelmchartData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_Helmchart_JSON,"CREATE")
    updateHelmchartData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_Helmchart_JSON,"UPDATE")

    @pytest.fixture(scope='class')
    def collectHelmchartId(self):
        return []

    @pytest.fixture(scope='class')
    def createdHelmchartId(self):
        return []

    def test_getHelmchart(self, record_property, collectHelmchartId, init_env, initialize_request):
        record_prop = {"JIRA_ID": "EETK-9312",
                       "Short_Desc": "Validate the user is able to fetch HelmChart data using gethelmChart api"}
        commons.set_Record_Property(record_property, record_prop, "API", "No Browser")
        hosturl = init_env + mcapi.HelmChartEndPoint
        res = initialize_request.get(url=hosturl, verify=False)
        collectHelmchartId.append(res.json()[0]['id'])
        collectHelmchartId.append(res.json()[1]['id'])
        collectHelmchartId.append(res.json()[2]['id'])
        collectHelmchartId.append(res.json()[3]['id'])
        collectHelmchartId.append(res.json()[4]['id'])
        assert res.status_code == 200
        assert len(res.json()) > 0

    def test_get_helmchart_by_id(self, record_property, collectHelmchartId, init_env, initialize_request):
        record_prop = {"JIRA_ID": "EETK-9313",
                       "Short_Desc": "Validate the user is able to fetch specific, helmchart data using gethelmChartById api"}
        commons.set_Record_Property(record_property, record_prop, "API", "No Browser")
        hosturl = init_env + mcapi.HelmChartEndPoint + str(collectHelmchartId[0]) + "/"
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.status_code == 200

        hosturl = init_env + mcapi.HelmChartEndPoint + str(collectHelmchartId[1]) + "/"
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.status_code == 200

        hosturl = init_env + mcapi.HelmChartEndPoint + str(collectHelmchartId[2]) + "/"
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.status_code == 200

    def test_get_helmchart_by_invalid_id(self, record_property, collectHelmchartId, init_env, initialize_request):
        record_prop = {"JIRA_ID": "EETK-7137",
                       "Short_Desc": "Validate dbsyncbyId API by giving invalid recipe/helm chart/container id in 'id' field"}
        commons.set_Record_Property(record_property, record_prop, "API", "No Browser")
        hosturl = init_env + mcapi.HelmChartEndPoint + "602cea8234c227002a8202de" + "/"
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.status_code == 400

    #  To Create HelmCharts

    @pytest.mark.parametrize("TestData", createHelmchartData)
    def test_createHelmchart(self, TestData, record_property, createdHelmchartId, init_env, initialize_request,
                             fetch_dependent_ids):
        commons.set_Record_Property(record_property, TestData, "API", "No Browser")
        payload = json.loads(TestData["request_payload"])

        payload = mc_dp.update_name_and_version_in_payload(payload)
        payload = mc_dp.update_helmchart_dependent_values(payload, fetch_dependent_ids)
        print(payload)

        res = initialize_request.post(url=init_env + mcapi.HelmChartEndPoint, json=payload, verify=False)

        if TestData["response_code"] == 200:
            assert res.status_code == 200, res.json()
            createdHelmchartId.append(res.json()['id'])
            mc_validator.validate_helmchart_response_json(res.json(), payload)
            # mc_validator.validate_helmchart_response_json(res.json(), payload, TestData)
        else:
            assert res.status_code == TestData["response_code"], print(str(res.json()))

        mc_validator.validate_mc_api_response_data(res.status_code, res.json(), TestData["expected_message_code"],
                                                   TestData["expected_message"])
        # mc_validator.validate_json_schema(res.json(), "CreateHelmchart")

    # # To Promote a HelmChart
    #
    # def test_promoteHelmchart(self, record_property, init_env, createdHelmchartId, initialize_request,
    #                           fetch_helmchart_request_json):
    #     record_prop = {"JIRA_ID": "", "Short_Desc": ""}
    #     commons.set_Record_Property(record_property, record_prop, "API", "No Browser")
    #     name = "AUTO_promote_" + str(utils.common.get_Current_TimeStamp()[4:])
    #
    #     fetch_helmchart_request_json["name"]["en"] = name
    #     fetch_helmchart_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
    #     res = initialize_request.post(url=init_env + mcapi.HelmChartEndPoint, json=fetch_helmchart_request_json,
    #                                   verify=False)
    #     assert res.status_code == 200, str(res.json())
    #
    #     promoteURL = init_env + "/basecomponent/promoteById"
    #     payload = {
    #         "type": "helmchart",
    #         "id": str(res.json()["data"]["id"]),
    #         "user": str(res.json()["data"]["user"]),
    #         "envValue": "dev"
    #     }
    #     res = initialize_request.post(promoteURL, json=payload, verify=False)
    #     assert res.status_code == 200, str(res.json())
    #
    # # Create helmchart with existing names
    #
    # def test_create_helmchart_with_existing_name(self, record_property, init_env, initialize_request,
    #                                              fetch_helmchart_request_json, fetch_dependent_ids):
    #
    #     name = "Auto_existing" + str(utils.common.get_Current_TimeStamp()[4:])
    #     record_prop = {"JIRA_ID": "EETK-7912",
    #                    "Short_Desc": "Validate creating already existing HelmChart with API"}
    #     commons.set_Record_Property(record_property, record_prop, "API", "No Browser")
    #
    #     fetch_helmchart_request_json = mc_dp.update_helmchart_dependent_values(fetch_helmchart_request_json,
    #                                                                            fetch_dependent_ids)
    #
    #     fetch_helmchart_request_json["name"]["en"] = name
    #     fetch_helmchart_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
    #     print(fetch_helmchart_request_json)
    #     res = initialize_request.post(url=init_env + mcapi.HelmChartEndPoint, json=fetch_helmchart_request_json,
    #                                   verify=False)
    #     print(res.json())
    #     assert res.status_code == 200, "Initial Helmchart creation failed"
    #
    #     res = initialize_request.post(url=init_env + mcapi.HelmChartEndPoint, json=fetch_helmchart_request_json,
    #                                   verify=False)
    #     assert res.status_code == 400, res.json()
    #     # assert res.json()["message"]=="Version  and Name exist!"
    #     # assert res.json()["messageCode"]=="Name and version exist "
    #     if "Version  and Name exist!" not in str(res.json()):
    #         pytest.fail("Error message is not correct -- " + str(res.json()))
    #
    def test_create_helmchart_with_multiple_versions(self, record_property, init_env, initialize_request,
                                                     fetch_helmchart_request_json, fetch_dependent_ids):
        name = "Auto_Multi_" + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-7922, EETK-7900",
                       "Short_Desc": "Validate creating multiple version of a HelmChart by giving version no. in 'version',"
                                     "Create different version of HelmChart and validate if API is fetching all the details of HelmChart",
                       "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")
    
        fetch_helmchart_request_json = mc_dp.update_helmchart_dependent_values(fetch_helmchart_request_json,
                                                                               fetch_dependent_ids)
    
        fetch_helmchart_request_json["name"]["en"] = name
        fetch_helmchart_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        print(fetch_helmchart_request_json)
    
        #res1 = initialize_request.post(init_env + "/helmchart", json=fetch_helmchart_request_json)
        res1 = initialize_request.post(init_env + mcapi.HelmChartEndPoint, json=fetch_helmchart_request_json)
        print(res1.json())
        assert res1.status_code == 200
        fetch_helmchart_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        print(fetch_helmchart_request_json)
        res2 = initialize_request.post(init_env + mcapi.HelmChartEndPoint, json=fetch_helmchart_request_json)
        print(res2.json())
        assert res2.status_code == 200
    
        get_helmchart1 = initialize_request.get(url=init_env + mcapi.HelmChartEndPoint + res1.json()["id"],
                                                verify=False)
        get_helmchart2 = initialize_request.get(url=init_env + mcapi.HelmChartEndPoint + res2.json()["id"],
                                                verify=False)
        assert get_helmchart1.json()["name"]["en"] == get_helmchart2.json()["name"]["en"]
        assert get_helmchart1.json()["fullJenkinsPath"] == get_helmchart2.json()["fullJenkinsPath"]

    @pytest.mark.parametrize("TestData", updateHelmchartData)
    def test_updateHelmchart(self, TestData, record_property, createdHelmchartId, init_env, initialize_request, fetch_dependent_ids):
        commons.set_Record_Property(
            record_property, TestData, "API", "No Browser")
        payload = json.loads(TestData["request_payload"])
        updated_param=TestData["updated_param"]
        if(TestData["UUID"] != ""):
            UUID = TestData["UUID"]
        else:
            UUID=createdHelmchartId[0]
        getHostUrl = init_env + mcapi.HelmChartEndPoint + UUID + '/'
        getRes = requests.get(url=getHostUrl, verify=False)

        payload["name"]["en"] = getRes.json()["name"]["en"]
        if (payload["version"] == "blank"):
            payload["version"] = getRes.json()["version"]

        hosturl = init_env + mcapi.HelmChartEndPoint + UUID + "/"
        res = requests.put(url=hosturl, json=payload, verify=False)
        data=res.json()
        print("\n")
        print(data)
        if TestData["response_code"] == 200:
            assert res.status_code == 200, print(str(res.json())+str(payload))
            mc_validator.validate_helmchart_response_json(
                res.json(), payload)
            if updated_param=="coOwners":
                assert payload[updated_param][0]==data["data"][updated_param][0]["userId"]
            else:
                assert payload[updated_param]==data["data"][updated_param]
        else:
            if TestData["expected_message_code"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["messageCode"],TestData["expected_message_code"])
            if TestData["expected_message"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["message"],TestData["expected_message"])
        assert res.status_code==TestData['response_code']
