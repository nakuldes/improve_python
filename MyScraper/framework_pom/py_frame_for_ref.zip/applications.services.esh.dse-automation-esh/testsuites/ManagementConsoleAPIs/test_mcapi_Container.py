import utils
import requests
import pytest
from utils import FileOperations as fo
from configs import ManagementConsole as mcapi
from libs import commons
import time
import json
from libs import API_responseValidation as api_validation
from libs.ManagementConsole import MC_APIsDataProvider as mc_dp
from libs.ManagementConsole import MC_APIsResponseValidation as mc_validator


class Test_ContainerAPI:

    global createContainerData
    createContainerData = fo.File_Operations().get_json_file_filtered_data(
        mcapi.file_path_create_Container_JSON, "create")
    updateContainerData = fo.File_Operations().get_json_file_filtered_data(
        mcapi.file_path_create_Container_JSON, "update")
    deleteContainerData = fo.File_Operations().get_json_file_filtered_data(
        mcapi.file_path_create_Container_JSON, "delete")
    createContainerMulitpleVersionsData = fo.File_Operations().get_json_file_filtered_data(
        mcapi.file_path_create_Container_JSON, "create_multiple_versions")

    @pytest.fixture(scope='class')
    def collectContainerId(self):
        return []

    @pytest.fixture(scope='class')
    def createdContainerId(self):
        return []

    def test_getContainer(self, record_property, collectContainerId, init_env, initialize_request):
        record_prop = {"JIRA_ID": "EETK-7015,EETK-7016",
                       "Short_Desc": "Create multiple Containers and validate if API is fetching the list of all Containers,Create a Intel Private registry container in MC and validate if API is fetching all the details of container by giving its UUID"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = init_env + mcapi.ContainerEndPoint
        res = initialize_request.get(url=hosturl, verify=False)
        collectContainerId.append(res.json()[0]['id'])
        collectContainerId.append(res.json()[1]['id'])
        collectContainerId.append(res.json()[2]['id'])
        collectContainerId.append(res.json()[3]['id'])
        assert res.status_code == 200
        assert len(res.json()) > 0

    def test_getContainer_by_Invalid_Id(self, record_property, init_env, initialize_request):
        record_prop = {"JIRA_ID": "EETK-7020",
                       "Short_Desc": "Validate containerGetByID api by passing invalid container id"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = init_env + mcapi.ContainerEndPoint + "INVALID"
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.status_code == 400

    @pytest.mark.parametrize("TestData", createContainerData)
    def test_createContainer(self, TestData, record_property, createdContainerId, init_env, initialize_request, fetch_dependent_ids):
        commons.set_Record_Property(
            record_property, TestData, "API", "No Browser")
        payload = json.loads(TestData["request_payload"])
        time.sleep(0.001)
        payload = mc_dp.update_name_and_version_in_payload(payload)
        payload = mc_dp.update_container_dependent_values(
            payload, fetch_dependent_ids)

        res = initialize_request.post(
            url=init_env + mcapi.ContainerEndPoint, json=payload, verify=False)

        
        if TestData["response_code"] == 200:
            assert res.status_code == 200, print(str(res.json())+str(payload))
            createdContainerId.append([res.json()['id'], res.json(
            )['data']['imageSourceType'], res.json()['data']['registryType']])
            
            mc_validator.validate_container_response_json(
                res.json(), payload, TestData)
        else:
            assert res.status_code == TestData["response_code"], print(
                str(res.json()))

        mc_validator.validate_mc_api_response_data(res.status_code, res.json(), TestData["expected_message_code"],
                                                   TestData["expected_message"])
        # mc_validator.validate_json_schema(res.json(), "CreateModule")

    @pytest.mark.parametrize("TestData", updateContainerData)
    def test_updateContainer(self, TestData, record_property, createdContainerId, init_env, initialize_request, fetch_dependent_ids):
        commons.set_Record_Property(
            record_property, TestData, "API", "No Browser")
        payload = json.loads(TestData["request_payload"])
        if(TestData["UUID"] != ""):
            UUID = TestData["UUID"]

        else:
            for x in createdContainerId:
                if x[1] == payload['imageSourceType'] and x[2] == payload['registryType']:
                    UUID = str(x[0])
                    break

        getHostUrl = init_env + mcapi.ContainerEndPoint + UUID + '/'
        
        getRes = requests.get(url=getHostUrl, verify=False)

        if payload["name"]["en"] == "UPDATE":
            payload["name"]["en"] = getRes.json()["name"]["en"] + '_UPDATE'

        else:
            payload["name"]["en"] = getRes.json()["name"]["en"]
        if (payload["version"] == "blank"):
            payload["version"] = getRes.json()["version"]

        hosturl = init_env + mcapi.ContainerEndPoint + UUID + "/"
        res = requests.put(url=hosturl, json=payload, verify=False)

        if TestData["response_code"] == 200:
            assert res.status_code == 200, print(str(res.json())+str(payload))
            mc_validator.validate_container_response_json(
                res.json(), payload, TestData)
        else:
            assert res.status_code == TestData["response_code"], print(
                str(res.json()))

        mc_validator.validate_mc_api_response_data(res.status_code, res.json(), TestData["expected_message_code"],
                                                   TestData["expected_message"])
        # mc_validator.validate_json_schema(res.json(), "CreateModule")


    def test_update_container_with_valid_data(self, record_property, init_env, initialize_request, createdContainerId, fetch_container_request_json, fetch_dependent_ids):

        report_data = {"JIRA_ID": "EETK-7970, EETK-7021",
                       "Short_Desc": "Validate if container is updated using updateContainer API, Update existing container in MC and validate API is fetching with latest details"}
        commons.set_Record_Property(record_property, report_data, "API", "No Browser")
        for x in createdContainerId:
            if x[1] == "buildimage" and x[2] == "intelprivate":
                UUID = str(x[0])
                break
        container_id = UUID
        hosturl = init_env + mcapi.ContainerEndPoint + container_id
        res = initialize_request.get(url=hosturl, verify=False)
        assert  res.status_code == 200, str(res.json())
        mc_dp.update_container_dependent_values(fetch_container_request_json, fetch_dependent_ids)
        fetch_container_request_json["name"]["en"] = res.json()["name"]["en"]
        fetch_container_request_json["version"] = res.json()["version"]
        #Updated needs to be done for modules
        fetch_container_request_json["description"]["en"] = "Updated Description"
        fetch_container_request_json["displayName"]["en"] = "Updated displayName"
        fetch_container_request_json["moreInfo"]["en"] = "Updated moreInfo"
        fetch_container_request_json["baseImage"] = "updatedbaseimage"
        # fetch_module_request_json["releaseTag"] = "Updated New tag"

        update = initialize_request.put(init_env + mcapi.ContainerEndPoint + container_id, json=fetch_container_request_json)

        assert update.status_code == 200, str(update.json())
        assert update.json()["data"]["description"]["en"] == "Updated Description"
        assert update.json()["data"]["displayName"]["en"] == "Updated displayName"
        assert update.json()["data"]["moreInfo"]["en"] == "Updated moreInfo"
        assert update.json()["data"]["baseImage"] == "updatedbaseimage"
        assert update.json()["data"]["fullJenkinsPath"] == res.json()["fullJenkinsPath"]



    def test_update_RegistryTypes_of_Import_Containers(self, record_property, createdContainerId, init_env, initialize_request, fetch_container_request_json, fetch_dependent_ids):
        record_prop = {"JIRA_ID": "EETK-10831",
                       "Short_Desc": "Validate updating registry types in a import image container"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")

        for x in createdContainerId:
            if x[1] == "importimage" and x[2] == "intelprivate":
                UUID = str(x[0])
                break

        hosturl = init_env + mcapi.ContainerEndPoint + UUID
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.status_code == 200, str(res.json())
        mc_dp.update_container_dependent_values(
            fetch_container_request_json, fetch_dependent_ids)
        fetch_container_request_json["name"]["en"] = res.json()["name"]["en"]
        fetch_container_request_json["version"] = res.json()["version"]
        fetch_container_request_json["registryType"] = "intelpublic"
        fetch_container_request_json["imageSourceType"] = "importimage"

        update1 = initialize_request.put(
            init_env + mcapi.ContainerEndPoint + UUID, json=fetch_container_request_json)
        assert update1.status_code == 200, str(update1.json())
        assert update1.json()["data"]["registryType"] == "intelpublic"

        fetch_container_request_json["registryType"] = "public"
        update2 = initialize_request.put(
            init_env + mcapi.ContainerEndPoint + UUID, json=fetch_container_request_json)
        assert update2.status_code == 200, str(update2.json())
        assert update2.json()["data"]["registryType"] == "public"

        pass

    @pytest.mark.parametrize("TestData", createContainerMulitpleVersionsData)
    def test_create_container_with_multiple_versions(self, TestData, record_property, init_env, initialize_request, fetch_dependent_ids):
        commons.set_Record_Property(
            record_property, TestData, "API", "No Browser")
        payload = json.loads(TestData["request_payload"])

        payload = mc_dp.update_name_and_version_in_payload(payload)
        payload = mc_dp.update_container_dependent_values(
            payload, fetch_dependent_ids)
        res1 = initialize_request.post(
            url=init_env + mcapi.ContainerEndPoint, json=payload, verify=False)
        assert res1.status_code == 200
        # time.sleep(3)
        payload["version"] = "1." + \
            str(utils.common.get_Current_TimeStamp()[4:14])
        res2 = initialize_request.post(
            url=init_env + mcapi.ContainerEndPoint, json=payload, verify=False)
        assert res2.status_code == 200
        get_container1 = initialize_request.get(
            url=init_env + mcapi.ContainerEndPoint + res1.json()["id"], verify=False)
        get_container2 = initialize_request.get(
            url=init_env + mcapi.ContainerEndPoint + res2.json()["id"], verify=False)
        assert get_container1.json()["name"]["en"] == get_container2.json()[
            "name"]["en"]
        if payload["imageSourceType"] == "buildimage":
            assert get_container1.json()["fullJenkinsPath"] == get_container2.json()[
                "fullJenkinsPath"]

    @pytest.mark.parametrize("TestData", deleteContainerData)
    def test_deleteContainer_negative(self, TestData, record_property, collectContainerId, init_env, initialize_request):
        commons.set_Record_Property(
            record_property, TestData, "API", "No Browser")
        TestData = mc_dp.update_user_and_uuid_in_payload(TestData)
        Id = {"Id": TestData["Id"]}
        value = {"user": TestData["user"]}
        if Id != "INVALID" or Id != "":
            Id = {"Id": collectContainerId[0]}
        hosturl = init_env + mcapi.ContainerEndPoint + str(Id) + "/"
        res = initialize_request.delete(hosturl, params=value, verify=False)
        assert res.status_code == 400

    def test_deleteContainer(self, record_property, createdContainerId, init_env, initialize_request):
        record_prop = {"JIRA_ID": "EETK-7975, EETK-7023, EETK-7027",
                       "Short_Desc": "Validate if container is deleted using deleteContainer API, Create container and validate its deletion, Validate deleting already deleted container with API"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")
        hosturl = init_env + mcapi.ContainerEndPoint + \
            str(createdContainerId[-1][0]) + "/"
        value = {"user": "eshautomate"}
        res = initialize_request.delete(hosturl, params=value, verify=False)
        assert res.status_code == 200
        hosturl = init_env + mcapi.ContainerEndPoint + \
            str(createdContainerId[-1][0]) + "/"
        value = {"user": "eshautomate"}
        res = initialize_request.delete(hosturl, params=value, verify=False)
        assert res.status_code == 400

     # This Test case fails as the jenkins status needs to be manually refreshed to update its status
    # Workaround- Needs to check with developer team to check if their is any API to trigger refresh button for updating the Jenkins status
    # def test_promoteContainer(self, record_property, init_env, createdContainerId, initialize_request, fetch_container_request_json):
    #     record_prop = {"JIRA_ID": "EETK-7145",
    #                    "Short_Desc": "Validate promotion of Container with API when Container status is Not started/Failed"}
    #     commons.set_Record_Property(
    #         record_property, record_prop, "API", "No Browser")
    #     name = "AUTO_promote_" + str(utils.common.get_Current_TimeStamp()[4:])

    #     fetch_container_request_json["name"]["en"] = name
    #     fetch_container_request_json["version"] = "1." + \
    #         str(utils.common.get_Current_TimeStamp()[4:])
    #     res = initialize_request.post(
    #         url=init_env + mcapi.ContainerEndPoint, json=fetch_container_request_json, verify=False)
    #     assert res.status_code == 200, str(res.json())

    #     promoteURL = init_env + "/basecomponent/promoteById"
    #     payload = {
    #         "type": "container",
    #         "id": str(res.json()["data"]["id"]),
    #         "user": str(res.json()["data"]["user"]),
    #         "envValue": "dev"
    #     }
    #     res = initialize_request.post(promoteURL, json=payload, verify=False)
    #     assert res.status_code == 200, str(res.json())

    def test_creatingExistingContainer(self, record_property, init_env, initialize_request, fetch_container_request_json, fetch_dependent_ids):

        name = "Auto_existing" + str(utils.common.get_Current_TimeStamp()[4:])
        record_prop = {"JIRA_ID": "EETK-7031",
                       "Short_Desc": "creating already existing Container"}
        commons.set_Record_Property(
            record_property, record_prop, "API", "No Browser")

        fetch_container_request_json = mc_dp.update_container_dependent_values(
            fetch_container_request_json, fetch_dependent_ids)
        fetch_container_request_json["name"]["en"] = name
        fetch_container_request_json["version"] = "1." + \
            str(utils.common.get_Current_TimeStamp()[4:])
        res = initialize_request.post(
            url=init_env + mcapi.ContainerEndPoint, json=fetch_container_request_json, verify=False)
        
        assert res.status_code == 200, "Initial Container Creation failed"

        res = initialize_request.post(
            url=init_env + mcapi.ContainerEndPoint, json=fetch_container_request_json, verify=False)
        assert res.status_code == 400, res.json()
        # api_validation.validateJSONFieldData(res.json()["message"],"Version  and Name exist!")
        # api_validation.validateJSONFieldData(res.json()["messageCode"],"Name and version exist ")
        if "Version  and Name exist!" not in str(res.json()):
            pytest.fail("Error message is not correct -- " + str(res.json()))

    # def test_update_container_with_valid_data(self, record_property, init_env, initialize_request, createdContainerId, fetch_container_request_json, fetch_dependent_ids):

    #     report_data = {"JIRA_ID": "EETK-7970",
    #                    "Short_Desc": "Validate if container is updated using updateContainer API"}
    #     commons.set_Record_Property(
    #         record_property, report_data, "API", "No Browser")

    #     module_id = createdContainerId[0][0]
    #     hosturl = init_env + mcapi.ContainerEndPoint + module_id
    #     res = initialize_request.get(url=hosturl, verify=False)
    #     assert res.status_code == 200, str(res.json())
    #     mc_dp.update_container_dependent_values(
    #         fetch_container_request_json, fetch_dependent_ids)
    #     fetch_container_request_json["name"]["en"] = res.json()["name"]["en"]
    #     fetch_container_request_json["version"] = res.json()["version"]
    #     # Updated needs to be done for modules
    #     fetch_container_request_json["description"]["en"] = "Updated Description"
    #     fetch_container_request_json["displayName"]["en"] = "Updated displayName"
    #     fetch_container_request_json["moreInfo"]["en"] = "Updated moreInfo"
    #     fetch_container_request_json["baseImage"] = "updatedbaseimage"
    #     # fetch_module_request_json["releaseTag"] = "Updated New tag"

    #     update = initialize_request.put(
    #         init_env + mcapi.ContainerEndPoint + module_id, json=fetch_container_request_json)

    #     assert update.status_code == 200, str(update.json())
    #     assert update.json()[
    #         "data"]["description"]["en"] == "Updated Description"
    #     assert update.json()[
    #         "data"]["displayName"]["en"] == "Updated displayName"
    #     assert update.json()["data"]["moreInfo"]["en"] == "Updated moreInfo"
    #     assert update.json()["data"]["baseImage"] == "updatedbaseimage"
    #     assert update.json()["data"]["fullJenkinsPath"] == res.json()[
    #         "fullJenkinsPath"]

    # # @pytest.mark.skip
    # def test_update_existing_container_with_valid_data(self, record_property, init_env, initialize_request, collectContainerId, fetch_container_request_json, fetch_dependent_ids):

    #     report_data = {"JIRA_ID": "EETK-7021",
    #                    "Short_Desc": "Update existing container in MC and validate API is fetching with latest details"}
    #     commons.set_Record_Property(
    #         record_property, report_data, "API", "No Browser")
    #     module_id = collectContainerId[0][0]
    #     hosturl = init_env + mcapi.ContainerEndPoint + module_id
    #     res = initialize_request.get(url=hosturl, verify=False)
    #     assert res.status_code == 200, str(res.json())
    #     mc_dp.update_container_dependent_values(
    #         fetch_container_request_json, fetch_dependent_ids)
    #     fetch_container_request_json["name"]["en"] = res.json()["name"]["en"]
    #     fetch_container_request_json["version"] = res.json()["version"]
    #     # Updated needs to be done for modules
    #     fetch_container_request_json["description"]["en"] = "Updated Description"
    #     fetch_container_request_json["displayName"]["en"] = "Updated displayName"
    #     fetch_container_request_json["moreInfo"]["en"] = "Updated moreInfo"
    #     fetch_container_request_json["baseImage"] = "updatedbaseimage"
    #     # fetch_module_request_json["releaseTag"] = "Updated New tag"

    #     update = initialize_request.put(
    #         init_env + mcapi.ContainerEndPoint + module_id, json=fetch_container_request_json)

    #     assert update.status_code == 200, str(update.json())
    #     assert update.json()[
    #         "data"]["description"]["en"] == "Updated Description"
    #     assert update.json()[
    #         "data"]["displayName"]["en"] == "Updated displayName"
    #     assert update.json()["data"]["moreInfo"]["en"] == "Updated moreInfo"
    #     assert update.json()["data"]["baseImage"] == "updatedbaseimage"
    #     assert update.json()["data"]["fullJenkinsPath"] == res.json()[
    #         "fullJenkinsPath"]

    def test_update_container_name(self, record_property, init_env, initialize_request, createdContainerId, fetch_container_request_json, fetch_dependent_ids):

        report_data = {"JIRA_ID": "EETK-7971",
                       "Short_Desc": "Validate if module is updated using updateModule API"}
        commons.set_Record_Property(
            record_property, report_data, "API", "No Browser")
        module_id = createdContainerId[0][0]
        hosturl = init_env + mcapi.ContainerEndPoint + module_id
        res = initialize_request.get(url=hosturl, verify=False)
        assert res.status_code == 200
        mc_dp.update_container_dependent_values(
            fetch_container_request_json, fetch_dependent_ids)
        fetch_container_request_json["name"]["en"] = "Update Name"
        fetch_container_request_json["version"] = res.json()["version"]
        # Updated needs to be done for modules
        fetch_container_request_json["description"]["en"] = "Updated Description"

        update = initialize_request.put(
            init_env + mcapi.ContainerEndPoint + module_id, json=fetch_container_request_json)
        assert update.status_code == 400
        if "container name cannot be updated." not in str(update.json()):
            pytest.fail("Error message is not correct. " + str(update.json()))
