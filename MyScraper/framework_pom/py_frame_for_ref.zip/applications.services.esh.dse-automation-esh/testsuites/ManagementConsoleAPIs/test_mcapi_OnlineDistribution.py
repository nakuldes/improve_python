import requests
import pytest
import utils
from utils import FileOperations as fo
from configs import ManagementConsole as mcapi
from libs import commons
import json
from libs import API_responseValidation as api_validation
from libs.ManagementConsole import MC_APIsDataProvider as mc_dp

class Test_OnlineDistributionAPI:


    
    createOnlineDistributionData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_OnlineDistribution_JSON,'create')
    updateOnlineDistributionData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_OnlineDistribution_JSON,'update')
    getByIdOnlineDistributionData= fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_OnlineDistribution_JSON,'fetch')
    deleteOnlineDistributionData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_OnlineDistribution_JSON,"DELETE")
    global record_prop
    record_prop = {"JIRA_ID":"No JIRA","Short_Desc":"No Desc"}
    

    """for get and getById APIs"""
    @pytest.fixture(scope='class')
    def collectOnlineDistributionId(self):
        return []
    


    """maintains list of created ODs, used in create, update, delete tests"""
    @pytest.fixture(scope='class')
    def createdOnlineDistributionId(self):
        return []


    def test_getOnlineDistribution(self,record_property,collectOnlineDistributionId,init_env):
        report_data = {"JIRA_ID": "EETK-7456",
                   "Short_Desc": "Validate fetching list of all Online Distributions in MC with API",
                   "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        
        hosturl = init_env + mcapi.OnlineDistributionEndpoint
        res = requests.get(url=hosturl,verify=False)
        collectOnlineDistributionId.append(res.json()[0]['id'])
        collectOnlineDistributionId.append(res.json()[1]['id'])
        
        assert res.status_code==200
        assert len(res.json())>0

    @pytest.mark.parametrize("Testdata",getByIdOnlineDistributionData)
    def test_getOnlineDistributionById(self,Testdata,record_property,collectOnlineDistributionId,init_env):
        commons.set_Record_Property(record_property,Testdata,"API", "No Browser")
        if(Testdata["UUID"]!=""):
            hosturl = init_env + mcapi.OnlineDistributionEndpoint + Testdata["UUID"] + "/"
        else:
            hosturl = init_env + mcapi.OnlineDistributionEndpoint + str(collectOnlineDistributionId.pop()) + "/"
        res = requests.get(url=hosturl,verify=False)
        assert res.status_code==Testdata['response_code']

    @pytest.mark.parametrize("Testdata",createOnlineDistributionData)
    def test_createOnlineDistribution(self,Testdata,record_property,createdOnlineDistributionId,init_env,fetch_dependent_ids):
        commons.set_Record_Property(record_property,Testdata,"API", "No Browser")
        payload=json.loads(Testdata["request_payload"])
        payload = mc_dp.update_name_and_version_in_payload(payload)
        payload = mc_dp.update_onlinedistribution_dependent_values(payload, fetch_dependent_ids)

        hosturl = init_env + mcapi.OnlineDistributionEndpoint
        res = requests.post(url=hosturl,json=payload,verify=False)
        data=res.json()
        if res.status_code==201:
            OD_data={"id":data['id'],"version":data['data']['version'],"user":data['data']['createdBy']}
            createdOnlineDistributionId.append(OD_data)
            api_validation.validateJSONFieldData(data["message"],Testdata["expected_message"])
            api_validation.validateJSONFieldData(data["messageCode"],Testdata["expected_message_code"])
        else:
            if Testdata["expected_message_code"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["messageCode"],Testdata["expected_message_code"])
            if Testdata["expected_message"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["message"],Testdata["expected_message"])
        assert res.status_code==Testdata['response_code']
    

    @pytest.mark.parametrize("Testdata",updateOnlineDistributionData)
    def test_updateOnlineDistribution(self,Testdata,record_property,init_env,createdOnlineDistributionId):
        commons.set_Record_Property(record_property,Testdata,"API", "No Browser")

        payload=json.loads(Testdata["request_payload"])
        if(Testdata["UUID"]!=""):
            hosturl = init_env + mcapi.OnlineDistributionEndpoint + Testdata["UUID"] + "/"
        else:
            hosturl = init_env + mcapi.OnlineDistributionEndpoint + str(createdOnlineDistributionId[0]["id"]) + "/"
            if (payload["version"]=="blank"):
                payload['version'] = createdOnlineDistributionId[0]["version"]
        res = requests.put(url=hosturl,json=payload,verify=False)
        data=res.json()
        
        if res.status_code==200:
            api_validation.validateJSONFieldData(data["message"],Testdata["expected_message"])
            api_validation.validateJSONFieldData(data["messageCode"],Testdata["expected_message_code"])
        else:
            if Testdata["expected_message_code"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["messageCode"],Testdata["expected_message_code"])
            if Testdata["expected_message"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["message"],Testdata["expected_message"])
        assert res.status_code==Testdata['response_code']



    def test_create_OD_and_fetch_its_details(self, record_property, init_env,createdOnlineDistributionId,fetch_onlinedistribution_request_json,fetch_dependent_ids):
        name = "Auto_OD_" + str(utils.common.get_Current_TimeStamp()[4:])
        version = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-7458",
                   "Short_Desc": "Create Online Distribution in MC and Validate fetching all of its details using API",
                   "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")

        fetch_onlinedistribution_request_json["name"]["en"] = name
        fetch_onlinedistribution_request_json["version"] = version
        fetch_onlinedistribution_request_json = mc_dp.update_onlinedistribution_dependent_values(fetch_onlinedistribution_request_json, fetch_dependent_ids)
       
        hosturl = init_env + mcapi.OnlineDistributionEndpoint
        res = requests.post(url=hosturl,json=fetch_onlinedistribution_request_json,verify=False)
        data=res.json()

        if res.status_code==201:
            OD_data={"id":data['id'],"version":data['data']['version'],"user":data['data']['createdBy']}
            createdOnlineDistributionId.append(OD_data)
            getODbyID_hosturl = init_env + mcapi.OnlineDistributionEndpoint + data["id"] + "/"
            getODbyID_res = requests.get(url=getODbyID_hosturl,verify=False)
            
            assert name==getODbyID_res.json()["name"]["en"]
            assert version==getODbyID_res.json()["version"]
            assert data["data"]["createdOn"]==getODbyID_res.json()["createdOn"]
        else:
            assert False

    def test_create_another_version_of_OD_and_fetch_its_details(self, record_property, init_env,createdOnlineDistributionId,fetch_onlinedistribution_request_json,fetch_dependent_ids):
        name = "Auto_OD_" + str(utils.common.get_Current_TimeStamp()[4:])
        version1 = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        version2 = "2." + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-7459",
                   "Short_Desc": "Create different version of Online Distribution and Validate fetching all of its details with API",
                   "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")

        fetch_onlinedistribution_request_json["name"]["en"] = name
        fetch_onlinedistribution_request_json["version"] = version1
        fetch_onlinedistribution_request_json = mc_dp.update_onlinedistribution_dependent_values(fetch_onlinedistribution_request_json, fetch_dependent_ids)
        hosturl = init_env + mcapi.OnlineDistributionEndpoint
        version1_res = requests.post(url=hosturl,json=fetch_onlinedistribution_request_json,verify=False)
        assert version1_res.status_code==201
        data1=version1_res.json()
        OD_data={"id":data1['id'],"version":data1['data']['version'],"user":data1['data']['createdBy']}
        createdOnlineDistributionId.append(OD_data)
        fetch_onlinedistribution_request_json["version"] = version2
        version2_res = requests.post(url=hosturl,json=fetch_onlinedistribution_request_json,verify=False)
        data2=version2_res.json()

        if version2_res.status_code==201:
            OD_data={"id":data2['id'],"version":data2['data']['version'],"user":data2['data']['createdBy']}
            createdOnlineDistributionId.append(OD_data)
            getODbyID_hosturl = init_env +mcapi.OnlineDistributionEndpoint + data2["id"] + "/"
            getODbyID_res = requests.get(url=getODbyID_hosturl,verify=False)

            assert name==getODbyID_res.json()["name"]["en"]
            assert version2==getODbyID_res.json()["version"]
            assert data2["data"]["createdOn"]==getODbyID_res.json()["createdOn"]

        else:
            assert False

    def test_update_onlineDistribution_fetch_its_details(self, record_property, init_env,createdOnlineDistributionId,fetch_onlinedistribution_request_json,fetch_dependent_ids):
        name = "Auto_OD_" + str(utils.common.get_Current_TimeStamp()[4:])
        version = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-7461",
                   "Short_Desc": "Update existing Online Distribution in MC and Validate API is fetching with latest details",
                   "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")
        fetch_onlinedistribution_request_json["name"]["en"] = name
        fetch_onlinedistribution_request_json["version"] = version
        fetch_onlinedistribution_request_json = mc_dp.update_onlinedistribution_dependent_values(fetch_onlinedistribution_request_json, fetch_dependent_ids)
        hosturl = init_env + mcapi.OnlineDistributionEndpoint
        create_res = requests.post(url=hosturl,json=fetch_onlinedistribution_request_json,verify=False)
        data=create_res.json()
        if create_res.status_code==201:
            OD_data={"id":data['id'],"version":data['data']['version'],"user":data['data']['createdBy']}
            createdOnlineDistributionId.append(OD_data)
            UUID=data["id"]
            update_hosturl = init_env +mcapi.OnlineDistributionEndpoint + UUID + "/"
            updated_displayName="updated_" + fetch_onlinedistribution_request_json["displayName"]["en"]
            fetch_onlinedistribution_request_json["displayName"]["en"]=updated_displayName
            update_res = requests.put(url=update_hosturl,json=fetch_onlinedistribution_request_json,verify=False)

            assert update_res.status_code==200
            assert updated_displayName==update_res.json()["data"]["displayName"]["en"]
        
        else:
            assert False

    def test_create_OnlineDistribution_with_existing_name(self,record_property, init_env, initialize_request, fetch_onlinedistribution_request_json,fetch_dependent_ids,createdOnlineDistributionId):        
        name = "Auto_existing" + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-7453",
                   "Short_Desc": "Validate creating already existing Online Distribution with API",
                   "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")

        fetch_onlinedistribution_request_json = mc_dp.update_onlinedistribution_dependent_values(fetch_onlinedistribution_request_json, fetch_dependent_ids)
        fetch_onlinedistribution_request_json["name"]["en"] = name
        fetch_onlinedistribution_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        res = initialize_request.post(init_env + mcapi.OnlineDistributionEndpoint, json=fetch_onlinedistribution_request_json)
        data=res.json()
        OD_data={"id":data['id'],"version":data['data']['version'],"user":data['data']['createdBy']}
        createdOnlineDistributionId.append(OD_data)
        assert res.status_code == 201
        res = initialize_request.post(init_env + mcapi.OnlineDistributionEndpoint, json=fetch_onlinedistribution_request_json)
        assert res.status_code == 409


    def test_create_OnlineDistribution_multiple_versions(self,record_property, init_env, initialize_request, fetch_onlinedistribution_request_json,fetch_dependent_ids,createdOnlineDistributionId):        
        name = "Auto_Multiple_" + str(utils.common.get_Current_TimeStamp()[4:])
        report_data = {"JIRA_ID": "EETK-7457",
                       "Short_Desc": "Create different version of Modules and validate if API is fetching all the details of Modules, Validate creating multiple version of a Modules by giving version no. in version using post api",
                       "Data": name}
        commons.set_Record_Property(record_property, report_data, "API")

        fetch_onlinedistribution_request_json = mc_dp.update_onlinedistribution_dependent_values(fetch_onlinedistribution_request_json, fetch_dependent_ids)
        fetch_onlinedistribution_request_json["name"]["en"] = name
        fetch_onlinedistribution_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        res1 = initialize_request.post(init_env + mcapi.OnlineDistributionEndpoint, json=fetch_onlinedistribution_request_json)
        data=res1.json()
        OD_data={"id":data['id'],"version":data['data']['version'],"user":data['data']['createdBy']}
        createdOnlineDistributionId.append(OD_data)
        assert res1.status_code == 201
        fetch_onlinedistribution_request_json["version"] = "1." + str(utils.common.get_Current_TimeStamp()[4:])
        res2 = initialize_request.post(init_env + mcapi.OnlineDistributionEndpoint, json=fetch_onlinedistribution_request_json)
        data=res2.json()
        OD_data={"id":data['id'],"version":data['data']['version'],"user":data['data']['createdBy']}
        createdOnlineDistributionId.append(OD_data)
        assert res2.status_code == 201
        get_distribution1 = initialize_request.get(url=init_env + mcapi.OnlineDistributionEndpoint + res1.json()['id'] + '/', verify=False)
        get_distribution2 = initialize_request.get(url=init_env + mcapi.OnlineDistributionEndpoint + res2.json()['id'] + "/", verify=False)
        assert get_distribution1.json()["name"]["en"] == get_distribution2.json()["name"]["en"]
    
    @pytest.mark.parametrize("Testdata",deleteOnlineDistributionData)
    def test_deleteOnlineDistribution(self,Testdata,record_property,init_env):
        commons.set_Record_Property(record_property,Testdata,"API", "No Browser")
        
        distribution_uuid = Testdata["Distribution_UUID"]
        hosturl = init_env + mcapi.OnlineDistributionEndpoint + str(distribution_uuid)
        value={"user":Testdata["user"]}
        res = requests.delete(hosturl,params=value,verify=False)
        data = res.json()
        if res.status_code==200 or res.status_code==424:
            assert data["messageCode"] == Testdata["expected_message_code"]
        else:
            assert data["errors"][0]["messageCode"] == Testdata["expected_message_code"]
        assert res.status_code == Testdata["response_code"]
        


    def test_deleteDistributions(self,record_property,init_env,createdOnlineDistributionId):
        report_data = {"JIRA_ID": "EETK-7467",
                       "Short_Desc": "Validate Online Distribution deletion",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        if (len(createdOnlineDistributionId)) > 0:
            hosturl = init_env + mcapi.OnlineDistributionEndpoint + str(createdOnlineDistributionId[-1]['id']) + "/"
            value={"user":createdOnlineDistributionId[-1]["user"]}
            createdOnlineDistributionId.pop()
            res = requests.delete(hosturl,params=value,verify=False)
            
            assert res.status_code == 200

    def test_deleteOnlineDistributions(self,record_property,init_env,createdOnlineDistributionId):
        report_data = {"JIRA_ID": "EETK-9316",
                       "Short_Desc": "Validate deleting all online distribution using automation",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        for i in range (len(createdOnlineDistributionId)):
            hosturl = init_env + mcapi.OnlineDistributionEndpoint + str(createdOnlineDistributionId[i]["id"]) + "/"
            value={"user":createdOnlineDistributionId[i]["user"]}
            res = requests.delete(hosturl,params=value,verify=False)
            assert res.status_code == 200
    
