import pytest
import requests
import json
from configs import ManagementConsole as mc
from configs import EdgeSoftwareHubUI_CLI as eshui
from utils import FileOperations as fo


@pytest.fixture(scope='class')
def init_env(pytestconfig):
    global mc_url, esh_url,mc_api_qa, logger

    env = pytestconfig.getoption("env")
    if env == "QA":
        mc_url = mc.MC_QA
        esh_url = eshui.ESH_QA
        mc_api_qa = mc.MC_API_HOST_QA
    elif env == "DEV":
        mc_url = mc.MC_DEV
        esh_url = eshui.ESH_DEV

    return mc_api_qa

@pytest.fixture(scope='class')
def initialize_request():
    session = requests.Session()
    headers = {
        'Content-Type': 'application/json',
    }
    session.headers.update(headers)
    session.verify = False
    return session

@pytest.fixture(scope='class')
def fetch_dependent_ids(pytestconfig):

    env = pytestconfig.getoption("env")
    dependent_values = fo.File_Operations.get_json_file_data(mc.dependent_values_api)
    if env == "QA":
        final_dependent_values = dependent_values["QA"]
    elif env == "DEV":
        final_dependent_values = dependent_values["DEV"]
    elif env == "STAGE":
        final_dependent_values = dependent_values["STAGE"]

    return final_dependent_values

@pytest.fixture(scope='class')
def fetch_module_request_json():
    jsonfile = open(mc.create_module_request_payload)
    data=json.load(jsonfile)
    return data

@pytest.fixture(scope='class')
def fetch_onlinedistribution_request_json():
    jsonfile = open(mc.create_od_request_payload)
    data=json.load(jsonfile)
    return data

@pytest.fixture(scope='class')
def fetch_container_request_json():
    jsonfile = open(mc.create_container_request_payload)
    data=json.load(jsonfile)
    return data

@pytest.fixture(scope='class')
def fetch_package_request_json():
    jsonfile = open(mc.create_package_request_payload)
    data = json.load(jsonfile)
    return data

@pytest.fixture(scope='class')
def fetch_od_package_request_json():
    jsonfile = open(mc.create_od_package_request_payload)
    data = json.load(jsonfile)
    return data

@pytest.fixture(scope='class')
def fetch_helmchart_request_json():
    jsonfile = open(mc.create_helmchart_request_payload)
    data = json.load(jsonfile)
    return data

@pytest.fixture(scope='class')
def get_online_distribution_recipe_type_id(initialize_request,init_env):
    res = initialize_request.get(url=init_env + "/recipe/recipeType")
    recipetypeid = ""
    if res.status_code == 200:
        for i in res.json():
            if i["name"]["en"] == "Online Distribution":
                recipetypeid = i["id"]
                break

    return recipetypeid

