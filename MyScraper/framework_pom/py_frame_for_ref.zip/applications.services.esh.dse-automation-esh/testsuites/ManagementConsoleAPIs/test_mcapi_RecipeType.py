import requests
import pytest
import utils
from utils import FileOperations as fo
from configs import ManagementConsole as mcapi
from libs import commons
import json
from libs import API_responseValidation as api_validation
from libs.ManagementConsole import MC_APIsDataProvider as mc_dp


class Test_RecipeTypeAPI:

    createRecipeTypeData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_RecipeType_JSON,'create')
    updateRecipeTypeData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_RecipeType_JSON,'update')
    deleteRecipeTypeData = fo.File_Operations().get_json_file_filtered_data(mcapi.file_path_create_RecipeType_JSON,"delete")
    
    """maintains list of created RecipeTypes, used in create, update, delete tests"""
    @pytest.fixture(scope='class')
    def createdRecipeTypesId(self):
        return []

    """for get  API"""
    @pytest.fixture(scope='class')
    def collectRecipeTypeId(self):
        return []

    def test_getRecypeType(self,record_property,collectRecipeTypeId,init_env):
        report_data = {"JIRA_ID": "EETK-7158",
                   "Short_Desc": "Create multiple RecipeTypes and validate if API is fetching the list of all RecipeTypes",
                   "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        
        hosturl = init_env + "/recipe/recipeType"
        res = requests.get(url=hosturl,verify=False)
        collectRecipeTypeId.append(res.json()[0]['id'])
        collectRecipeTypeId.append(res.json()[1]['id'])
        
        assert res.status_code==200
        assert len(res.json())>0
    
    @pytest.mark.parametrize("Testdata",createRecipeTypeData)
    def test_createRecipeType(self,Testdata,record_property,createdRecipeTypesId,init_env):
        commons.set_Record_Property(record_property,Testdata,"API", "No Browser")
        payload=json.loads(Testdata["request_payload"])
        payload = mc_dp.update_name_in_payload(payload)
        hosturl = init_env + "/recipe/recipeType" 
        res = requests.post(url=hosturl,json=payload,verify=False)
        data=res.json()
        if res.status_code==200:
            RecipeType_data={"id":data['id'],"name":data["notify"]["en"]}
            createdRecipeTypesId.append(RecipeType_data)
            api_validation.validateJSONFieldData(data["message"],Testdata["expected_message"])
            api_validation.validateJSONFieldData(data["messageCode"],Testdata["expected_message_code"])
        else:
            if Testdata["expected_message_code"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["messageCode"],Testdata["expected_message_code"])
            if Testdata["expected_message"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["message"],Testdata["expected_message"])
        assert res.status_code==Testdata['response_code']
    
    @pytest.mark.parametrize("Testdata",updateRecipeTypeData)
    def test_updateORecipeType(self,Testdata,record_property,init_env,createdRecipeTypesId):
        commons.set_Record_Property(record_property,Testdata,"API", "No Browser")

        if(Testdata["id"]!=""):
            hosturl = init_env + "/recipe/recipeType/"+Testdata["id"]
        else:
            hosturl = init_env + "/recipe/recipeType/"+str(createdRecipeTypesId[0]["id"])
        payload = json.loads(Testdata["request_payload"])

        if payload["name"]["en"] == "":
            payload["name"]["en"] = str(createdRecipeTypesId[0]["name"])

        res = requests.put(url=hosturl,json=payload,verify=False)
        data=res.json()
        
        if res.status_code==200:
            api_validation.validateJSONFieldData(data["message"],Testdata["expected_message"])
            api_validation.validateJSONFieldData(data["messageCode"],Testdata["expected_message_code"])
        else:
            if Testdata["expected_message_code"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["messageCode"],Testdata["expected_message_code"])
            if Testdata["expected_message"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["message"],Testdata["expected_message"])
        assert res.status_code==Testdata['response_code']

    @pytest.mark.parametrize("Testdata",deleteRecipeTypeData)
    def test_deleteRecipeType(self,Testdata,record_property,init_env,createdRecipeTypesId):
        commons.set_Record_Property(record_property,Testdata,"API", "No Browser")
        if(Testdata["id"]=="blank"):
            RecipeTypeID = str(createdRecipeTypesId[-1]["id"])
            createdRecipeTypesId.pop()
        else:
            RecipeTypeID = Testdata["id"]
        
        hosturl = init_env + "/recipe/recipeType/"+str(RecipeTypeID)
        value={"user":"eshautomate"}
        res = requests.delete(hosturl,params=value,verify=False)
        data = res.json()
        if res.status_code==200:
            api_validation.validateJSONFieldData(data["message"],Testdata["expected_message"])
            api_validation.validateJSONFieldData(data["messageCode"],Testdata["expected_message_code"])
        else:
            if Testdata["expected_message_code"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["messageCode"],Testdata["expected_message_code"])
            if Testdata["expected_message"]!="":
                api_validation.validateJSONFieldData(data["errors"][0]["message"],Testdata["expected_message"])
        assert res.status_code==Testdata['response_code']

    def test_deleteAllRecipeTypes(self,record_property,init_env,createdRecipeTypesId):
        report_data = {"JIRA_ID": "EETK-10284",
                       "Short_Desc": "Validate deleting all Recipe Types using automation",
                       "Data": ""}
        commons.set_Record_Property(record_property, report_data, "API")
        for i in range (len(createdRecipeTypesId)):
            hosturl = init_env + "/recipe/recipeType/"+str(createdRecipeTypesId[i]["id"])
            value={"user":"eshautomate"}
            res = requests.delete(hosturl,params=value,verify=False)
            assert res.status_code==200
    