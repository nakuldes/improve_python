import json
import os
import datetime
import pytest
import requests
import logging
import utils.common
from configs import ManagedServices as ms
from urllib3.exceptions import InsecureRequestWarning
from py.xml import html

# def pytest_addoption(parser):
#     # parser.addoption("--env", action="store", default="QA")
#     parser.addoption("--testurl", action="store", help="URL to run the tests against")
#     parser.addoption("--username", action="store", help="User Name of the Test Url Account")
#     parser.addoption("--password", action="store", help="Password of the Test Url Account")

@pytest.fixture(scope='class')
def init_env(pytestconfig):
    global logger

    env_dict={}
    env_dict['testUrl'] = pytestconfig.getoption("testurl")
    env_dict['userId'] = pytestconfig.getoption("username")
    env_dict['passWord'] = pytestconfig.getoption("password")
    env_dict['env'] = pytestconfig.getoption("env")
    env_dict['unauthuserId'] = pytestconfig.getoption("unauthorizedusername")
    env_dict['unauthpassWord'] = pytestconfig.getoption("unauthorizedpassword")
    env_dict['dockerhubusername'] = pytestconfig.getoption("dockerhubusername")    
    env_dict['dockerhubpassword'] = pytestconfig.getoption("dockerhubpassword")
    env_dict['amrregistryusername'] = pytestconfig.getoption("amrregistryusername")
    env_dict['amrregistrypassword'] = pytestconfig.getoption("amrregistrypassword")
    env_dict['msaapigeeauth'] = pytestconfig.getoption("msaapigeeauth")

    return env_dict

@pytest.fixture(scope='class')
def initialize_request(init_env):

    try:
        authSession = requests.Session()
        if init_env['msaapigeeauth'] == 'Yes':
            authHeaders = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            data ={
                "client_secret": init_env['passWord'], 
                "client_id": init_env['userId'],
                "grant_type":"client_credentials"
            }
            proxies = {
                    'http': 'http://proxy-chain.intel.com:911',
                    'https': 'http://proxy-chain.intel.com:912',
            }
            authUrl = init_env['testUrl'] + "/v1/auth/token"
            print("The authURL is: " + authUrl)
            authResponse = authSession.post(url=authUrl,headers=authHeaders,data=data,timeout=5,proxies=proxies)
            if(authResponse.status_code != 200):
                raise Exception (f'Authentication Error, Response code: {authResponse.status_code}; Response Message: {authResponse.text}')
            auth_token =  authResponse.json()["access_token"]
            print("The auth_token is: " + auth_token)
            init_env['DockerUrl'] = init_env['testUrl'] + "/esh/msa/v1/docker/build"
            init_env['StatusUrl'] = init_env['testUrl'] + "/esh/msa/v1/status/"
            init_env['PypiUrl'] = init_env['testUrl'] + "/esh/msa/v1/pypi/build"    

        else:
            authUrl = init_env['testUrl'] + "/v1/auth/token"
            print("The authURL is: " + authUrl)
            authJson = '{"username":"'+ init_env['userId'] + '","password":"' + init_env['passWord'] + '"}'
            print("The authJson : " + authJson)  
            authPayload = json.loads(authJson)
            authHeaders = {
                'Content-Type': 'application/json'
            }
            authSession.headers.update(authHeaders)
            authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)
            if(authResponse.status_code != 200):
                raise Exception (f'Authentication Error, Response code: {authResponse.status_code}; Response Message: {authResponse.text}')
            auth_token =  authResponse.json()["token"]
            print("The auth_token is: " + auth_token)            
            init_env['DockerUrl'] = init_env['testUrl'] + "/v1/build/docker"
            init_env['StatusUrl'] = init_env['testUrl'] + "/v1/status/"
            init_env['PypiUrl'] = init_env['testUrl'] + "/v1/build/pypi/"   
                    
        
        headers = {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + auth_token
                    }
        session = requests.Session()
        session.proxies = {
                    'http': 'http://proxy-chain.intel.com:911',
                    'https': 'http://proxy-chain.intel.com:912',
            }
        session.headers.update(headers)
        session.verify = False
    except Exception as e:
        print("The error is: ", e)
        pytest.fail(e)
    
    return session

@pytest.fixture(scope='class')
def initialize_unauthorizedrequest(init_env):

    try:
        authJson = '{"username":"'+ init_env['unauthuserId'] + '","password":"' + init_env['unauthpassWord'] + '"}'
        print("The authJson : " + authJson)  
        authPayload = json.loads(authJson)
        authUrl = init_env['testUrl'] + "/auth/token"
        authSession = requests.Session()
        authHeaders = {
            'Content-Type': 'application/json'
         }
        authSession.headers.update(authHeaders)
        authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)

        if(authResponse.status_code != 200):
            raise Exception (f'Authentication Error, Response code: {authResponse.status_code}; Response Message: {authResponse.text}')

        session = requests.Session()
        auth_token =  authResponse.json()["token"]
        headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + auth_token
        }
        session.headers.update(headers)
        session.verify = False
    except Exception as e:
        print("The error is: ", e)
        pytest.fail(e)
    
    return session

@pytest.fixture(scope='class')
def initialize_request_text(init_env):

    try:
        authJson = '{"username":"'+ init_env['userId'] + '","password":"' + init_env['passWord'] + '"}'
        print("The authJson : " + authJson)  
        authPayload = json.loads(authJson)
        authUrl = init_env['testUrl'] + "/auth/token"
        authSession = requests.Session()
        authHeaders = {
            'Content-Type': 'application/json'
         }
        authSession.headers.update(authHeaders)
        authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)

        if(authResponse.status_code != 200):
            raise Exception (f'Authentication Error, Response code: {authResponse.status_code}; Response Message: {authResponse.text}')

        session = requests.Session()
        auth_token =  authResponse.json()["token"]
        headers = {
        'Content-Type': 'text/plain',
        'Authorization': 'Bearer ' + auth_token
        }
        session.headers.update(headers)
        session.verify = False
    except Exception as e:
        print("The error is: ", e)
        pytest.fail(e)
    
    return session



@pytest.fixture(scope="class")
def initialize_request_token(init_env):
    token = ""
    url = init_env['testUrl'] + "/auth/token"
    payload = json.dumps({"username": str(init_env['userId']), "password": str(init_env['passWord'])})
    headers = {'Content-Type': 'application/json'}
    try:
        response = requests.request("POST", url, headers=headers, data=payload, verify=False)
        token = response.json()['token']
    except Exception as e:
        print("not able to get token")
    return token
