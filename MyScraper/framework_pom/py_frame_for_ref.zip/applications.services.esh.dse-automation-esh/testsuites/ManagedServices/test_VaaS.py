from managed_service_base_page import Base_Page
import pytest,csv

@pytest.mark.vaas
class Test_VaaS(Base_Page):

    @staticmethod
    def get_csv():
        file = "testdata/ms_api/validation.csv"
        values = []
        with open(file, 'r') as data:
            for row in csv.DictReader(data):
                values.append((row['tc_name'], row["expected_result"], row['yaml_file_path']))
        return values

    @pytest.mark.parametrize("tc_name, expected_result, yaml_file_path", get_csv())
    def test_validation_with_pass_fail_yaml(self, tc_name, expected_result, yaml_file_path, record_property, init_env,
                                           initialize_request_token):
        record_property("JIRA_ID", "")
        record_property("Test_Type", "API")

        bearer_token = initialize_request_token
        response = self.make_validate_request(init_env, bearer_token, yaml_file_path)
        validate_response = self.check_validation_response(response)
        if validate_response:
            status_id = response.json()["statusId"]
            status_response = self.make_status_request(init_env, status_id, bearer_token)
            is_status_response_correct = self.check_status_response(status_response)
            if is_status_response_correct:
                validation_reports = [status_response['responseBody']['artifacts']['html_reports'],
                                      status_response['responseBody']['artifacts']['csv_report']]
                csv_file_url = status_response['responseBody']['artifacts']['csv_report']
                result = self.check_validation_testsuite_tc(csv_file_url, tc_name, expected_result)
                record_property("API_JSON_RESPONSE", validation_reports)
                assert result
            else:
                assert False, "Status response is not as expected"
        else:
            assert False, "Validate response is not as expected"
