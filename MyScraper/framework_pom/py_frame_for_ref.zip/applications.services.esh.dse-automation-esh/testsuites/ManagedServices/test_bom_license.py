from managed_service_base_page import Base_Page
import pytest,json,requests
from utils import FileOperations as fo
from configs import ManagedServices as ms_config


@pytest.mark.bomLicense
class Test_Bom_License():

    createBomLicense = fo.File_Operations().get_json_file_filtered_data(ms_config.file_path_bom_license, "create")
    updateBomLicense = fo.File_Operations().get_json_file_filtered_data(ms_config.file_path_bom_license, "update")
    deleteBomLicense = fo.File_Operations().get_json_file_filtered_data(ms_config.file_path_bom_license, "delete")
    findBomLicense = fo.File_Operations().get_json_file_filtered_data(ms_config.file_path_bom_license, "find")

    def make_bom_license_request(self,request_method, bom_license_url, token, request_payload, params={}):
        response = {}
        try:
            headers = {'Authorization': 'Bearer ' + str(token), 'Content-Type': 'application/json'}
            response = requests.request(request_method, bom_license_url, headers=headers, params=params, data=request_payload, verify=False)
        except Exception as e:
            print("Request_failed ", e)
        return response

    def check_bom_license_success_response(self, response, message):
        json_response = response.json()
        success_response_correct = False
        if response.status_code == 201:
            if json_response["message"] == message:
                    success_response_correct = True
        elif response.status_code == 200:
            if json_response["Status"] == message:
                    success_response_correct = True
        return success_response_correct

    def check_bom_license_error_response(self, response, errorCode, errorMessage):
        json_response = response.json()
        error_response_correct = False
        if response.status_code == 400:
            if json_response["errors"][0]["errorCode"] == errorCode:
                if json_response["errors"][0]["message"] == errorMessage:
                    error_response_correct = True
        return error_response_correct


    @pytest.mark.parametrize("testdata", createBomLicense)
    def test_bom_license_create(self, testdata, record_property, init_env, initialize_request_token):
        record_property("JIRA_ID", testdata["JIRA_ID"])
        record_property("Test_Type", "API")
        bom_license_url = init_env['testUrl'] + "/bom/license/"
        request_payload = testdata["request_payload"]

        response = self.make_bom_license_request("POST", bom_license_url, initialize_request_token, request_payload)
        if response.status_code == 400:
            assert self.check_bom_license_error_response(response,  testdata["expected_message_code"], testdata["expected_message"])
        elif response.status_code == 201:
            assert self.check_bom_license_success_response(response, testdata["message"])
        else:
            assert False

    @pytest.mark.parametrize("testdata", deleteBomLicense)
    def test_bom_license_delete(self, testdata, record_property, init_env, initialize_request_token):
        record_property("JIRA_ID", testdata["JIRA_ID"])
        record_property("Test_Type", "API")
        bom_license_url = init_env['testUrl'] + "/bom/license/"
        request_payload = testdata["request_payload"]

        response = self.make_bom_license_request("DELETE", bom_license_url, initialize_request_token, request_payload)
        if response.status_code == 400:
            assert self.check_bom_license_error_response(response, testdata["expected_message_code"],
                                                         testdata["expected_message"])
        elif response.status_code == 200:
            assert self.check_bom_license_success_response(response, testdata["Status"])
        else:
            assert False

    @pytest.mark.parametrize("testdata", updateBomLicense)
    def test_bom_license_update(self, testdata, record_property, init_env, initialize_request_token):
        record_property("JIRA_ID", testdata["JIRA_ID"])
        record_property("Test_Type", "API")
        bom_license_url = init_env['testUrl'] + "/bom/license/"
        request_payload = testdata["request_payload"]
        response = self.make_bom_license_request("PUT",bom_license_url, initialize_request_token, request_payload)
        if response.status_code == 400:
            assert self.check_bom_license_error_response(response,
                                                         testdata["expected_message_code"],
                                                         testdata["expected_message"])
        elif response.status_code == 200:
            assert self.check_bom_license_success_response(response, testdata["Status"])

    @pytest.mark.parametrize("testdata", findBomLicense)
    def test_bom_license_find(self, testdata, record_property, init_env, initialize_request_token):
        record_property("JIRA_ID", testdata["JIRA_ID"])
        record_property("Test_Type", "API")
        bom_license_url = init_env['testUrl'] + "/bom/license/"
        request_payload = testdata["request_payload"]
        params = testdata["params"]
        response = self.make_bom_license_request("GET", bom_license_url, initialize_request_token, request_payload, params)
        assert response.status_code == testdata["response_code"]
