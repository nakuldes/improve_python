import requests
import pytest
from configs import ManagedServices as ms_config
import time
from utils import FileOperations as fo
from libs import API_responseValidation as api_validation
import json
from jsonpath_ng.ext import parse
import docker

@pytest.mark.builddocker
class TestDockerCreation:
    
    requestStatusId =0
    imageName ='NA'
    imageTag= 'NA'
    global amrRegistryUrl
    amrRegistryUrl = 'https://amr-fm-registry.caas.intel.com/'

    def test_createDockerImageWithAllFields(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8694")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON)
        global imageTag
        global imageName
        imageTag=createDockerImage["valid_Payload_With_All_Fields"]["imageTag"]
        imageName=createDockerImage["valid_Payload_With_All_Fields"]["imageName"]

        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_All_Fields"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithAllFields(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8689")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        print("The request url is : " ,hosturl)

        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesDockerScanwithoutReports")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"
        #Assert Image is uploaded in amr registry
        try:
            client = docker.from_env()
            print(f"The arm regisry username and apssword is: : {init_env['amrregistryusername'], init_env['amrregistrypassword']}")
            login_response = client.login(
                           username=init_env['amrregistryusername'],
                           password=init_env['amrregistrypassword'],
                           registry= amrRegistryUrl
                        )
            print(f"Login Status: : {login_response}")
            #print(f"Docker login returns : {login_response['Status']}")       
            print(f"Pulling docker image : {imageName}")       
            imageObject = client.images.pull("amr-fm-registry.caas.intel.com/esh-user/"+imageName,tag=imageTag)            
            print(f"The Image object is: {imageObject}")
            if imageObject is not None:
                assert True
            else:
                assert False
        except Exception as e:
            print(f"Failed to login to docker registry : {e}")
            pytest.fail(e)       

    def test_createDockerImageWithDifferentVersion(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8700")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_DifferentVersion"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithDifferentVersion(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8700")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesDockerScanwithoutReports")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_createDockerImageWithMandatoryFields(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9054")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_Mandatory_Fields"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithMandatoryFields(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesDockerScanwithoutReports")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_createDockerImageWithValidDefaultDockerFileInLocation(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_ValidDefaultDockerFileInLocation"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithValidDefaultDockerFileInLocation(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesDockerScanwithoutReports")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_createDockerImageWithInvalidDockerLocation(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8709")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_InvalidDockerFileLocation"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_createDockerImageWithValidBranchName(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_ValidBranchName"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithValidBranchName(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesDockerScanwithoutReports")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_createDockerImageWithInvalidDockerLocation(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8709")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_InvalidDockerFileLocation"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithInvalidDockerLocation(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9024")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesFailure")
        assert jsonres_validation==True
        assert responseJson["status"] == "FAILURE"

    def test_createDockerImageWithInvalidGithubRepo(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8665")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_InvalidGitHubRepo"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithInvalidGithubRepo(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8665")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesFailure")
        assert jsonres_validation==True
        assert responseJson["status"] == "FAILURE"

    def test_createDockerImageWithInvalidBranchName(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8666")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_InvalidBranchName"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithInvalidBranchName(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8666")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['StatusUrl'] + str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesFailure")
        assert jsonres_validation==True
        assert responseJson["status"] == "FAILURE"

    def test_createDockerImageWithInvalidGitHubUrl(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8749")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_InvalidGithubUrl"])
        print("The response is:", response.text)

        #Assert Statements
        assert response.status_code==400
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceInvalidParamErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "invalidURL" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "invalid url" == parse("$.errors[0].message").find(errors)[0].value
        assert "githubUrl" == parse("$.errors[0].param").find(errors)[0].value

    def test_createDockerImageWithWithoutGitHubUrlParam(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8749")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_Without_GithubUrlParam"])
        print("The response is:", response.text)
        
        #Assert Statements
        assert response.status_code==400
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceInvalidParamErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "githubUrlMandatory" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "githubUrl is a mandatory field" == parse("$.errors[0].message").find(errors)[0].value
        assert "githubUrl" == parse("$.errors[0].param").find(errors)[0].value


    def test_createDockerImageWithWithoutImageNameParam(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8693")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['DockerUrl']
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_Without_ImageNameParam"])
        print("The response is:", response.text)
        
        #Assert Statements
        assert response.status_code==400
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceInvalidParamErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "imageNameMandatory" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "imageName is a mandatory field" == parse("$.errors[0].message").find(errors)[0].value
        assert "imageName" == parse("$.errors[0].param").find(errors)[0].value