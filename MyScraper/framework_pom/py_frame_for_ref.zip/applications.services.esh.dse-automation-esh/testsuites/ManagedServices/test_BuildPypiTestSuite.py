import requests
import pytest
import time
from utils import FileOperations as fo
import json
from jsonpath_ng.ext import parse
from libs.ManagedServices import msa_api_dataprovider as testdata
from libs import API_responseValidation as api_validation
from libs.ManagedServices import  msa_api_datavalidation as msaapival
import copy


@pytest.mark.buildpypi
class TestPypiPackageCreation:    
    
    requestStatusId =0

    
    @pytest.mark.parametrize("PypiTestData", testdata.get_BuildPypi_TestData_As_JSON("POST"))
    def test_buildPypiAuthorizedUser(self,record_property, init_env, initialize_request,PypiTestData):
        record_property("JIRA_ID",PypiTestData['JIRA_ID'])
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['PypiUrl']
        print("The request url is : " ,hosturl)
        tempTestData = copy.deepcopy(PypiTestData)
        del tempTestData['JIRA_ID']
        del tempTestData['Short_Desc']
        del tempTestData['Scenario_Type']
        del tempTestData['ExpectedResult']
        print("The temp data: ", tempTestData)
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=tempTestData)
        print("The response is:", response.text)

        if PypiTestData['ExpectedResult'].lower() == 'error':
            assert response.json()["errors"][0]["errorCode"] == PypiTestData['errorCode']
            assert response.json()["errors"][0]["message"] == PypiTestData['message']
            assert response.json()["errors"][0]["param"] == PypiTestData['param'] 
        else:
            global requestStatusId
            requestStatusId = response.json()["statusId"]

            print("The pypi test data:", PypiTestData)
            #Assert Statements
            assert response.status_code==201
            jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
            assert jsonres_validation==True
            msaapival.verifyPypiRequestStatus(init_env, initialize_request, PypiTestData,requestStatusId)
