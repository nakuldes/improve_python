import requests
import pytest
from configs import ManagedServices as ms_config
import time
from utils import FileOperations as fo
from libs import API_responseValidation as api_validation
from libs.ManagedServices import  msa_api_datavalidation as msaapival
import json
from jsonpath_ng.ext import parse
import docker

@pytest.mark.builddocker
class TestDockerCreation:

    requestStatusId =0
    imageName ='NA'
    imageTag= 'NA'


    def test_createDockerImageWithAllFields(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8694")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['testUrl'] + "/build/docker/"
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON)

        imageTag=createDockerImage["valid_Payload_With_All_Fields"]["imageTag"]
        imageName=createDockerImage["valid_Payload_With_All_Fields"]["imageName"]

        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createDockerImage["valid_Payload_With_All_Fields"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

        msaapival.verify_msa_api_status(init_env, initialize_request, imageTag, imageName, response.json()["statusId"])
