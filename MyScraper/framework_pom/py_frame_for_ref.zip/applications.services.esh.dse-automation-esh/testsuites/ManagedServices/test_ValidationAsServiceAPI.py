import requests
import pytest
from configs import ManagedServices as ms_config
import time
from utils import FileOperations as fo
from libs import API_responseValidation as api_validation
import json
from jsonpath_ng.ext import parse
import yaml

@pytest.mark.validationdocker
class TestDockerCNFSuite:
    
    requestStatusId =0
    global validateUrl
    validateUrl = "/validate/"

    def test_validateSingleImageWithAllPass(self,record_property, init_env, initialize_request_text):
        record_property("JIRA_ID","")
        record_property("Test_Type","API")
        
        hosturl = init_env['testUrl'] + validateUrl
        print("The request url is : " ,hosturl)

        validateSingleImage = fo.File_Operations().get_yaml_file_data(ms_config.file_path_validateDocker_SingleImage)       
        validateSingleImage['auths']['https://registry.hub.docker.com/']['username'] = init_env['dockerhubusername']
        validateSingleImage['auths']['https://registry.hub.docker.com/']['password'] = init_env['dockerhubpassword']
        validateSingleImage['auths']['https://amr-fm-registry.caas.intel.com/']['username'] = init_env['amrregistryusername']
        validateSingleImage['auths']['https://amr-fm-registry.caas.intel.com/']['password'] = init_env['amrregistrypassword']
        #Make POST Http Request
        response = initialize_request_text.post(url=hosturl,data=yaml.dump(validateSingleImage))
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdValidateSingleImageWithAllPass(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","")
        record_property("Test_Type","API")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        respArr = [responseJson['reports']['html_reports'],responseJson['reports']['csv_report']]
        record_property("API_JSON_RESPONSE",respArr)
        #Assert Statements        
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesStatusValidateDocker")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_validateMultipleImageAllFail(self,record_property, init_env, initialize_request_text):
        record_property("JIRA_ID","")
        record_property("Test_Type","API")
        
        hosturl = init_env['testUrl'] + validateUrl
        print("The request url is : " ,hosturl)

        validateMultipleImage = fo.File_Operations().get_yaml_file_data(ms_config.file_path_validateDocker_MultipleImageWithAllFail)       
        validateMultipleImage['auths']['https://registry.hub.docker.com/']['username'] = init_env['dockerhubusername']
        validateMultipleImage['auths']['https://registry.hub.docker.com/']['password'] = init_env['dockerhubpassword']
        validateMultipleImage['auths']['https://amr-fm-registry.caas.intel.com/']['username'] = init_env['amrregistryusername']
        validateMultipleImage['auths']['https://amr-fm-registry.caas.intel.com/']['password'] = init_env['amrregistrypassword']
        #Make POST Http Request
        response = initialize_request_text.post(url=hosturl,data=yaml.dump(validateMultipleImage))
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdValidateMultipleImageAllFail(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","")
        record_property("Test_Type","API")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        respArr = [responseJson['reports']['html_reports'],responseJson['reports']['csv_report']]
        record_property("API_JSON_RESPONSE",respArr)
        #Assert Statements        
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesStatusValidateDocker")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_validateDockerComposeFile(self,record_property, init_env, initialize_request_text):
        record_property("JIRA_ID","")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + validateUrl
        print("The request url is : " ,hosturl)

        validateDockerComposeFile = fo.File_Operations().get_yaml_file_data(ms_config.file_path_validateDocker_CommposeFile)       
        
        #Make POST Http Request
        response = initialize_request_text.post(url=hosturl,data=yaml.dump(validateDockerComposeFile))
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdValidateDockerComposeFile(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","")
        record_property("Test_Type","API")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        respArr = [responseJson['reports']['html_reports'],responseJson['reports']['csv_report']]
        record_property("API_JSON_RESPONSE",respArr)
        #Assert Statements        
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesStatusValidateDocker")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"