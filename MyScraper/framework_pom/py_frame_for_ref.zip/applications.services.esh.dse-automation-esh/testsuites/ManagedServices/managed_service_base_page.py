import json
import requests
import pytest
from configs import ManagedServices
from utils import FileOperations as fo
from libs import API_responseValidation as api_response_body_validation
import yaml
import csv
import time
import os


class Base_Page:

    def update_credentials_in_yaml_file(self, init_env, yaml_file):
        with open(yaml_file, "r") as file:
            modifyYamlData = yaml.safe_load(file)
        auth_list = modifyYamlData['auths']
        for i in range(len(auth_list)):
            if auth_list[i]['url'] == 'https://registry.hub.docker.com/':
                auth_list[i]['username'] = init_env['dockerhubusername']
                auth_list[i]['password'] = init_env['dockerhubpassword']

            if auth_list[i]['url'] == 'https://amr-fm-registry.caas.intel.com/':
                auth_list[i]['username'] = init_env['amrregistryusername']
                auth_list[i]['password'] = init_env['amrregistrypassword']

            if auth_list[i]['url'] == 'https://amr-fm-registry.caas.intel.com/chartrepo/esh-user':
                auth_list[i]['username'] = init_env['amrregistryusername']
                auth_list[i]['password'] = init_env['amrregistrypassword']
        modifyYamlData['auths'] = auth_list
        return modifyYamlData

    def make_validate_request(self, init_env, token, yaml_file):
        validate_url = init_env['testUrl'] + "/validate/"
        response = {}
        try:
            updated_yaml_file = self.update_credentials_in_yaml_file(init_env, yaml_file)
            payload = yaml.dump(updated_yaml_file)
            headers = {'Authorization': 'Bearer ' + str(token), 'Content-Type': 'text/plain'}
            response = requests.request("POST", validate_url, headers=headers, data=payload, verify=False)
        except Exception as e:
            print("Request_failed ", e)
        return response

    def check_validation_response(self, response):
        is_validation_response_correct = False
        print(response)
        print(response.json())
        if response.status_code == 201:
            is_validation_response_correct = api_response_body_validation.getJSONSchema(data=response.json(),
                                                                                        dataKey="managedServicesStatus")
        return is_validation_response_correct

    def make_status_request(self, init_env, status_id, token):
        get_url = init_env['testUrl'] + "/status/" + str(status_id)
        headers = {'Authorization': 'Bearer ' + str(token)}
        payload = {}
        json_response = requests.request("GET", get_url, headers=headers, data=payload, verify=False).json()
        try:
            while json_response["status"] != "SUCCESS" and json_response["status"] != "FAILURE":
                json_response = requests.request("GET", get_url, headers=headers, data=payload, verify=False).json()
                time.sleep(20)
                print(json_response)
        except Exception as e:
            print(json_response)
        return json_response

    def check_status_response(self, json_response):
        is_status_response_correct = False
        if json_response['status'] == "SUCCESS":
            is_status_response_correct = api_response_body_validation.getJSONSchema(json_response,
                                                                                    "managedServiceStatusValidateHelm")
        return is_status_response_correct

    def check_failure_status_response(self, json_response):
        is_status_response_correct = False
        if json_response['status'] == "FAILURE":
            is_status_response_correct = api_response_body_validation.getJSONSchema(json_response,
                                                                                    "managedServiceValidationFailureStatus")
        return is_status_response_correct

    def download_csv_report(self, csv_file_url):
        csv_file = requests.get(url=csv_file_url)
        file = "testResults/validation_report.csv"
        try:
            with open(file, 'wb') as data:
                data.write(csv_file.content)
        except Exception as e:
            print("csv file operation failed")
        return file

    def check_validateHelm_testsuite_tc(self, csv_file_url, tc_names, expected_result):
        file = self.download_csv_report(csv_file_url)
        result = True
        try:
            with open(file, 'r+', encoding='UTF-8') as csv_data:
                for row in csv.DictReader(csv_data):
                    if result:
                        for each_tc in tc_names.split():
                            if each_tc in row['name'] and 'helm' in row['markers']:
                                print(row['status'], row['name'])
                                if row['status'] != expected_result:
                                    result = False
                                    break
            return result
        except Exception as e:
            print("csv file operation failed")
            result = False
            return result
        finally:
            os.remove(file)

    def check_validation_testsuite_tc(self, csv_file_url, tc_names, expected_result):
        file = self.download_csv_report(csv_file_url)
        result = True
        try:
            with open(file, 'r+', encoding='UTF-8') as csv_data:
                for row in csv.DictReader(csv_data):
                    if result:
                        for each_tc in tc_names.split():
                            if each_tc in row['name']:
                                print(row['status'], row['name'])
                                if row['status'] != expected_result:
                                    result = False
                                    break
            return result
        except Exception as e:
            print("csv file operation failed")
            result = False
            return result
        finally:
            os.remove(file)
