from managed_service_base_page import Base_Page
import pytest,csv

@pytest.mark.validateHelm
class Test_validate_helm(Base_Page):

    @staticmethod
    def get_csv():
        file = "testdata/ms_api/validateHelm.csv"
        values = []
        with open(file, 'r') as data:
            for row in csv.DictReader(data):
                values.append((row['tc_name'], row["expected_result"], row['yaml_file_path']))
        return values

    @pytest.mark.parametrize("tc_name, expected_result, yaml_file_path", get_csv())
    def test_validate_helm_with_valid_data(self, tc_name, expected_result, yaml_file_path, record_property, init_env, initialize_request_token):
        record_property("JIRA_ID", "")
        record_property("Test_Type", "API")

        bearer_token = initialize_request_token
        response = self.make_validate_request(init_env, bearer_token, yaml_file_path)
        validate_response = self.check_validation_response(response)
        if validate_response:
            status_id = response.json()["statusId"]
            status_response = self.make_status_request(init_env, status_id, bearer_token)
            print(status_response)
            is_status_response_correct = self.check_status_response(status_response)
            if is_status_response_correct:
                validation_reports = [status_response['responseBody']['artifacts']['html_reports'],
                                      status_response['responseBody']['artifacts']['csv_report']]
                csv_file_url = status_response['responseBody']['artifacts']['csv_report']
                result = self.check_validateHelm_testsuite_tc(csv_file_url, tc_name, expected_result)
                record_property("API_JSON_RESPONSE", validation_reports)
                assert result
            else:
                assert False, "Status response is not as expected"
        else:
            assert False, "Validate response is not as expected"


    def test_validate_helm_with_invalid_data(self, record_property, init_env, initialize_request_token):
        record_property("JIRA_ID", "")
        record_property("Test_Type", "API")

        bearer_token = initialize_request_token
        yaml_file_path = "testdata/ms_api/ValidateHelm_wrong_details.yaml"
        validate_response = self.make_validate_request(init_env, bearer_token, yaml_file_path)
        is_validate_response_correct = self.check_validation_response(validate_response)
        if is_validate_response_correct:
            status_id = validate_response.json()["statusId"]
            status_response = self.make_status_request(init_env, status_id, bearer_token)
            is_status_response_correct = self.check_failure_status_response(status_response)
            assert is_status_response_correct

    def test_invalid_yaml_file(self, record_property, initialize_request_token):
        record_property("JIRA_ID", "")
        record_property("Test_Type", "API")
        # token = initialize_request_token
        is_yaml_file_valid = True
        try:
            invalid_yam_file = fo.File_Operations().get_yaml_file_data("testdata/ms_api/ValidateHelm_invalidyaml_nginx.yaml")
        except Exception as e:
            is_yaml_file_valid = False
        assert is_yaml_file_valid == False


