import requests
import pytest
from configs import ManagedServices as ms_config
import time
from utils import FileOperations as fo
from libs import API_responseValidation as api_validation
import json
from jsonpath_ng.ext import parse
import subprocess

@pytest.mark.buildhelmchart
class TestHelmChartCreation:
    
    requestStatusId =0
    global helmchartUrl
    helmchartUrl = "/build/helm/"

    def test_createHelmChartWithAllFields(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9026")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + helmchartUrl
        print("The request url is : " ,hosturl)

        createHelmChart = fo.File_Operations().get_json_file_data(ms_config.file_path_create_helmchart_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createHelmChart["valid_Payload_With_All_Fields"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithAllFields(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9026")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesStatusHelmChart")
        assert jsonres_validation==True
        assert responseJson["status"] == SUCCESS
        
        #Asserting Helm Chart Creation in Caas
        try:
            process_output = subprocess.run("helm search repo appqa --version 1.0.4",shell=True,stdout=subprocess.PIPE)
            if process_output.stdout.decode('utf8').find("appqa") != -1:
                assert True
            else:
                assert False    
        except Exception as e:
            print (e)
        
    def test_createHelmChartWithoutCharVersion(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9030")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + helmchartUrl
        print("The request url is : " ,hosturl)

        createHelmChart = fo.File_Operations().get_json_file_data(ms_config.file_path_create_helmchart_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createHelmChart["valid_Payload_WithoutCharVersion"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithoutCharVersion(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9030")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesStatusHelmChart")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_createHelmChartWithoutFilesinGithubLink(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8746")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + helmchartUrl
        print("The request url is : " ,hosturl)

        createHelmChart = fo.File_Operations().get_json_file_data(ms_config.file_path_create_helmchart_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createHelmChart["valid_Payload_WithoutFilesinGithubLink"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithoutFilesinGithubLink(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8746")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesFailure")
        assert jsonres_validation==True
        assert responseJson["status"] == "FAILURE"

    def test_createHelmChartWithBranchandHelmChartLocation(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9039")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + helmchartUrl
        print("The request url is : " ,hosturl)

        createHelmChart = fo.File_Operations().get_json_file_data(ms_config.file_path_create_helmchart_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createHelmChart["valid_Payload_WithBranchandHelmChartLocation"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithBranchandHelmChartLocation(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9039")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesStatusHelmChart")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_createHelmChartWithoutGitHubUrlParam(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9034")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + helmchartUrl
        print("The request url is : " ,hosturl)

        createHelmChart = fo.File_Operations().get_json_file_data(ms_config.file_path_create_helmchart_JSON)           
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createHelmChart["valid_Payload_WithoutGithubUrl"])
        print("The response is:", response.text)
        
        #Assert Statements
        assert response.status_code==400
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceInvalidParamErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "githubUrlMandatory" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "githubUrl is a mandatory field" == parse("$.errors[0].message").find(errors)[0].value
        assert "githubUrl" == parse("$.errors[0].param").find(errors)[0].value

    def test_createHelmInvalidGithubLink(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-8684")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + helmchartUrl
        print("The request url is : " ,hosturl)

        createHelmChart = fo.File_Operations().get_json_file_data(ms_config.file_path_create_helmchart_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createHelmChart["valid_Payload_With_InvalidGitHubRepo"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdInvalidGithubLink(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9043")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesFailure")
        assert jsonres_validation==True
        assert responseJson["status"] == "FAILURE"

    #Disabled as of now due to no test data
    def createHelmChartWithoutHelmChartLocation(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9032/EETK-9029")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + helmchartUrl
        print("The request url is : " ,hosturl)

        createHelmChart = fo.File_Operations().get_json_file_data(ms_config.file_path_create_helmchart_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createHelmChart["valid_Payload_WithoutHelmChartLocation"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def statusIdWithoutHelmChartLocation(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9032/EETK-9029")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesStatusHelmChart")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"

    def test_createHelmChartWithSameVersion(self,record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9033")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")
        
        hosturl = init_env['testUrl'] + helmchartUrl
        print("The request url is : " ,hosturl)

        createHelmChart = fo.File_Operations().get_json_file_data(ms_config.file_path_create_helmchart_JSON) 
       
        #Make POST Http Request
        response = initialize_request.post(url=hosturl,json=createHelmChart["valid_Payload_With_SameVersion"])
        print("The response is:", response.text)
        global requestStatusId
        requestStatusId = response.json()["statusId"]

        #Assert Statements
        assert response.status_code==201
        jsonres_validation = api_validation.getJSONSchema(response.json(),"managedServicesStatus")
        assert jsonres_validation==True

    def test_statusIdWithSameVersion(self, record_property, init_env, initialize_request):
        record_property("JIRA_ID","EETK-9042")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")

        hosturl = init_env['testUrl'] + "/status/"+ str(requestStatusId)
        #Make Http Request
        response = initialize_request.get(url=hosturl)
        assert response.status_code==200
        responseJson = response.json()
        print(responseJson)

        try:
            while responseJson["status"] != "FAILURE" and responseJson["status"] != "SUCCESS":
                time.sleep(25)
                responseJson = initialize_request.get(url=hosturl).json()
                print(responseJson)

        except Exception as e:
            print("The response json: ", responseJson)
            pytest.fail(e)

        #Assert Statements
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServicesStatusHelmChart")
        assert jsonres_validation==True
        assert responseJson["status"] == "SUCCESS"