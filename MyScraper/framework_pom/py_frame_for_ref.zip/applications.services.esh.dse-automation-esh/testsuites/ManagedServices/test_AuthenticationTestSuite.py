import requests
import pytest
from libs import API_responseValidation as api_validation
from configs import ManagedServices as ms_config
from utils import FileOperations as fo
from libs import commons
from jsonpath_ng.ext import parse
import json
from base64 import b64decode

@pytest.mark.authentication
class TestAuthenticationSuite:

    def test_InvalidBase64UserName(self, record_property, init_env):
        record_property("JIRA_ID","EETK-8833")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        authJson = '{"username":"'+ "UUE=" + '","password":"' + init_env['unauthpassWord'] + '"}'
        print("The authJson : " + authJson)  
        authPayload = json.loads(authJson)
        authUrl = init_env['testUrl'] + "/auth/token"
        authSession = requests.Session()
        authHeaders = {
            'Content-Type': 'application/json'
         }
        authSession.headers.update(authHeaders)
        authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)

         #Assert Statements
        assert authResponse.status_code==401
        authResponseJson = authResponse.json()
        assert len(authResponseJson)>0
        jsonres_validation = api_validation.getJSONSchema(authResponseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(authResponse.text)
        assert "invalidCredentials" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "username/password is incorrect" == parse("$.errors[0].message").find(errors)[0].value

    def test_InvalidBase64UserName_Password(self, record_property, init_env):
        record_property("JIRA_ID","EETK-8841")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        authJson = '{"username":"'+ "UUE=" + '","password":"' + "UUE=" + '"}'
        print("The authJson : " + authJson)  
        authPayload = json.loads(authJson)
        authUrl = init_env['testUrl'] + "/auth/token"
        authSession = requests.Session()
        authHeaders = {
            'Content-Type': 'application/json'
         }
        authSession.headers.update(authHeaders)
        authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)

         #Assert Statements
        assert authResponse.status_code==401
        authResponseJson = authResponse.json()
        assert len(authResponseJson)>0
        jsonres_validation = api_validation.getJSONSchema(authResponseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(authResponse.text)
        assert "invalidCredentials" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "username/password is incorrect" == parse("$.errors[0].message").find(errors)[0].value

    def test_InvalidBase64Password(self, record_property, init_env):
        record_property("JIRA_ID","EETK-8840")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        authJson = '{"username":"'+ init_env['unauthuserId'] + '","password":"' + "UUE=" + '"}'
        print("The authJson : " + authJson)  
        authPayload = json.loads(authJson)
        authUrl = init_env['testUrl'] + "/auth/token"
        authSession = requests.Session()
        authHeaders = {
            'Content-Type': 'application/json'
         }
        authSession.headers.update(authHeaders)
        authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)

         #Assert Statements
        assert authResponse.status_code==401
        authResponseJson = authResponse.json()
        assert len(authResponseJson)>0
        jsonres_validation = api_validation.getJSONSchema(authResponseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(authResponse.text)
        assert "invalidCredentials" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "username/password is incorrect" == parse("$.errors[0].message").find(errors)[0].value

    def test_ValidUsernamePasswordWithoutEncoding(self, record_property, init_env):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        authJson = '{"username":"'+ str(b64decode(init_env['unauthuserId'])) + '","password":"' + str(b64decode(init_env['unauthpassWord'])) + '"}'
        print("The authJson : " + authJson)  
        authPayload = json.loads(authJson)
        authUrl = init_env['testUrl'] + "/auth/token"
        authSession = requests.Session()
        authHeaders = {
            'Content-Type': 'application/json'
         }
        authSession.headers.update(authHeaders)
        authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)

        #Assert Statements
        assert authResponse.status_code==400
        authResponseJson = authResponse.json()
        assert len(authResponseJson)>0
        jsonres_validation = api_validation.getJSONSchema(authResponseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(authResponse.text)
        assert "notValidBase64Value" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "value is not a base64 encoded" == parse("$.errors[0].message").find(errors)[0].value

    def test_ValidPasswordWithoutEncoding(self, record_property, init_env):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        authJson = '{"username":"'+ str(b64decode(init_env['unauthuserId'])) + '","password":"' + init_env['unauthpassWord'] + '"}'
        print("The authJson : " + authJson)  
        authPayload = json.loads(authJson)
        authUrl = init_env['testUrl'] + "/auth/token"
        authSession = requests.Session()
        authHeaders = {
            'Content-Type': 'application/json'
         }
        authSession.headers.update(authHeaders)
        authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)

        #Assert Statements
        assert authResponse.status_code==400
        authResponseJson = authResponse.json()
        assert len(authResponseJson)>0
        jsonres_validation = api_validation.getJSONSchema(authResponseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(authResponse.text)
        assert "notValidBase64Value" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "value is not a base64 encoded" == parse("$.errors[0].message").find(errors)[0].value

    def test_ValidUserNameWithoutEncoding(self, record_property, init_env):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        authJson = '{"username":"'+ init_env['unauthuserId'] + '","password":"' + str(b64decode(init_env['unauthpassWord'])) + '"}'
        print("The authJson : " + authJson)  
        authPayload = json.loads(authJson)
        authUrl = init_env['testUrl'] + "/auth/token"
        authSession = requests.Session()
        authHeaders = {
            'Content-Type': 'application/json'
         }
        authSession.headers.update(authHeaders)
        authResponse = authSession.post(url=authUrl,json=authPayload,verify=False)

        #Assert Statements
        assert authResponse.status_code==400
        authResponseJson = authResponse.json()
        assert len(authResponseJson)>0
        jsonres_validation = api_validation.getJSONSchema(authResponseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(authResponse.text)
        assert "notValidBase64Value" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "value is not a base64 encoded" == parse("$.errors[0].message").find(errors)[0].value