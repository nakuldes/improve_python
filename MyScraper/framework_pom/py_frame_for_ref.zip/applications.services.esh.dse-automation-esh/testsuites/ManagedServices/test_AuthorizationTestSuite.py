import requests
import pytest
from libs import API_responseValidation as api_validation
from configs import ManagedServices as ms_config
from utils import FileOperations as fo
from libs import commons
from jsonpath_ng.ext import parse
import json

@pytest.mark.authorization
class TestAuthorizationSuite:

    global createDockerImage
    createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON)
   
    def test_BuildDockerUnAuthorization(self, record_property, init_env, initialize_unauthorizedrequest):
        record_property("JIRA_ID","EETK-8873")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        hosturl = init_env['testUrl'] + "/build/docker/"
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_unauthorizedrequest.post(url=hosturl,json=createDockerImage)
        print("The response is:", response.text)

        #Assert Statements
        assert response.status_code==401
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "unAuthorized" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "Unauthorized to perform the action" == parse("$.errors[0].message").find(errors)[0].value

    def test_PublishDockerUnAuthorization(self, record_property, init_env, initialize_unauthorizedrequest):
        record_property("JIRA_ID","EETK-8696")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        hosturl = init_env['testUrl'] + "/publish/docker/"
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_unauthorizedrequest.post(url=hosturl,json=createDockerImage)
        print("The response is:", response.text)

        #Assert Statements
        assert response.status_code==401
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "unAuthorized" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "Unauthorized to perform the action" == parse("$.errors[0].message").find(errors)[0].value

    def test_BuildHelmUnAuthorization(self, record_property, init_env, initialize_unauthorizedrequest):
        record_property("JIRA_ID","EETK-8742")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        hosturl = init_env['testUrl'] + "/build/helm/"
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_unauthorizedrequest.post(url=hosturl,json=createDockerImage)
        print("The response is:", response.text)

        #Assert Statements
        assert response.status_code==401
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "unAuthorized" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "Unauthorized to perform the action" == parse("$.errors[0].message").find(errors)[0].value

    def test_PublishHelmUnAuthorization(self, record_property, init_env, initialize_unauthorizedrequest):
        record_property("JIRA_ID","EETK-9004")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        hosturl = init_env['testUrl'] + "/publish/helm/"
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
       
        #Make POST Http Request
        response = initialize_unauthorizedrequest.post(url=hosturl,json=createDockerImage)
        print("The response is:", response.text)

        #Assert Statements
        assert response.status_code==401
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "unAuthorized" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "Unauthorized to perform the action" == parse("$.errors[0].message").find(errors)[0].value

    def test_StatusUnAuthorization(self, record_property, init_env, initialize_unauthorizedrequest):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        hosturl = init_env['testUrl'] + "/status/1234/"
        print("The request url is : " ,hosturl)

 
        #Make POST Http Request
        response = initialize_unauthorizedrequest.get(url=hosturl)
        print("The response is:", response.text)

        #Assert Statements
        assert response.status_code==401
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "unAuthorized" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "Unauthorized to perform the action" == parse("$.errors[0].message").find(errors)[0].value

    def test_GetValidateConfigTemplateUnAuthorization(self, record_property, init_env, initialize_unauthorizedrequest):
        record_property("JIRA_ID","No Jira")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        hosturl = init_env['testUrl'] + "/validate/config-template"
        print("The request url is : " ,hosturl)

 
        #Make POST Http Request
        response = initialize_unauthorizedrequest.get(url=hosturl)
        print("The response is:", response.text)

        #Assert Statements
        assert response.status_code==401
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "unAuthorized" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "Unauthorized to perform the action" == parse("$.errors[0].message").find(errors)[0].value

    def test_ValidateUnAuthorization(self, record_property, init_env, initialize_unauthorizedrequest):
        record_property("JIRA_ID","EETK-8738")
        record_property("Test_Type","API")
        record_property("Driver","No Browser")
        record_property("Data_Set","")        
        
        hosturl = init_env['testUrl'] + "/validate"
        print("The request url is : " ,hosturl)

        createDockerImage = fo.File_Operations().get_json_file_data(ms_config.file_path_create_dockerimage_JSON) 
        #Make POST Http Request
        response = initialize_unauthorizedrequest.post(url=hosturl,json=createDockerImage)
        print("The response is:", response.text)

        #Assert Statements
        assert response.status_code==401
        responseJson = response.json()
        jsonres_validation = api_validation.getJSONSchema(responseJson,"managedServiceErrorResponse")
        assert jsonres_validation==True
        errors =  json.loads(response.text)
        assert "unAuthorized" == parse("$.errors[0].errorCode").find(errors)[0].value
        assert "Unauthorized to perform the action" == parse("$.errors[0].message").find(errors)[0].value