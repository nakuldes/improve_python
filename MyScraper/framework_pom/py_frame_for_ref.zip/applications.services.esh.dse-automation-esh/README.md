# ESH Automation Repository
# Programming Language and Tools
##### THis automation framework has developed using Python and Pytest

### Projects automated using this framework
```http
Management Console
Service Layer
ESH Selector Tool UI
Managed Services
```

### Command Line execution
```commandline
Management Console test suites execution
pytest .\testsuites\ManagementConsoleAPIs\test_mcapi_Container.py
```
```commandline
Management Console test suites execution
python -m pytest .\testsuites\ManagementConsoleAPIs\test_mcapi_Container.py
```
```commandline
Management Console test suites execution
python -m pytest -s -v --env QA --testurl https://esh-software-services.intel.com/v1 --username ENCRYPTED_USERNAME --password ENCRYPTED_PASSWORD
```

## Test Results
```doctest
Test Result directory gets generated for each execution
 - HTML report contains the JIRA IDs and Test data used for each test case
 - For UI test cases screenshot are included for failed test cases
```






# 
  

