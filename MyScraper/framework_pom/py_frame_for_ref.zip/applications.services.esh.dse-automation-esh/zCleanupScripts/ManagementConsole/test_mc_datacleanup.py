import pytest
import requests
from configs import ManagementConsole as mc
from configs import EdgeSoftwareHubUI_CLI as eshui


# def pytest_addoption(parser):
#     parser.addoption("--env", action="store", default="QA")

@pytest.fixture(scope='class')
def init_env(pytestconfig):
    global mc_url, esh_url,mc_api_qa, logger

    env = pytestconfig.getoption("env")
    if env == "QA":
        mc_url = mc.MC_QA
        esh_url = eshui.ESH_QA
        mc_api_qa = mc.MC_API_HOST_QA
    elif env == "DEV":
        mc_url = mc.MC_DEV
        esh_url = eshui.ESH_DEV

    return mc_api_qa

@pytest.fixture(scope='class')
def initialize_request():
    session = requests.Session()
    headers = {
        'Content-Type': 'application/json',
    }
    session.headers.update(headers)
    session.verify = False
    return session



def test_delete_package(init_env, initialize_request):
    res = initialize_request.get(url=init_env + "/recipe/")
    for i in res.json():
        if str(i["name"]["en"]).startswith("AUTO_") or str(i["name"]["en"]).startswith("Auto_"):
            # print(i)
            hosturl = init_env + "/recipe/" + i["id"]
            value = {"user": "eshautomate"}
            res = initialize_request.delete(hosturl, params=value)
            if res.status_code == 200:
                print("Deleted .. " + str(i["name"]["en"]))

def test_delete_helmchart(init_env, initialize_request):
    res = initialize_request.get(url=init_env + "/helmchart/")
    for i in res.json():
        if str(i["name"]["en"]).startswith("AUTO_") or str(i["name"]["en"]).startswith("Auto_"):
            # print(i)
            hosturl = init_env + "/helmchart/" + i["id"]
            value = {"user": "eshautomate"}
            res = initialize_request.delete(hosturl, params=value)
            if res.status_code == 200:
                print("Deleted .. " + str(i["name"]["en"]))

def test_delete_container(init_env, initialize_request):
    res = initialize_request.get(url=init_env + "/container/")
    for i in res.json():
        if str(i["name"]["en"]).startswith("AUTO_") or str(i["name"]["en"]).startswith("Auto_"):
            # print(i)
            hosturl = init_env + "/container/" + i["id"]
            value = {"user": "eshautomate"}
            res = initialize_request.delete(hosturl, params=value)
            if res.status_code == 200:
                print("Deleted .. " + str(i["name"]["en"]))

def test_delete_onlinedistribution(init_env, initialize_request):
    res = initialize_request.get(url=init_env + "/distribution/")
    for i in res.json():
        if str(i["name"]["en"]).startswith("AUTO_") or str(i["name"]["en"]).startswith("Auto_") or str(i["name"]["en"]).startswith("( - +()&"):
            # print(i)
            hosturl = init_env + "/distribution/" + i["id"]
            value = {"user": "eshautomate"}
            res = initialize_request.delete(hosturl, params=value)
            if res.status_code == 200:
                print("Deleted .. " + str(i["name"]["en"]))


def test_delete_modules(init_env, initialize_request):
    res = initialize_request.get(url=init_env + "/ingredient/")
    for i in res.json():
        if str(i["name"]["en"]).startswith("AUTO_") or str(i["name"]["en"]).startswith("Auto_"):
            print(i)
            hosturl = init_env + "/ingredient/" + i["id"]
            value = {"user": "eshautomate"}
            res = initialize_request.delete(hosturl, params=value)
            if res.status_code == 200:
                print("Deleted .. " + str(i["name"]["en"]))
