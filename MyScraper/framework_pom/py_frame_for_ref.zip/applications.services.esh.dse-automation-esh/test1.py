import paramiko
import os

def get_ubuntu_22_connection():
    print("Creating SSH connection for Ubuntu 22 VM....")
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # ssh.set_missing_host_key_policy(paramiko.MissingHostKeyPolicy())
        ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
        ssh.connect('10.66.244.41', 22, 'intel', 'intel@123', look_for_keys=False, allow_agent=False)
        console = ssh.invoke_shell()
        console.keep_this = ssh
        print("Successfully created SSH connection for Ubuntu 22 VM....")
    except Exception as e:
        print("SSH Connectioned failed due to error : " + str(e))
    return ssh


ssh = get_ubuntu_22_connection()
ls = ["sudo yum install bison", "sudo yum install gawk", "sudo yum install nasm", "sudo yum install ninja-build", "sudo yum install pkg-config", "sudo yum install python3", "sudo yum install python3-click", "sudo yum install python3-jinja2", "sudo yum install python3-pip", "sudo yum install python3-pyelftools", "sudo yum install wget"]
for cmd in ls:
    cmd_executable = cmd
    stdin, stdout, stderr = ssh.exec_command(cmd_executable)
    print(stdout.read().decode())
    stdin.write('intel@123')
    if stderr.channel.recv_exit_status() != 0:
        print(f"error occured: {stderr.readline()}")
        print(stdout.read().decode())
ssh.close()