﻿#$IPaddr=$args[0]

#Uncomment only once below statement to install required module in case of incompatibility
#Install-Module -Name ImportExcel -Scope CurrentUser -Force

#-------------- LOGIN DETAILS --------------#

$IPaddr="10.3.159.251"
$RESTAPIUser = "infoblox"
$RESTAPIPassword = "test"
$baseURL = "https://10.201.0.111/wapi/v2.3/ipv4address?ip_address="



add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'


$RESTAPIURLu = $baseURL + $IPaddr
$Header = @{"Authorization" = "Basic "+[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($RESTAPIUser+":"+$RESTAPIPassword))}
$Type = "application/xml"


################ FIRST LOGIN ################
#-------------------------------------------#
Try 
{
    $apiSessionResponse = Invoke-RestMethod -Uri $RESTAPIURLu -Headers $Header -Method GET -SessionVariable session
    write "Login SUCCESS"
}
Catch 
{
    $_.Exception.ToString()
    $error[0] | Format-List -Force
    write "FAILED - Check Login details" #If login fails script will be terminated
    exit 1
}

#-------------- OUTPUT & INPUT FILES --------------#
$inputFilePath = "F:\Test1.xlsx"         ##Input File Path with File Name
$outputCSVPath = "F:\output.csv"         #Output File Path with File Name

#-------------- Keep all IPs in worksheet >>Sheet1<< Under column header ip_address --------------# 
$x1 =Import-Excel -Path $Path -WorksheetName Sheet1 -HeaderName ip_address

$totalrows = $x1.Count - 1
$response_List = $null
$errs = $null

#-------------- STARTING MULTI QUERIES OPERATIONS --------------#

for($i =1; $i -le $totalrows; $i++){
    $raw_IP = $x1.GetValue($i)
    $str_IP = Out-String -InputObject $raw_IP
    $ipAdddr = $str_IP -replace  "`t|`n|`r|-|ip_address",""
    $RESTAPIURLm = $baseURL + $ipAdddr.Trim()
        Try{
            $response = Invoke-RestMethod -Uri $RESTAPIURLm -WebSession $session -Method GET 
            }
        Catch {
            $_.Exception.ToString() #---------unfinished error handle
            $response = $raw_IP     #---------puts BLANK if ip is not available
            $errs = $error[0]       #--------- silently continues for rest of the IPs
    }
    $response_List = $response_List + $response
    $outpt = $response_List | Select ip_address, network| ConvertTo-Csv
    
}
#--------Below File will be overwritten on each run of this script-----#
$outpt | Out-File $outPAth -Force