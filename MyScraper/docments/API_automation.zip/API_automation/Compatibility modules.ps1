﻿#Below statement to install required module in case of incompatibility
Install-Module -Name ImportExcel -Scope CurrentUser -Force

# with Administrator rights
# Use below 
#Install-Module -Name ImportExcel -Force